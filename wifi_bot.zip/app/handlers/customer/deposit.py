"""গ্রাহক প্যানেল — 'টাকা জমা' (ডিপোজিট) ফ্লো, স্মার্ট এক-স্ক্রিন সংস্করণ।

- পুরো ফ্লোতে একটিই বট-মেসেজ ('স্ক্রিন') থাকে; ধাপে ধাপে সেটিই edit হয়,
  ফলে চ্যাট পরিষ্কার থাকে (নতুন মেসেজ জমে না)।
- প্রতিটি ধাপে '🔙 পিছনে' — এক ধাপ আগে ফেরা যায়।
- প্রি-সেট অ্যামাউন্ট বাটন, বাংলা অঙ্ক/৳/কমা গ্রহণ, শেষ মাধ্যম মনে রাখা,
  এবং সাবমিটের আগে নিশ্চিতকরণ সারাংশ।

এই router customer_panel-এর আগে রেজিস্টার হয়, তাই ডিপোজিট সংক্রান্ত সব
হ্যান্ডলিং এখান থেকেই হয়।
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.handlers.customer.panel import (
    _INTERRUPT,
    _deny_if_banned,
    _ensure_account,
    _is_cancel,
    _notify_owner_request,
    _resolve,
)
from app.keyboards.customer_kb import (
    CM_DEPOSIT,
    back_kb,
    deposit_amount_kb,
    deposit_confirm_kb,
    deposit_methods_kb,
    deposit_proof_kb,
)
from app.services.request_service import request_service
from app.services.settings_service import settings_service
from app.states.states import CustomerDeposit
from app.utils import date_utils, validators
from app.utils.logger import get_logger
from app.utils.nav import delete_user_message, show_screen

log = get_logger(__name__)

router = Router(name="customer-deposit")

# শেষ ব্যবহৃত পেমেন্ট মাধ্যম (telegram_id -> method) — রিস্টার্টে রিসেট (নিছক সুবিধা)।
_LAST_METHOD: dict[int, str] = {}

_BN_DIGITS = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")


# --------------------------- টেক্সট হেল্পার ---------------------------
def _method_text() -> str:
    return "💵 <b>টাকা জমা</b>\n\nকোন মাধ্যমে টাকা পাঠাবেন তা বেছে নিন:"


def _amount_text(method: str) -> str:
    return (
        f"💵 মাধ্যম: <b>{method}</b>\n\n"
        "কত টাকা জমা দিতে চান? নিচ থেকে বেছে নিন — অথবা পরিমাণ লিখে পাঠান:"
    )


def _number_text() -> str:
    return "📱 আপনি যে নম্বর থেকে টাকা পাঠিয়েছেন সেই নম্বরটি লিখুন (আবশ্যক):"


def _summary_text(method: str, amount: float, number, has_proof: bool) -> str:
    lines = [
        "🧾 <b>ডিপোজিট নিশ্চিত করুন</b>",
        "",
        f"মাধ্যম: <b>{method}</b>",
        f"পরিমাণ: <b>{date_utils.fmt_money(amount)}</b>",
    ]
    if number:
        lines.append(f"প্রেরকের নম্বর: <b>{date_utils.to_bn_digits(number)}</b>")
    if method != "Cash":
        lines.append("প্রমাণ: " + ("সংযুক্ত ✅" if has_proof else "দেওয়া হয়নি"))
    lines.append("")
    lines.append("সব ঠিক থাকলে নিচের বাটনে চাপুন:")
    return "\n".join(lines)


def _parse_amount(text) -> float:
    """বাংলা অঙ্ক, ৳ চিহ্ন, কমা ও স্পেস সরিয়ে টাকার অঙ্ক যাচাই করে।"""
    raw = (text or "").translate(_BN_DIGITS)
    for ch in ("৳", ",", " ", "\t"):
        raw = raw.replace(ch, "")
    return validators.validate_amount(raw)


# --------------------------- স্ক্রিন হেল্পার ---------------------------
async def _show_method(event, state: FSMContext, user_id: int) -> None:
    methods = await settings_service.method_names()
    cash = await settings_service.is_cash_enabled()
    await state.set_state(CustomerDeposit.choosing_method)
    await show_screen(
        event,
        state,
        _method_text(),
        reply_markup=deposit_methods_kb(methods, cash, _LAST_METHOD.get(user_id)),
    )


async def _show_amount(event, state: FSMContext) -> None:
    data = await state.get_data()
    method = data.get("method", "Cash")
    await state.set_state(CustomerDeposit.waiting_amount)
    await show_screen(
        event,
        state,
        _amount_text(method),
        reply_markup=deposit_amount_kb(back_data="dep:back:method"),
    )


async def _show_proof(event, state: FSMContext) -> None:
    data = await state.get_data()
    method = data.get("method", "Cash")
    amount = float(data.get("amount", 0.0))
    number = await settings_service.get_payment_number(method)
    if number:
        pay_line = (
            f"📲 নিচের {method} নম্বরে {date_utils.fmt_money(amount)} পাঠান:\n"
            f"<code>{number}</code>\n\n"
        )
    else:
        pay_line = (
            f"⚠ এই মুহূর্তে {method} নম্বর সেট করা নেই — সাপোর্ট টিমের সাথে যোগাযোগ করুন।\n\n"
        )
    await state.set_state(CustomerDeposit.waiting_proof)
    await show_screen(
        event,
        state,
        pay_line
        + "টাকা পাঠানোর পর পেমেন্টের স্ক্রিনশট অথবা Transaction ID পাঠান।\n"
        "(না থাকলে নিচের 'স্কিপ' বাটনে চাপুন — এরপর নম্বর চাওয়া হবে)",
        reply_markup=deposit_proof_kb(back_data="dep:back:amount"),
    )


async def _show_number(event, state: FSMContext) -> None:
    await state.set_state(CustomerDeposit.waiting_number)
    await show_screen(event, state, _number_text(), reply_markup=back_kb("dep:back:proof"))


async def _show_confirm(event, state: FSMContext) -> None:
    data = await state.get_data()
    method = data.get("method", "Cash")
    amount = float(data.get("amount", 0.0))
    number = data.get("sender_number")
    has_proof = bool(data.get("dep_txn") or data.get("dep_proof_file_id"))
    await state.set_state(CustomerDeposit.waiting_confirm)
    await show_screen(
        event,
        state,
        _summary_text(method, amount, number, has_proof),
        reply_markup=deposit_confirm_kb(back_data="dep:back:confirm"),
    )


async def _cancel(event, state: FSMContext, text: str) -> None:
    await show_screen(event, state, text)
    await state.clear()


# --------------------------- এন্ট্রি ---------------------------
@router.message(F.text == CM_DEPOSIT)
async def menu_deposit(message: Message, state: FSMContext) -> None:
    customer = await _ensure_account(message.from_user)
    if customer is None:
        await message.answer(
            "টাকা জমা দিতে হলে প্রথমে আপনার সংযোগ থাকতে হবে। "
            "মেনু থেকে সংযোগের অনুরোধ পাঠান।"
        )
        return
    await state.clear()
    await _show_method(message, state, message.from_user.id)


# --------------------------- বাতিল ও পিছনে ---------------------------
@router.callback_query(F.data == "dep:cancel")
async def deposit_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await _cancel(callback, state, "❌ ডিপোজিট বাতিল করা হয়েছে।")
    await callback.answer()


@router.callback_query(F.data == "dep:back:method")
async def back_to_method(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_method(callback, state, callback.from_user.id)
    await callback.answer()


@router.callback_query(F.data == "dep:back:amount")
async def back_to_amount(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_amount(callback, state)
    await callback.answer()


@router.callback_query(F.data == "dep:back:proof")
async def back_to_proof(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_proof(callback, state)
    await callback.answer()


@router.callback_query(F.data == "dep:back:confirm")
async def back_from_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    if data.get("method", "Cash") == "Cash":
        await _show_amount(callback, state)
    else:
        await _show_number(callback, state)
    await callback.answer()


# --------------------------- প্রি-সেট অ্যামাউন্ট ---------------------------
@router.callback_query(F.data.startswith("dep:amt:"))
async def deposit_amount_preset(callback: CallbackQuery, state: FSMContext) -> None:
    try:
        amount = float(callback.data.split(":")[2])
    except (IndexError, ValueError):
        await callback.answer()
        return
    await _process_amount(callback, state, amount)
    await callback.answer()


# --------------------------- মাধ্যম বাছাই ---------------------------
@router.callback_query(CustomerDeposit.choosing_method, F.data.startswith("dep:"))
async def deposit_method(callback: CallbackQuery, state: FSMContext) -> None:
    method = callback.data.split(":", 1)[1]
    _LAST_METHOD[callback.from_user.id] = method
    await state.update_data(method=method)
    await _show_amount(callback, state)
    await callback.answer()


# --------------------------- অ্যামাউন্ট প্রসেস ---------------------------
async def _process_amount(event, state: FSMContext, amount: float) -> None:
    min_deposit = await settings_service.get_min_deposit()
    data = await state.get_data()
    method = data.get("method", "Cash")
    if amount < min_deposit:
        await state.set_state(CustomerDeposit.waiting_amount)
        await show_screen(
            event,
            state,
            _amount_text(method)
            + f"\n\n⚠ সর্বনিম্ন ডিপোজিট {date_utils.fmt_money(min_deposit)}।",
            reply_markup=deposit_amount_kb(back_data="dep:back:method"),
        )
        return
    await state.update_data(amount=amount)
    if method == "Cash":
        await _show_confirm(event, state)
    else:
        await _show_proof(event, state)


@router.message(CustomerDeposit.waiting_amount, ~_INTERRUPT)
async def deposit_amount_typed(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await delete_user_message(message)
        await _cancel(message, state, "❌ ডিপোজিট বাতিল করা হয়েছে।")
        return
    try:
        amount = _parse_amount(message.text)
    except validators.ValidationError as exc:
        await delete_user_message(message)
        data = await state.get_data()
        method = data.get("method", "Cash")
        await show_screen(
            message,
            state,
            _amount_text(method) + f"\n\n⚠ {exc}",
            reply_markup=deposit_amount_kb(back_data="dep:back:method"),
        )
        return
    await delete_user_message(message)
    await _process_amount(message, state, amount)


# --------------------------- প্রমাণ ধাপ ---------------------------
@router.callback_query(CustomerDeposit.waiting_proof, F.data == "deposit:skipproof")
async def deposit_skip_proof(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(dep_txn=None, dep_proof_file_id=None)
    await _show_number(callback, state)
    await callback.answer()


@router.callback_query(CustomerDeposit.waiting_proof, F.data == "deposit:cantpay")
async def deposit_cant_pay(callback: CallbackQuery, state: FSMContext) -> None:
    await _cancel(
        callback,
        state,
        "❌ ডিপোজিট বাতিল করা হয়েছে।\n\n"
        "ডিপোজিট করতে বা অন্য কোনো সমস্যা হয়ে থাকলে সাপোর্ট সেন্টারে যোগাযোগ করুন।",
    )
    await callback.answer()


@router.message(CustomerDeposit.waiting_proof, ~_INTERRUPT)
async def deposit_proof(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await delete_user_message(message)
        await _cancel(message, state, "❌ ডিপোজিট বাতিল করা হয়েছে।")
        return
    txn = (message.text or "").strip()
    if txn.lower() in ("skip", "-", "না"):
        txn = None
    if not txn and message.caption:
        txn = message.caption.strip()
    proof_file_id = message.photo[-1].file_id if message.photo else None
    # ছবির file_id মনে রেখে ইউজারের পাঠানো ছবিটি মুছে ফেলি — চ্যাট পরিষ্কার থাকে;
    # পরে অ্যাডমিনকে এই file_id দিয়েই ছবিটি পাঠানো হবে।
    await delete_user_message(message)
    await state.update_data(dep_txn=(txn or None), dep_proof_file_id=proof_file_id)
    await _show_number(message, state)


# --------------------------- প্রেরকের নম্বর ---------------------------
@router.message(CustomerDeposit.waiting_number, ~_INTERRUPT)
async def deposit_number(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await delete_user_message(message)
        await _cancel(message, state, "❌ ডিপোজিট বাতিল করা হয়েছে।")
        return
    try:
        number = validators.validate_sender_number(message.text or "")
    except validators.ValidationError as exc:
        await delete_user_message(message)
        await show_screen(
            message,
            state,
            _number_text() + f"\n\n⚠ {exc}",
            reply_markup=back_kb("dep:back:proof"),
        )
        return
    await delete_user_message(message)
    await state.update_data(sender_number=number)
    await _show_confirm(message, state)


# --------------------------- চূড়ান্ত নিশ্চিতকরণ ---------------------------
@router.callback_query(CustomerDeposit.waiting_confirm, F.data == "dep:confirm")
async def deposit_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    method = data.get("method", "Cash")
    amount = float(data.get("amount", 0.0))
    txn = data.get("dep_txn")
    proof_file_id = data.get("dep_proof_file_id")
    sender = data.get("sender_number")
    user = callback.from_user
    customer = await _resolve(user.id)
    if await _deny_if_banned(callback, customer):
        return
    req = await request_service.create_deposit(
        customer_id=customer.id if customer else None,
        telegram_id=user.id,
        username=user.username,
        name=user.full_name,
        amount=amount,
        method=method,
        transaction_id=txn,
        sender_number=sender,
    )
    await show_screen(
        callback,
        state,
        "✅ আপনার ডিপোজিট অনুরোধ অ্যাডমিনের কাছে পাঠানো হয়েছে।\n"
        "অ্যাডমিন অনুমোদন করলে টাকা আপনার ব্যালান্সে যোগ হবে।",
    )
    await state.clear()
    await _notify_owner_request(callback.bot, req, proof_file_id=proof_file_id)
    await callback.answer("পাঠানো হয়েছে ✅")
