"""গ্রাহক প্যানেল — /start, নিজের তথ্য, আমার আইডি, ব্যালান্স,
ডিপোজিট, প্যাকেজ কেনা, রিডিম কোড ও সাপোর্ট।

এই router সবশেষে রেজিস্টার হয়; owner-এর মেসেজ আগেই হ্যান্ডল হয়ে যায়।
অনিবন্ধিত গ্রাহকও সব অপশন দেখতে পারে।
"""

from __future__ import annotations

from datetime import datetime, timedelta

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.keyboards.customer_kb import (
    CM_BALANCE,
    CM_BUY,
    CM_CONTACT,
    CM_DEPOSIT,
    CM_HISTORY,
    CM_MYID,
    CM_PACKAGE,
    CM_REDEEM,
    buy_credit_kb,
    buy_mac_kb,
    customer_menu,
    customer_pay_methods_kb,
    due_pay_kb,
    deposit_methods_kb,
    deposit_proof_kb,
    my_id_kb,
    packages_buy_kb,
    skip_kb,
)
from app.keyboards.owner_kb import request_action_kb
from app.services.customer_service import customer_service
from app.services.package_service import package_service
from app.services.payment_service import payment_service
from app.services.redeem_service import redeem_service
from app.services.request_service import request_service
from app.services.settings_service import settings_service
from app.services.text_service import tx
from app.states.states import (
    CustomerBuy,
    CustomerDeposit,
    CustomerRedeem,
    CustomerSetPhone,
)
from app.utils import date_utils, validators
from app.utils.formatters import (
    customer_self_package,
    payment_row,
    purchase_summary,
    request_card,
)
from app.utils.logger import get_logger

log = get_logger(__name__)

router = Router(name="customer-panel")

# মূল মেনুর সব বাটন টেক্সট। যেকোনো FSM ধাপে এগুলো চাপলে (বা / কমান্ড দিলে)
# ধাপটি বাতিল হয়ে মূল মেনু কাজ করবে — নাহলে ইউজার ডিপোজিট ইত্যাদিতে আটকে যায়।
_MENU_TEXTS = {
    CM_BALANCE,
    CM_DEPOSIT,
    CM_BUY,
    CM_MYID,
    CM_REDEEM,
    CM_PACKAGE,
    CM_HISTORY,
    CM_CONTACT,
}


def _is_interrupt(text: str | None) -> bool:
    """টেক্সটটি মেনু-বাটন বা কমান্ড হলে True (FSM ধাপ ছেড়ে দিতে হবে)।"""
    if not text:
        return False
    return text in _MENU_TEXTS or text.startswith("/")


_INTERRUPT = F.text.func(_is_interrupt)
_CANCEL_WORDS = {"cancel", "/cancel", "বাতিল"}


async def _resolve(telegram_id: int):
    """telegram_id দিয়ে গ্রাহক বের করে।"""
    return await customer_service.get_by_telegram_id(telegram_id)


async def _ensure_account(user):
    """গ্রাহকের অ্যাকাউন্ট না থাকলে স্বয়ংক্রিয়ভাবে খোলে —
    যেন অনিবন্ধিত গ্রাহকও ডিপোজিট/প্যাকেজ কিনতে পারে।"""
    return await customer_service.get_or_create_account(
        user.id, user.full_name, user.username
    )


def _is_cancel(message: Message) -> bool:
    return (message.text or "").strip().lower() in _CANCEL_WORDS


@router.message(CommandStart())
async def customer_start(message: Message, state: FSMContext) -> None:
    """গ্রাহকের /start (owner না হলে এখানে আসবে)।"""
    await state.clear()  # যেকোনো আটকে থাকা ফ্লো রিসেট — /start সবসময় মেনুতে ফেরায়
    if message.from_user.id == settings.owner_id:
        return  # owner dashboard router আগেই হ্যান্ডল করে
    user = message.from_user
    customer = await _resolve(user.id)
    # রেকর্ড না থাকলেও একটি অ্যাকাউন্ট তৈরি করি — যেন শুধু /start করা ইউজারও
    # ইউজার ম্যানেজমেন্টে (🔴 লাল) দেখা যায়।
    await _ensure_account(user)
    has_connection = customer is not None and (
        customer.package_name not in (None, "", "—", "-")
    )
    if has_connection:
        await customer_service.touch_telegram_profile(
            user.id, user.username, user.full_name
        )
        await message.answer(
            tx("start.welcome_registered", name=customer.name),
            reply_markup=customer_menu(True),
        )
        return
    await message.answer(
        tx("start.welcome_new"),
        reply_markup=customer_menu(False),
    )


_BANNED_NOTICE = (
    "⛔ আপনাকে অ্যাডমিন ব্যান করেছেন।\n"
    "আপাতত অ্যাডমিনের কাছে কোনো অনুরোধ (ডিপোজিট/প্যাকেজ) পাঠানো যাবে না।"
)


def _is_banned(customer) -> bool:
    """গ্রাহক এডমিন কর্তৃক ব্যান হলে True।"""
    return bool(customer and getattr(customer, "is_banned", False))


async def _deny_if_banned(event, customer) -> bool:
    """ব্যান করা গ্রাহক অনুরোধ পাঠাতে চাইলে নোটিশ দিয়ে True ফেরত দেয়।"""
    if not _is_banned(customer):
        return False
    if isinstance(event, CallbackQuery):
        await event.answer(_BANNED_NOTICE, show_alert=True)
    else:
        await event.answer(_BANNED_NOTICE)
    return True


# ===================== নিজের নম্বর সেট =====================
@router.callback_query(F.data == "cust:setphone")
async def set_phone_start(callback: CallbackQuery, state: FSMContext) -> None:
    customer = await _ensure_account(callback.from_user)
    if (getattr(customer, "phone", "") or "").strip():
        await callback.answer(
            "আপনার নম্বর আগেই সেট করা আছে — এটি আর পরিবর্তন করা যাবে না।",
            show_alert=True,
        )
        return
    await state.set_state(CustomerSetPhone.waiting_phone)
    await callback.message.answer(tx("myid.set_phone_prompt"))
    await callback.answer()


@router.message(CustomerSetPhone.waiting_phone, ~_INTERRUPT)
async def set_phone_save(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।")
        return
    customer = await _ensure_account(message.from_user)
    if (getattr(customer, "phone", "") or "").strip():
        await state.clear()
        await message.answer("আপনার নম্বর আগেই সেট করা আছে — এটি আর পরিবর্তন করা যাবে না।")
        return
    try:
        phone = validators.validate_sender_number(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    await customer_service.update_fields(customer.id, phone=phone)
    await state.clear()
    await message.answer(tx("myid.set_phone_done", phone=date_utils.to_bn_digits(phone)))


# ===================== ব্যালান্স / ডিপোজিট / প্যাকেজ কেনা =====================
async def _notify_owner_request(bot, req, proof_chat_id=None, proof_message_id=None, proof_file_id=None) -> None:
    """অনুরোধটি owner কে Approve/Reject বাটনসহ পাঠায় (প্রুফ স্ক্রিনশট থাকলে সহ)।"""
    card = request_card(req)
    kb = request_action_kb(req.id)
    if proof_file_id:
        try:
            await bot.send_photo(settings.owner_id, proof_file_id, caption=card, reply_markup=kb)
            return
        except Exception as exc:
            log.warning("Proof photo send failed, fallback: %s", exc)
            try:
                await bot.send_photo(settings.owner_id, proof_file_id, caption="🧾 গ্রাহকের পাঠানো পেমেন্ট স্ক্রিনশট")
            except Exception as exc2:
                log.warning("Proof photo resend failed: %s", exc2)
    has_photo = proof_chat_id is not None and proof_message_id is not None
    if has_photo:
        try:
            await bot.copy_message(
                chat_id=settings.owner_id,
                from_chat_id=proof_chat_id,
                message_id=proof_message_id,
                caption=card,
                reply_markup=kb,
            )
            return
        except Exception as exc:
            log.warning("Proof+card send failed, fallback: %s", exc)
            try:
                await bot.copy_message(
                    chat_id=settings.owner_id,
                    from_chat_id=proof_chat_id,
                    message_id=proof_message_id,
                    caption="🧾 গ্রাহকের পাঠানো পেমেন্ট স্ক্রিনশট",
                )
            except Exception as exc2:
                log.warning("Proof copy failed: %s", exc2)
    try:
        await bot.send_message(settings.owner_id, card, reply_markup=kb)
    except Exception as exc:
        log.warning("Owner request notify failed: %s", exc)


@router.callback_query(F.data == "cust:duepay")
async def due_pay_info(callback: CallbackQuery) -> None:
    customer = await _ensure_account(callback.from_user)
    due = float(customer.due_amount or 0.0) if customer is not None else 0.0
    if due <= 0:
        await callback.answer("আপনার কোনো বকেয়া নেই।", show_alert=True)
        return
    await callback.message.answer(
        tx("balance.duepay_info", due=date_utils.fmt_money(due))
    )
    await callback.answer()


@router.callback_query(F.data == "dep:cancel")
async def deposit_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.answer("\u09ac\u09be\u09a4\u09bf\u09b2 \u0995\u09b0\u09be \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964", reply_markup=customer_menu(True))
    await callback.answer()


@router.callback_query(CustomerDeposit.choosing_method, F.data.startswith("dep:"))
async def deposit_method(callback: CallbackQuery, state: FSMContext) -> None:
    method = callback.data.split(":", 1)[1]
    await state.update_data(method=method)
    await state.set_state(CustomerDeposit.waiting_amount)
    await callback.message.answer(
        f"\U0001f4b5 \u09ae\u09be\u09a7\u09cd\u09af\u09ae: <b>{method}</b>\n\n\u0995\u09a4 \u099f\u09be\u0995\u09be \u099c\u09ae\u09be \u09a6\u09bf\u09a4\u09c7 \u099a\u09be\u09a8, \u09b8\u09c7\u0987 \u09aa\u09b0\u09bf\u09ae\u09be\u09a3 \u09b2\u09bf\u0996\u09c1\u09a8:"
    )
    await callback.answer()


@router.message(CustomerDeposit.waiting_amount, ~_INTERRUPT)
async def deposit_amount(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("\u09ac\u09be\u09a4\u09bf\u09b2\u0964", reply_markup=customer_menu(True))
        return
    try:
        amount = validators.validate_amount(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    min_deposit = await settings_service.get_min_deposit()
    if amount < min_deposit:
        await message.answer(
            f"⚠ সর্বনিম্ন ডিপোজিট {date_utils.fmt_money(min_deposit)}। অনুগ্রহ করে আবার পরিমাণ লিখুন:"
        )
        return
    data = await state.get_data()
    method = data.get("method", "Cash")
    await state.update_data(amount=amount)
    if method == "Cash":
        await _create_deposit_and_notify(message, state, transaction_id=None)
        return
    number = await settings_service.get_payment_number(method)
    await state.set_state(CustomerDeposit.waiting_proof)
    if number:
        pay_line = (
            f"📲 নিচের {method} নম্বরে {date_utils.fmt_money(amount)} পাঠান:\n"
            f"<code>{number}</code>\n\n"
        )
    else:
        pay_line = (
            f"⚠ এই মুহূর্তে {method} নম্বর সেট করা নেই — সাপোর্ট টিমের সাথে যোগাযোগ করুন।\n\n"
        )
    await message.answer(
        pay_line
        + "টাকা পাঠানোর পর পেমেন্টের স্ক্রিনশট, অথবা Transaction ID পাঠান।\n"
        "(না থাকলে নিচের 'স্কিপ' বাটনে চাপুন — এরপর নম্বর চাওয়া হবে)",
        reply_markup=deposit_proof_kb(),
    )


@router.message(CustomerDeposit.waiting_proof, ~_INTERRUPT)
async def deposit_proof(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("\u09ac\u09be\u09a4\u09bf\u09b2\u0964", reply_markup=customer_menu(True))
        return
    txn = (message.text or "").strip()
    if txn.lower() in ("skip", "-", "\u09a8\u09be"):
        txn = None
    if not txn and message.caption:
        txn = message.caption.strip()
    proof_chat = message.chat.id if message.photo else None
    proof_msg_id = message.message_id if message.photo else None
    await state.update_data(
        dep_txn=(txn or None),
        dep_proof_chat=proof_chat,
        dep_proof_msg=proof_msg_id,
    )
    await state.set_state(CustomerDeposit.waiting_number)
    await message.answer(
        "📱 আপনি যে নম্বর থেকে টাকা পাঠিয়েছেন সেই নম্বরটি লিখুন (আবশ্যক):"
    )


@router.message(CustomerDeposit.waiting_number, ~_INTERRUPT)
async def deposit_number(message: Message, state: FSMContext) -> None:
    """ডিপোজিটে প্রেরকের নম্বর (আবশ্যক) — এরপর অনুরোধ তৈরি ও owner কে পাঠানো।"""
    if _is_cancel(message):
        await state.clear()
        await message.answer("বাতিল।", reply_markup=customer_menu(True))
        return
    try:
        number = validators.validate_sender_number(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    if not number:
        await message.answer(
            "⚠ যে নম্বর থেকে টাকা পাঠিয়েছেন সেটি অবশ্যই দিতে হবে।\n"
            "অনুগ্রহ করে সঠিক নম্বরটি লিখুন:"
        )
        return
    data = await state.get_data()
    await _create_deposit_and_notify(
        message,
        state,
        transaction_id=data.get("dep_txn"),
        proof_chat_id=data.get("dep_proof_chat"),
        proof_message_id=data.get("dep_proof_msg"),
        sender_number=number,
    )


async def _create_deposit_and_notify(
    message: Message,
    state: FSMContext,
    transaction_id,
    proof_chat_id=None,
    proof_message_id=None,
    sender_number=None,
) -> None:
    data = await state.get_data()
    method = data.get("method", "Cash")
    amount = float(data.get("amount", 0.0))
    await state.clear()
    user = message.from_user
    customer = await _resolve(user.id)
    if await _deny_if_banned(message, customer):
        return
    req = await request_service.create_deposit(
        customer_id=customer.id if customer else None,
        telegram_id=user.id,
        username=user.username,
        name=user.full_name,
        amount=amount,
        method=method,
        transaction_id=transaction_id,
        sender_number=sender_number,
    )
    await message.answer(
        "\u2705 \u0986\u09aa\u09a8\u09be\u09b0 \u09a1\u09bf\u09aa\u09cb\u099c\u09bf\u099f \u0985\u09a8\u09c1\u09b0\u09cb\u09a7 অ্যাডমিনের কাছে \u09aa\u09be\u09a0\u09be\u09a8\u09cb \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964\n"
        "অ্যাডমিন অনুমোদন করলে \u099f\u09be\u0995\u09be \u0986\u09aa\u09a8\u09be\u09b0 \u09ac\u09cd\u09af\u09be\u09b2\u09be\u09a8\u09cd\u09b8\u09c7 \u09af\u09cb\u0997 \u09b9\u09ac\u09c7\u0964",
        reply_markup=customer_menu(True),
    )
    await _notify_owner_request(
        message.bot,
        req,
        proof_chat_id=proof_chat_id,
        proof_message_id=proof_message_id,
    )


@router.callback_query(F.data == "buy:cancel")
async def buy_cancel(callback: CallbackQuery) -> None:
    await callback.message.answer("\u09ac\u09be\u09a4\u09bf\u09b2 \u0995\u09b0\u09be \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964")
    await callback.answer()


async def _mac_prompt(package):
    """MAC চাওয়ার মেসেজ ও কীবোর্ড (অ্যাডমিন-এডিটযোগ্য টেক্সট + ঐচ্ছিক ভিডিও বাটন)।"""
    ask_text = await settings_service.get_mac_ask_text()
    video_url = await settings_service.get_mac_video_url()
    video_label = await settings_service.get_mac_video_label()
    skip_label = await settings_service.get_mac_skip_label()
    text = (
        f"📦 <b>{package.name}</b> ({date_utils.fmt_money(package.price)})\n\n"
        f"{ask_text}"
    )
    return text, buy_mac_kb(video_url, video_label, skip_label, "buymac:skip")


@router.callback_query(F.data.startswith("buy:"))
async def buy_package(callback: CallbackQuery, state: FSMContext) -> None:
    customer = await _ensure_account(callback.from_user)
    try:
        package_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer()
        return
    package = await package_service.get(package_id)
    if package is None or not package.is_active:
        await callback.answer("\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c\u099f\u09bf \u09aa\u09be\u0993\u09af\u09bc\u09be \u09af\u09be\u09af\u09bc\u09a8\u09bf\u0964", show_alert=True)
        return
    balance = float(customer.balance or 0.0)
    price = float(package.price)
    if float(customer.due_amount or 0.0) > 0:
        await callback.answer(
            "আগের বকেয়া পরিশোধ না করা পর্যন্ত নতুন প্যাকেজ নেওয়া যাবে না।",
            show_alert=True,
        )
        return
    if balance < price:
        min_pay = price * float(settings.credit_min_pay_ratio)
        if balance < min_pay:
            await callback.answer(
                f"এই প্যাকেজটি কিনতে আরও {date_utils.fmt_money(price - balance)} ডিপোজিট করুন। "
                f"পুরো টাকা না থাকলে বাকিতে নিতে হলেও কমপক্ষে ৫০% অর্থাৎ {date_utils.fmt_money(min_pay)} থাকতে হবে।",
                show_alert=True,
            )
            return
        due = price - balance
        await callback.message.answer(
            f"📦 <b>{package.name}</b> ({date_utils.fmt_money(price)})\n\n"
            f"💰 আপনার ব্যালান্স: {date_utils.fmt_money(balance)}\n"
            "ব্যালান্স প্যাকেজের দামের চেয়ে কম।\n\n"
            f"🧾 বাকিতে নিলে এখন {date_utils.fmt_money(balance)} কাটা হবে, "
            f"বাকি {date_utils.fmt_money(due)} বকেয়া থাকবে।\n"
            "নিচের বাটনে চাপুন:",
            reply_markup=buy_credit_kb(package_id),
        )
        await callback.answer()
        return
    await state.update_data(package_id=package_id)
    await state.set_state(CustomerBuy.waiting_mac)
    _mac_text, _mac_kb = await _mac_prompt(package)
    await callback.message.answer(_mac_text, reply_markup=_mac_kb)
    await callback.answer()


@router.callback_query(F.data.startswith("buycredit:"))
async def buy_credit(callback: CallbackQuery, state: FSMContext) -> None:
    customer = await _ensure_account(callback.from_user)
    if customer is None:
        await callback.answer("আগে আপনার সংযোগ থাকতে হবে।", show_alert=True)
        return
    try:
        package_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer()
        return
    package = await package_service.get(package_id)
    if package is None or not package.is_active:
        await callback.answer("প্যাকেজটি আর পাওয়া যাচ্ছে না।", show_alert=True)
        return
    balance = float(customer.balance or 0.0)
    price = float(package.price)
    if float(customer.due_amount or 0.0) > 0:
        await callback.answer(
            "আগের বকেয়া পরিশোধ না করা পর্যন্ত নতুন প্যাকেজ নেওয়া যাবে না।",
            show_alert=True,
        )
        return
    min_pay = price * float(settings.credit_min_pay_ratio)
    if balance < min_pay:
        await callback.answer(
            f"এই প্যাকেজটি কিনতে আরও {date_utils.fmt_money(price - balance)} ডিপোজিট করুন। "
            f"পুরো টাকা না থাকলে বাকিতে নিতে হলেও কমপক্ষে ৫০% অর্থাৎ {date_utils.fmt_money(min_pay)} থাকতে হবে।",
            show_alert=True,
        )
        return
    await state.update_data(package_id=package_id, is_credit=True)
    await state.set_state(CustomerBuy.waiting_mac)
    _mac_text, _mac_kb = await _mac_prompt(package)
    await callback.message.answer(_mac_text, reply_markup=_mac_kb)
    await callback.answer()


# ===================== Reply Keyboard মেনু (টেক্সট বাটন) =====================
# গ্রাহকের নিচের স্থায়ী মেনুর বাটনগুলো টেক্সট পাঠায়; এখানে সেই টেক্সট ধরা হয়।
@router.message(F.text == CM_BALANCE)
async def menu_balance(message: Message, state: FSMContext) -> None:
    await state.clear()
    customer = await _ensure_account(message.from_user)
    if customer is None:
        await message.answer(
            "\u0986\u09aa\u09a8\u09be\u09b0 \u098f\u0996\u09a8\u09cb \u0995\u09cb\u09a8\u09cb \u098f\u0995\u09be\u0989\u09a8\u09cd\u099f \u09a8\u09c7\u0987\u0964 \u09aa\u09cd\u09b0\u09a5\u09ae\u09c7 \u09b8\u0982\u09af\u09cb\u0997\u09c7\u09b0 \u0985\u09a8\u09c1\u09b0\u09cb\u09a7 \u09aa\u09be\u09a0\u09be\u09a8\u0964"
        )
        return
    text = tx("balance.show", balance=date_utils.fmt_money(customer.balance))
    due = float(customer.due_amount or 0.0)
    if due > 0:
        text += tx("balance.due_extra", due=date_utils.fmt_money(due))
        await message.answer(text, reply_markup=due_pay_kb())
    else:
        await message.answer(text)


@router.message(F.text == CM_DEPOSIT)
async def menu_deposit(message: Message, state: FSMContext) -> None:
    customer = await _ensure_account(message.from_user)
    if customer is None:
        await message.answer(
            "\u099f\u09be\u0995\u09be \u099c\u09ae\u09be \u09a6\u09bf\u09a4\u09c7 \u09b9\u09b2\u09c7 \u09aa\u09cd\u09b0\u09a5\u09ae\u09c7 \u0986\u09aa\u09a8\u09be\u09b0 \u09b8\u0982\u09af\u09cb\u0997 \u09a5\u09be\u0995\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964 \u09ae\u09c7\u09a8\u09c1 \u09a5\u09c7\u0995\u09c7 \u09b8\u0982\u09af\u09cb\u0997\u09c7\u09b0 \u0985\u09a8\u09c1\u09b0\u09cb\u09a7 \u09aa\u09be\u09a0\u09be\u09a8\u0964"
        )
        return
    await state.set_state(CustomerDeposit.choosing_method)
    await message.answer(
        "\U0001f4b5 <b>\u099f\u09be\u0995\u09be \u099c\u09ae\u09be</b>\n\n\u0995\u09cb\u09a8 \u09ae\u09be\u09a7\u09cd\u09af\u09ae\u09c7 \u099f\u09be\u0995\u09be \u09aa\u09be\u09a0\u09be\u09ac\u09c7\u09a8 \u09a4\u09be \u09ac\u09c7\u099b\u09c7 \u09a8\u09bf\u09a8\u0983",
        reply_markup=deposit_methods_kb(await settings_service.method_names(), await settings_service.is_cash_enabled()),
    )


@router.message(F.text == CM_BUY)
async def menu_buy(message: Message, state: FSMContext) -> None:
    await state.clear()
    customer = await _ensure_account(message.from_user)
    if customer is None:
        await message.answer(
            "\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u0995\u09bf\u09a8\u09a4\u09c7 \u09b9\u09b2\u09c7 \u09aa\u09cd\u09b0\u09a5\u09ae\u09c7 \u0986\u09aa\u09a8\u09be\u09b0 \u09b8\u0982\u09af\u09cb\u0997 \u09a5\u09be\u0995\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964"
        )
        return
    packages = await package_service.list_active()
    if not packages:
        await message.answer(
            "\u098f\u0987 \u09ae\u09c1\u09b9\u09c2\u09b0\u09cd\u09a4\u09c7 \u0995\u09cb\u09a8\u09cb \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09a8\u09c7\u0987\u0964 সাপোর্ট টিমের সাথে যোগাযোগ করুন\u0964"
        )
        return
    text = (
        "\U0001f6d2 <b>\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u0995\u09bf\u09a8\u09c1\u09a8</b>\n\n"
        f"\U0001f4b0 \u0986\u09aa\u09a8\u09be\u09b0 \u09ac\u09cd\u09af\u09be\u09b2\u09be\u09a8\u09cd\u09b8: {date_utils.fmt_money(customer.balance)}\n\n"
        "\u09a8\u09bf\u099a \u09a5\u09c7\u0995\u09c7 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09ac\u09c7\u099b\u09c7 \u09a8\u09bf\u09a8\u0983"
    )
    await message.answer(text, reply_markup=packages_buy_kb(packages))


@router.message(F.text == CM_MYID)
async def menu_myid(message: Message, state: FSMContext) -> None:
    await state.clear()
    user = message.from_user
    await customer_service.touch_telegram_profile(user.id, user.username, user.full_name)
    customer = await _ensure_account(user)
    username = f"@{user.username}" if user.username else "নেই"
    raw_phone = (getattr(customer, "phone", "") or "").strip()
    phone_set = raw_phone != ""
    phone_display = date_utils.to_bn_digits(raw_phone) if phone_set else "সেট করা হয়নি"
    await message.answer(
        tx(
            "myid.card",
            name=user.full_name,
            username=username,
            id=user.id,
            phone=phone_display,
        ),
        reply_markup=my_id_kb(phone_set),
    )


@router.message(F.text == CM_PACKAGE)
async def menu_package(message: Message, state: FSMContext) -> None:
    await state.clear()
    customer = await _resolve(message.from_user.id)
    if customer is None:
        await message.answer(
            """📶 আপনি এখনো কোনো ওয়াইফাই সংযোগ নেননি।
প্যাকেজ কিনতে "📦 প্যাকেজ কিনুন" অপশনে ক্লিক করুন।"""
        )
        return
    purchases = await customer_service.get_purchases(customer.id)
    never_bought = (not purchases) and (customer.package_name in (None, "", "-", "—"))
    if never_bought:
        await message.answer(
            """📶 <b>আমার WiFi</b>

আপনি এখনো কোনো প্যাকেজ কিনেননি।
প্যাকেজ কিনতে "📦 প্যাকেজ কিনুন" অপশনে ক্লিক করুন।"""
        )
        return
    await message.answer(customer_self_package(customer) + purchase_summary(purchases))


@router.message(F.text == CM_HISTORY)
async def menu_history(message: Message, state: FSMContext) -> None:
    await state.clear()
    customer = await _resolve(message.from_user.id)
    if customer is None:
        await message.answer("\u0995\u09cb\u09a8\u09cb \u0987\u09a4\u09bf\u09b9\u09be\u09b8 \u09a8\u09c7\u0987\u0964")
        return
    payments = await payment_service.history(customer.id)
    if not payments:
        await message.answer("\u0986\u09aa\u09a8\u09be\u09b0 \u0995\u09cb\u09a8\u09cb \u09aa\u09c7\u09ae\u09c7\u09a8\u09cd\u099f \u0987\u09a4\u09bf\u09b9\u09be\u09b8 \u09a8\u09c7\u0987\u0964")
        return
    rows = "\n\n".join(payment_row(p) for p in payments)
    await message.answer(f"\U0001f4b3 <b>\u0986\u09aa\u09a8\u09be\u09b0 \u09aa\u09c7\u09ae\u09c7\u09a8\u09cd\u099f \u0987\u09a4\u09bf\u09b9\u09be\u09b8:</b>\n\n{rows}")


@router.message(F.text == CM_CONTACT)
async def menu_contact(message: Message, state: FSMContext) -> None:
    await state.clear()
    contact = settings.owner_contact or "\u2014"
    support_link = f'<a href="tg://user?id={settings.owner_id}">সাপোর্ট টিমের সাথে চ্যাট করুন</a>'
    await message.answer(
        tx("contact.center", contact=contact, support_link=support_link)
    )


@router.message(CustomerBuy.waiting_mac, ~_INTERRUPT)
async def buy_mac(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("বাতিল করা হয়েছে।", reply_markup=customer_menu(True))
        return
    raw_mac = (message.text or "").strip()
    if raw_mac.lower() in ("skip", "-", "না", "নাই"):
        mac = None
    else:
        try:
            mac = validators.validate_mac(raw_mac)
        except validators.ValidationError as exc:
            await message.answer(
                f"⚠ {exc}\n\nঅনুগ্রহ করে সঠিক ফরম্যাটে আবার MAC দিন, অথবা স্কিপ করুন।"
            )
            return
    data = await state.get_data()
    await state.clear()
    package_id = data.get("package_id")
    customer = await _ensure_account(message.from_user)
    package = await package_service.get(int(package_id)) if package_id else None
    if package is None or not package.is_active:
        await message.answer(
            "প্যাকেজটি আর পাওয়া যাচ্ছে না।", reply_markup=customer_menu(True)
        )
        return
    balance = float(customer.balance or 0.0)
    price = float(package.price)
    is_credit = bool(data.get("is_credit"))
    if not is_credit and balance < price:
        shortfall = price - balance
        await message.answer(
            f"আপনার ব্যালান্স যথেষ্ট নয়। আরও {date_utils.fmt_money(shortfall)} জমা দিন।",
            reply_markup=customer_menu(True),
        )
        return
    if is_credit and (float(customer.due_amount or 0.0) > 0 or balance < price * float(settings.credit_min_pay_ratio)):
        await message.answer(
            "বাকিতে নেওয়ার শর্ত পূরণ হয়নি। আগের বকেয়া পরিশোধ করুন অথবা নিম্নতম ৫০% ব্যালান্স রাখুন।",
            reply_markup=customer_menu(True),
        )
        return
    if await _deny_if_banned(message, customer):
        return
    req = await request_service.create_package(
        customer_id=customer.id,
        telegram_id=message.from_user.id,
        username=message.from_user.username,
        name=message.from_user.full_name,
        package=package,
        mac_address=mac,
        is_credit=is_credit,
        paid_now=(balance if is_credit else None),
        credit_due=((price - balance) if is_credit else None),
    )
    mac_line = f"\n🔌 MAC: <code>{mac}</code>" if mac else ""
    if is_credit:
        due = price - balance
        tail = (
            f"\n🧾 বাকিতে কেনা: অনুমোদন হলে এখন {date_utils.fmt_money(balance)} কাটা হবে, "
            f"{date_utils.fmt_money(due)} বকেয়া থাকবে।"
        )
    else:
        tail = "\nঅ্যাডমিন অনুমোদন করলে প্যাকেজ চালু হবে এবং ব্যালান্স থেকে টাকা কাটা হবে।"
    await message.answer(
        f"✅ <b>{package.name}</b> কেনার অনুরোধ অ্যাডমিনের কাছে পাঠানো হয়েছে।{mac_line}{tail}",
        reply_markup=customer_menu(True),
    )
    await _notify_owner_request(message.bot, req)


# ===================== রিডিম কোড =====================
_REDEEM_PROMPT = (
    "🎟 <b>রিডিম কোড</b>\n\n"
    "আপনার কাছে থাকা কোডটি লিখে পাঠান:\n"
    "<i>('বাতিল' লিখে বন্ধ করতে পারেন)</i>"
)


@router.message(F.text == CM_REDEEM)
async def menu_redeem(message: Message, state: FSMContext) -> None:
    await _ensure_account(message.from_user)
    await state.set_state(CustomerRedeem.waiting_code)
    await message.answer(tx("redeem.prompt"))


@router.message(CustomerRedeem.waiting_code, ~_INTERRUPT)
async def redeem_code(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("বাতিল করা হয়েছে।", reply_markup=customer_menu(True))
        return
    code = (message.text or "").strip()
    await state.clear()
    customer = await _ensure_account(message.from_user)
    result, redeem, updated = await redeem_service.redeem(
        code, customer.id, message.from_user.id
    )
    errors = {
        "not_found": "❌ কোডটি সঠিক নয়।",
        "inactive": "❌ এই কোডটি আর সক্রিয় নেই।",
        "exhausted": "❌ এই কোডের ব্যবহারসীমা শেষ হয়ে গেছে।",
        "already": "⚠ আপনি এই কোডটি আগেই ব্যবহার করেছেন।",
        "no_customer": "⚠ আপনার অ্যাকাউন্ট পাওয়া যায়নি।",
    }
    if result != "ok":
        await message.answer(
            errors.get(result, "⚠ কোডটি ব্যবহার করা যায়নি।"),
            reply_markup=customer_menu(True),
        )
        return
    amount = redeem.amount if redeem else 0.0
    new_balance = updated.balance if updated else customer.balance
    settled = float(getattr(updated, "last_settled", 0.0) or 0.0)
    due_line = ""
    if settled > 0:
        remaining_due = float(getattr(updated, "due_amount", 0.0) or 0.0)
        due_line = (
            f"\n🧾 বকেয়া কাটা হয়েছে: {date_utils.fmt_money(settled)}"
            f"\n❌ অবশিষ্ট বকেয়া: {date_utils.fmt_money(remaining_due)}"
        )
    await message.answer(
        tx("redeem.success", amount=date_utils.fmt_money(amount), due_line=due_line, balance=date_utils.fmt_money(new_balance)),
        reply_markup=customer_menu(True),
    )


# ===================== স্কিপ বাটন কলব্যাক =====================
@router.callback_query(CustomerBuy.waiting_mac, F.data == "buymac:skip")
async def buy_mac_skip(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    await state.clear()
    package_id = data.get("package_id")
    customer = await _ensure_account(callback.from_user)
    package = await package_service.get(int(package_id)) if package_id else None
    if package is None or not package.is_active:
        await callback.message.answer(
            "প্যাকেজটি আর পাওয়া যাচ্ছে না।", reply_markup=customer_menu(True)
        )
        await callback.answer()
        return
    balance = float(customer.balance or 0.0)
    price = float(package.price)
    is_credit = bool(data.get("is_credit"))
    if not is_credit and balance < price:
        shortfall = price - balance
        await callback.message.answer(
            f"আপনার ব্যালান্স যথেষ্ট নয়। আরও {date_utils.fmt_money(shortfall)} জমা দিন।",
            reply_markup=customer_menu(True),
        )
        await callback.answer()
        return
    if is_credit and (float(customer.due_amount or 0.0) > 0 or balance < price * float(settings.credit_min_pay_ratio)):
        await callback.message.answer(
            "বাকিতে নেওয়ার শর্ত পূরণ হয়নি। আগের বকেয়া পরিশোধ করুন অথবা নিম্নতম ৫০% ব্যালান্স রাখুন।",
            reply_markup=customer_menu(True),
        )
        await callback.answer()
        return
    if await _deny_if_banned(callback, customer):
        return
    req = await request_service.create_package(
        customer_id=customer.id,
        telegram_id=callback.from_user.id,
        username=callback.from_user.username,
        name=callback.from_user.full_name,
        package=package,
        mac_address=None,
        is_credit=is_credit,
        paid_now=(balance if is_credit else None),
        credit_due=((price - balance) if is_credit else None),
    )
    if is_credit:
        due = price - balance
        tail = (
            f"\n🧾 বাকিতে কেনা: অনুমোদন হলে এখন {date_utils.fmt_money(balance)} কাটা হবে, "
            f"{date_utils.fmt_money(due)} বকেয়া থাকবে।"
        )
    else:
        tail = "\nঅ্যাডমিন অনুমোদন করলে প্যাকেজ চালু হবে এবং ব্যালান্স থেকে টাকা কাটা হবে।"
    await callback.message.answer(
        f"✅ <b>{package.name}</b> কেনার অনুরোধ অ্যাডমিনের কাছে পাঠানো হয়েছে।{tail}",
        reply_markup=customer_menu(True),
    )
    await _notify_owner_request(callback.bot, req)
    await callback.answer()


@router.callback_query(CustomerDeposit.waiting_proof, F.data == "deposit:skipproof")
async def deposit_skip_proof(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(dep_txn=None, dep_proof_chat=None, dep_proof_msg=None)
    await state.set_state(CustomerDeposit.waiting_number)
    if callback.message is not None:
        await callback.message.answer(
            "📱 আপনি যে নম্বর থেকে টাকা পাঠিয়েছেন সেই নম্বরটি লিখুন (আবশ্যক):"
        )
    await callback.answer()


@router.callback_query(CustomerDeposit.waiting_proof, F.data == "deposit:cantpay")
async def deposit_cant_pay(callback: CallbackQuery, state: FSMContext) -> None:
    """'টাকা পাঠাতে পারি নি' — ডিপোজিট বাতিল করে সাপোর্টে যোগাযোগের বার্তা।"""
    await state.clear()
    if callback.message is not None:
        await callback.message.answer(
            "❌ ডিপোজিট বাতিল করা হয়েছে।\n\n"
            "ডিপোজিট করতে বা অন্য কোনো সমস্যা হয়ে থাকলে সাপোর্ট সেন্টারে যোগাযোগ করুন।",
            reply_markup=customer_menu(True),
        )
    await callback.answer()
