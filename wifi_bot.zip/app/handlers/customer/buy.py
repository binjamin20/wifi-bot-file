"""গ্রাহক প্যানেল — 'প্যাকেজ কিনুন' (buy) ফ্লো, স্মার্ট এক-স্ক্রিন সংস্করণ।

- পুরো ফ্লোতে একটিই বট-মেসেজ ('স্ক্রিন') থাকে; ধাপে ধাপে সেটিই edit হয়।
- প্রতিটি ধাপে '🔙 পিছনে' — এক ধাপ আগে ফেরা যায়।
- MAC ইনপুট/স্কিপ, বাকিতে কেনা, এবং সাবমিটের আগে নিশ্চিতকরণ সারাংশ।

এই router customer_panel-এর আগে রেজিস্টার হয়, তাই প্যাকেজ কেনা সংক্রান্ত সব
হ্যান্ডলিং এখান থেকেই হয়।
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.handlers.customer.panel import (
    _INTERRUPT,
    _deny_if_banned,
    _ensure_account,
    _is_cancel,
    _notify_owner_request,
)
from app.keyboards.customer_kb import (
    CM_BUY,
    back_kb,
    buy_credit_kb,
    buy_mac_kb,
    deposit_confirm_kb,
    packages_buy_kb,
)
from app.services.package_service import package_service
from app.services.request_service import request_service
from app.services.settings_service import settings_service
from app.states.states import CustomerBuy
from app.utils import date_utils, validators
from app.utils.logger import get_logger
from app.utils.nav import delete_user_message, show_screen

log = get_logger(__name__)

router = Router(name="customer-buy")

_SKIP_WORDS = ("skip", "-", "না", "নাই")


# --------------------------- স্ক্রিন হেল্পার ---------------------------
async def _show_list(event, state: FSMContext) -> None:
    customer = await _ensure_account(event.from_user)
    if customer is None:
        await show_screen(event, state, "প্যাকেজ কিনতে হলে প্রথমে আপনার সংযোগ থাকতে হবে।")
        await state.clear()
        return
    packages = await package_service.list_active()
    if not packages:
        await show_screen(
            event,
            state,
            "এই মুহূর্তে কোনো প্যাকেজ নেই। সাপোর্ট টিমের সাথে যোগাযোগ করুন।",
        )
        await state.clear()
        return
    text = (
        "🛒 <b>প্যাকেজ কিনুন</b>\n\n"
        f"💰 আপনার ব্যালান্স: {date_utils.fmt_money(customer.balance)}\n\n"
        "নিচ থেকে প্যাকেজ বেছে নিন:"
    )
    await state.set_state(CustomerBuy.choosing_package)
    await show_screen(event, state, text, reply_markup=packages_buy_kb(packages))


async def _mac_parts(state: FSMContext, error: str | None = None):
    data = await state.get_data()
    package = await package_service.get(int(data["package_id"]))
    ask_text = await settings_service.get_mac_ask_text()
    video_url = await settings_service.get_mac_video_url()
    video_label = await settings_service.get_mac_video_label()
    skip_label = await settings_service.get_mac_skip_label()
    head = f"📦 <b>{package.name}</b> ({date_utils.fmt_money(package.price)})\n\n"
    if error:
        head += f"⚠ {error}\n\n"
    kb = buy_mac_kb(video_url, video_label, skip_label, "buymac:skip", back_data="buy:back:list")
    return head + ask_text, kb


async def _show_mac(event, state: FSMContext) -> None:
    text, kb = await _mac_parts(state)
    await state.set_state(CustomerBuy.waiting_mac)
    await show_screen(event, state, text, reply_markup=kb)


async def _show_confirm(event, state: FSMContext) -> None:
    data = await state.get_data()
    package = await package_service.get(int(data["package_id"]))
    customer = await _ensure_account(event.from_user)
    balance = float(customer.balance or 0.0) if customer else 0.0
    price = float(package.price)
    is_credit = bool(data.get("is_credit"))
    mac = data.get("mac")
    lines = [
        "🧾 <b>কেনা নিশ্চিত করুন</b>",
        "",
        f"প্যাকেজ: <b>{package.name}</b>",
        f"দাম: <b>{date_utils.fmt_money(price)}</b>",
        f"মেয়াদ: <b>{date_utils.to_bn_digits(package.duration_days)} দিন</b>",
        (f"MAC: <code>{mac}</code>" if mac else "MAC: দেওয়া হয়নি"),
        "",
    ]
    if is_credit:
        due = price - balance
        lines.append(
            f"🧾 বাকিতে: অনুমোদন হলে এখন {date_utils.fmt_money(balance)} কাটা হবে, "
            f"{date_utils.fmt_money(due)} বকেয়া থাকবে।"
        )
    else:
        lines.append(f"💰 ব্যালান্স থেকে {date_utils.fmt_money(price)} কাটা হবে।")
    lines.append("")
    lines.append("সব ঠিক থাকলে নিচের বাটনে চাপুন:")
    await state.set_state(CustomerBuy.waiting_confirm)
    await show_screen(
        event,
        state,
        "\n".join(lines),
        reply_markup=deposit_confirm_kb(confirm_data="buy:confirm", back_data="buy:back:mac"),
    )


async def _cancel(event, state: FSMContext, text: str) -> None:
    await show_screen(event, state, text)
    await state.clear()


# --------------------------- এন্ট্রি ---------------------------
@router.message(F.text == CM_BUY)
async def menu_buy(message: Message, state: FSMContext) -> None:
    customer = await _ensure_account(message.from_user)
    if customer is None:
        await message.answer("প্যাকেজ কিনতে হলে প্রথমে আপনার সংযোগ থাকতে হবে।")
        return
    await state.clear()
    await _show_list(message, state)


# --------------------------- বাতিল ও পিছনে ---------------------------
@router.callback_query(F.data == "buy:cancel")
async def buy_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await _cancel(callback, state, "❌ বাতিল করা হয়েছে।")
    await callback.answer()


@router.callback_query(F.data == "buy:back:list")
async def buy_back_list(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_list(callback, state)
    await callback.answer()


@router.callback_query(F.data == "buy:back:mac")
async def buy_back_mac(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_mac(callback, state)
    await callback.answer()


# --------------------------- চূড়ান্ত নিশ্চিতকরণ ---------------------------
@router.callback_query(CustomerBuy.waiting_confirm, F.data == "buy:confirm")
async def buy_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    customer = await _ensure_account(callback.from_user)
    if customer is None:
        await _cancel(callback, state, "আপনার অ্যাকাউন্ট পাওয়া যায়নি।")
        await callback.answer()
        return
    package_id = data.get("package_id")
    package = await package_service.get(int(package_id)) if package_id else None
    if package is None or not package.is_active:
        await _cancel(callback, state, "প্যাকেজটি আর পাওয়া যাচ্ছে না।")
        await callback.answer()
        return
    balance = float(customer.balance or 0.0)
    price = float(package.price)
    is_credit = bool(data.get("is_credit"))
    mac = data.get("mac")
    if float(customer.due_amount or 0.0) > 0:
        await _cancel(
            callback,
            state,
            "❌ আগের বকেয়া পরিশোধ না করা পর্যন্ত নতুন প্যাকেজ নেওয়া যাবে না।",
        )
        await callback.answer()
        return
    if not is_credit and balance < price:
        await _cancel(
            callback,
            state,
            f"আপনার ব্যালান্স যথেষ্ট নয়। আরও {date_utils.fmt_money(price - balance)} জমা দিন।",
        )
        await callback.answer()
        return
    if is_credit and balance < price * float(settings.credit_min_pay_ratio):
        await _cancel(
            callback,
            state,
            "বাকিতে নেওয়ার শর্ত পূরণ হয়নি। নিম্নতম ৫০% ব্যালান্স রাখুন।",
        )
        await callback.answer()
        return
    if await _deny_if_banned(callback, customer):
        return
    req = await request_service.create_package(
        customer_id=customer.id,
        telegram_id=callback.from_user.id,
        username=callback.from_user.username,
        name=callback.from_user.full_name,
        package=package,
        mac_address=mac,
        is_credit=is_credit,
        paid_now=(balance if is_credit else None),
        credit_due=((price - balance) if is_credit else None),
    )
    mac_line = f"\n🔌 MAC: <code>{mac}</code>" if mac else ""
    if is_credit:
        due = price - balance
        tail = (
            f"\n🧾 বাকিতে কেনা: অনুমোদন হলে এখন {date_utils.fmt_money(balance)} কাটা হবে, "
            f"{date_utils.fmt_money(due)} বকেয়া থাকবে।"
        )
    else:
        tail = "\nঅ্যাডমিন অনুমোদন করলে প্যাকেজ চালু হবে এবং ব্যালান্স থেকে টাকা কাটা হবে।"
    await show_screen(
        callback,
        state,
        f"✅ <b>{package.name}</b> কেনার অনুরোধ অ্যাডমিনের কাছে পাঠানো হয়েছে।{mac_line}{tail}",
    )
    await state.clear()
    await _notify_owner_request(callback.bot, req)
    await callback.answer("পাঠানো হয়েছে ✅")


# --------------------------- বাকিতে কেনা ---------------------------
@router.callback_query(F.data.startswith("buycredit:"))
async def buy_credit(callback: CallbackQuery, state: FSMContext) -> None:
    customer = await _ensure_account(callback.from_user)
    if customer is None:
        await callback.answer("আগে আপনার সংযোগ থাকতে হবে।", show_alert=True)
        return
    try:
        package_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer()
        return
    package = await package_service.get(package_id)
    if package is None or not package.is_active:
        await callback.answer("প্যাকেজটি আর পাওয়া যাচ্ছে না।", show_alert=True)
        return
    balance = float(customer.balance or 0.0)
    price = float(package.price)
    if float(customer.due_amount or 0.0) > 0:
        await callback.answer(
            "আগের বকেয়া পরিশোধ না করা পর্যন্ত নতুন প্যাকেজ নেওয়া যাবে না।",
            show_alert=True,
        )
        return
    if balance < price * float(settings.credit_min_pay_ratio):
        await callback.answer(
            "বাকিতে নিতে হলেও কমপক্ষে ৫০% ব্যালান্স থাকতে হবে।",
            show_alert=True,
        )
        return
    await state.update_data(package_id=package_id, is_credit=True, mac=None)
    await _show_mac(callback, state)
    await callback.answer()


# --------------------------- প্যাকেজ বাছাই ---------------------------
@router.callback_query(CustomerBuy.choosing_package, F.data.startswith("buy:"))
async def buy_package(callback: CallbackQuery, state: FSMContext) -> None:
    customer = await _ensure_account(callback.from_user)
    if customer is None:
        await callback.answer("আগে আপনার সংযোগ থাকতে হবে।", show_alert=True)
        return
    try:
        package_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer()
        return
    package = await package_service.get(package_id)
    if package is None or not package.is_active:
        await callback.answer("প্যাকেজটি পাওয়া যায়নি।", show_alert=True)
        return
    balance = float(customer.balance or 0.0)
    price = float(package.price)
    if float(customer.due_amount or 0.0) > 0:
        await show_screen(
            callback,
            state,
            "❌ আগের বকেয়া পরিশোধ না করা পর্যন্ত নতুন প্যাকেজ নেওয়া যাবে না।",
            reply_markup=back_kb("buy:back:list"),
        )
        await callback.answer()
        return
    if balance < price:
        min_pay = price * float(settings.credit_min_pay_ratio)
        if balance < min_pay:
            await show_screen(
                callback,
                state,
                f"📦 <b>{package.name}</b> ({date_utils.fmt_money(price)})\n\n"
                f"💰 আপনার ব্যালান্স: {date_utils.fmt_money(balance)}\n\n"
                f"এই প্যাকেজটি কিনতে আরও {date_utils.fmt_money(price - balance)} ডিপোজিট করুন। "
                f"বাকিতে নিতে হলেও কমপক্ষে ৫০% অর্থাৎ {date_utils.fmt_money(min_pay)} থাকতে হবে।",
                reply_markup=back_kb("buy:back:list"),
            )
            await callback.answer()
            return
        due = price - balance
        await show_screen(
            callback,
            state,
            f"📦 <b>{package.name}</b> ({date_utils.fmt_money(price)})\n\n"
            f"💰 আপনার ব্যালান্স: {date_utils.fmt_money(balance)}\n"
            "ব্যালান্স প্যাকেজের দামের চেয়ে কম।\n\n"
            f"🧾 বাকিতে নিলে এখন {date_utils.fmt_money(balance)} কাটা হবে, "
            f"বাকি {date_utils.fmt_money(due)} বকেয়া থাকবে।",
            reply_markup=buy_credit_kb(package_id, back_data="buy:back:list"),
        )
        await callback.answer()
        return
    await state.update_data(package_id=package_id, is_credit=False, mac=None)
    await _show_mac(callback, state)
    await callback.answer()


# --------------------------- MAC স্কিপ ---------------------------
@router.callback_query(CustomerBuy.waiting_mac, F.data == "buymac:skip")
async def buy_mac_skip(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(mac=None)
    await _show_confirm(callback, state)
    await callback.answer()


# --------------------------- MAC টাইপ ---------------------------
@router.message(CustomerBuy.waiting_mac, ~_INTERRUPT)
async def buy_mac_typed(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await delete_user_message(message)
        await _cancel(message, state, "❌ বাতিল করা হয়েছে।")
        return
    raw = (message.text or "").strip()
    await delete_user_message(message)
    if raw.lower() in _SKIP_WORDS:
        await state.update_data(mac=None)
        await _show_confirm(message, state)
        return
    try:
        mac = validators.validate_mac(raw)
    except validators.ValidationError as exc:
        text, kb = await _mac_parts(state, error=str(exc))
        await show_screen(message, state, text, reply_markup=kb)
        return
    await state.update_data(mac=mac)
    await _show_confirm(message, state)
