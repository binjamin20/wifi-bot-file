"""গ্রাহক প্যানেল — 'আমার আইডি' ও নিজের নম্বর সেট, স্মার্ট এক-স্ক্রিন সংস্করণ।

- 'আমার আইডি' একটি স্ক্রিন হিসেবে দেখায়; 'নিজের নম্বর সেট করুন' চাপলে সেই
  স্ক্রিনটিই edit হয়ে নম্বর চাওয়ার ধাপ দেখায় (নতুন মেসেজ জমে না)।
- নম্বর দিলে ইউজারের টাইপ-করা মেসেজ মুছে যায়, আর একই স্ক্রিন আবার
  'আমার আইডি' কার্ডে ফেরে — এবার নম্বরসহ।

এই router customer_panel-এর আগে রেজিস্টার হয়, তাই আমার-আইডি/নম্বর সংক্রান্ত
সব হ্যান্ডলিং এখান থেকেই হয়।
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.handlers.customer.panel import _INTERRUPT, _ensure_account, _is_cancel
from app.keyboards.customer_kb import CM_MYID, back_kb, my_id_kb
from app.services.customer_service import customer_service
from app.services.text_service import tx
from app.states.states import CustomerSetPhone
from app.utils import date_utils, validators
from app.utils.logger import get_logger
from app.utils.nav import delete_user_message, show_screen

log = get_logger(__name__)

router = Router(name="customer-myid")


# --------------------------- টেক্সট হেল্পার ---------------------------
def _card_text(user, customer) -> str:
    username = f"@{user.username}" if user.username else "নেই"
    raw_phone = (getattr(customer, "phone", "") or "").strip()
    phone_display = (
        date_utils.to_bn_digits(raw_phone) if raw_phone else "সেট করা হয়নি"
    )
    return tx(
        "myid.card",
        name=user.full_name,
        username=username,
        id=user.id,
        phone=phone_display,
    )


def _prompt_text(error: str | None = None) -> str:
    base = tx("myid.set_phone_prompt")
    if error:
        return f"⚠ {error}\n\n{base}"
    return base


# --------------------------- স্ক্রিন হেল্পার ---------------------------
async def _show_card(event, state: FSMContext, user) -> None:
    customer = await _ensure_account(user)
    phone_set = bool((getattr(customer, "phone", "") or "").strip())
    await show_screen(
        event, state, _card_text(user, customer), reply_markup=my_id_kb(phone_set)
    )


async def _show_prompt(event, state: FSMContext, error: str | None = None) -> None:
    await state.set_state(CustomerSetPhone.waiting_phone)
    await show_screen(
        event, state, _prompt_text(error), reply_markup=back_kb("myid:back")
    )


# --------------------------- এন্ট্রি: আমার আইডি ---------------------------
@router.message(F.text == CM_MYID)
async def menu_myid(message: Message, state: FSMContext) -> None:
    user = message.from_user
    await customer_service.touch_telegram_profile(
        user.id, user.username, user.full_name
    )
    await state.clear()
    await _show_card(message, state, user)


# --------------------------- নম্বর সেট শুরু ---------------------------
@router.callback_query(F.data == "cust:setphone")
async def set_phone_start(callback: CallbackQuery, state: FSMContext) -> None:
    customer = await _ensure_account(callback.from_user)
    if (getattr(customer, "phone", "") or "").strip():
        await callback.answer(
            "আপনার নম্বর আগেই সেট করা আছে — এটি আর পরিবর্তন করা যাবে না।",
            show_alert=True,
        )
        return
    await _show_prompt(callback, state)
    await callback.answer()


# --------------------------- পিছনে (কার্ডে ফেরা) ---------------------------
@router.callback_query(F.data == "myid:back")
async def phone_back(callback: CallbackQuery, state: FSMContext) -> None:
    await _show_card(callback, state, callback.from_user)
    await state.clear()
    await callback.answer()


# --------------------------- নম্বর গ্রহণ ---------------------------
@router.message(CustomerSetPhone.waiting_phone, ~_INTERRUPT)
async def set_phone_typed(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await delete_user_message(message)
        await _show_card(message, state, message.from_user)
        await state.clear()
        return
    await delete_user_message(message)
    customer = await _ensure_account(message.from_user)
    if (getattr(customer, "phone", "") or "").strip():
        await _show_card(message, state, message.from_user)
        await state.clear()
        return
    try:
        phone = validators.validate_sender_number(message.text or "")
    except validators.ValidationError as exc:
        await _show_prompt(message, state, error=str(exc))
        return
    await customer_service.update_fields(customer.id, phone=phone)
    await _show_card(message, state, message.from_user)
    await state.clear()
