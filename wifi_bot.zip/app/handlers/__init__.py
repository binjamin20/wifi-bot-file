"""Handlers প্যাকেজ — সব router এক জায়গায় রেজিস্টার করা হয়।"""

from __future__ import annotations

from aiogram import Dispatcher

from app.handlers.customer import panel as customer_panel
from app.handlers.customer import deposit as customer_deposit
from app.handlers.customer import buy as customer_buy
from app.handlers.customer import myid as customer_myid
from app.handlers import chat_member
from app.handlers.owner import (
    broadcast,
    customers,
    dashboard,
    export_backup,
    packages,
    payments,
    redeem,
    reports,
    requests,
    settings,
    subscriptions,
    system,
    texts,
)


def register_all_handlers(dp: Dispatcher) -> None:
    """সব router include করে। ক্রম গুরুত্বপূর্ণ: owner router আগে, তারপর customer।"""
    dp.include_router(dashboard.router)
    dp.include_router(customers.router)
    dp.include_router(subscriptions.router)
    dp.include_router(payments.router)
    dp.include_router(reports.router)
    dp.include_router(broadcast.router)
    dp.include_router(export_backup.router)
    dp.include_router(packages.router)
    dp.include_router(requests.router)
    dp.include_router(settings.router)
    dp.include_router(redeem.router)
    dp.include_router(system.router)
    dp.include_router(texts.router)
    dp.include_router(chat_member.router)
    # customer router সবশেষে (fallback /start ইত্যাদি)
    dp.include_router(customer_deposit.router)
    dp.include_router(customer_buy.router)
    dp.include_router(customer_myid.router)
    dp.include_router(customer_panel.router)
