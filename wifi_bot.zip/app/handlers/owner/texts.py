"""ইউজার প্যানেল টেক্সট এডিট — গ্রাহক যে টেক্সটগুলো দেখে সেগুলো এডমিন থেকে এডিট করার হ্যান্ডলার।

ফ্লো: সিস্টেম মেনু → টেক্সট এডিট → সেকশন (স্ক্রিন) → টেক্সট → এডিট / ডিফল্ট।
শুধু এডমিন (owner_id) ব্যবহার করতে পারবে।

কলব্যাক ফরম্যাট (পেজ মনে রাখা ব্যাক নেভিগেশন):
  sys:txt                  → সেকশন তালিকা
  txt:s:<slug>:<page>      → এক সেকশনের টেক্সট তালিকা
  txt:i:<key>:<page>       → একটি টেক্সট দেখা
  txt:e:<key>:<page>       → এডিট শুরু
  txt:r:<key>:<page>       → ডিফল্টে ফেরানো
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.config import settings
from app.services.text_service import text_service
from app.states.states import OwnerTextEdit
from app.utils.ui import danger, primary, success

router = Router(name='owner-texts')
router.message.filter(F.from_user.id == settings.owner_id)
router.callback_query.filter(F.from_user.id == settings.owner_id)

NL = chr(10)
_CANCEL_WORDS = {'cancel', '/cancel', 'বাতিল'}
ITEM_PER_PAGE = 8


def _esc(text: str) -> str:
    return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def _ph_tokens(key: str) -> str:
    ph = text_service.placeholders_of(key)
    return ' '.join('{' + p + '}' for p in ph) if ph else ''


def _ph_line(key: str) -> str:
    tokens = _ph_tokens(key)
    if not tokens:
        return ''
    return f'{NL}🔁 ডায়নামিক অংশ (হুবহু রাখুন): <code>{_esc(tokens)}</code>'


def _where_line(key: str) -> str:
    wheres = text_service.where_of(key)
    if not wheres:
        return ''
    return '📍 কোথায়: ' + ' · '.join(wheres)


async def _edit_or_send(message: Message, text: str, kb: InlineKeyboardMarkup) -> None:
    try:
        await message.edit_text(text, reply_markup=kb)
    except Exception:
        await message.answer(text, reply_markup=kb)


# ---------------- সেকশন তালিকা ----------------
def _sections_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for slug, label, count in text_service.list_sections():
        builder.button(text=f'{label} ({count})', callback_data=f'txt:s:{slug}:0', **primary())
    builder.adjust(1)
    foot = InlineKeyboardBuilder()
    foot.button(text='⬅️ সিস্টেম মেনু', callback_data='sys:open', **danger())
    foot.adjust(1)
    builder.attach(foot)
    return builder.as_markup()


def _sections_title() -> str:
    total = sum(c for _, _, c in text_service.list_sections())
    return (
        f'📝 <b>ইউজার প্যানেল টেক্সট এডিট</b>{NL}{NL}'
        f'গ্রাহক যে টেক্সটগুলো দেখে সেগুলো এখান থেকে বদলাতে পারবেন।{NL}'
        f'মোট <b>{total}</b> টি টেক্সট, স্ক্রিন অনুযায়ী সাজানো।{NL}{NL}'
        f'কোন স্ক্রিনের টেক্সট দেখবেন বেছে নিন:'
    )


# ---------------- এক সেকশনের তালিকা ----------------
def _items_kb(slug: str, page: int) -> InlineKeyboardMarkup:
    keys = text_service.list_keys(slug)
    pages = max(1, (len(keys) + ITEM_PER_PAGE - 1) // ITEM_PER_PAGE)
    page = max(0, min(page, pages - 1))
    start = page * ITEM_PER_PAGE
    builder = InlineKeyboardBuilder()
    for key in keys[start:start + ITEM_PER_PAGE]:
        mark = '✏️' if text_service.is_overridden(key) else '•'
        builder.button(text=f'{mark} {text_service.label_of(key)}', callback_data=f'txt:i:{key}:{page}', **primary())
    builder.adjust(1)
    nav = InlineKeyboardBuilder()
    if pages > 1:
        if page > 0:
            nav.button(text='⬅️', callback_data=f'txt:s:{slug}:{page - 1}')
        nav.button(text=f'{page + 1}/{pages}', callback_data='txt:noop')
        if page < pages - 1:
            nav.button(text='➡️', callback_data=f'txt:s:{slug}:{page + 1}')
        nav.adjust(3)
    foot = InlineKeyboardBuilder()
    foot.button(text='⬅️ সেকশন তালিকা', callback_data='sys:txt', **danger())
    foot.adjust(1)
    builder.attach(nav)
    builder.attach(foot)
    return builder.as_markup()


def _items_title(slug: str) -> str:
    return (
        f'{text_service.section_label(slug)}{NL}{NL}'
        f'📍 গ্রাহক প্যানেলের এই অংশের টেক্সটগুলো।{NL}'
        f'যেটি বদলাতে চান বেছে নিন:'
    )


# ---------------- একটি টেক্সট ----------------
def _item_kb(key: str, page: int) -> InlineKeyboardMarkup:
    slug = text_service.slug_of(key)
    builder = InlineKeyboardBuilder()
    builder.button(text='✏️ এডিট করুন', callback_data=f'txt:e:{key}:{page}', **success())
    if text_service.is_overridden(key):
        builder.button(text='♻️ ডিফল্টে ফেরান', callback_data=f'txt:r:{key}:{page}', **danger())
    builder.button(text='⬅️ পিছনে', callback_data=f'txt:s:{slug}:{page}', **primary())
    builder.adjust(1)
    return builder.as_markup()


def _item_view(key: str) -> str:
    raw = text_service.get_raw(key)
    status = '✏️ কাস্টম (এডিট করা)' if text_service.is_overridden(key) else '🔹 ডিফল্ট'
    return (
        f'📝 <b>{_esc(text_service.label_of(key))}</b>{NL}'
        f'{_where_line(key)}{NL}'
        f'অবস্থা: {status}{_ph_line(key)}{NL}{NL}'
        f'বর্তমান টেক্সট:{NL}<pre>{_esc(raw)}</pre>'
    )


def _edit_prompt(key: str) -> str:
    raw = text_service.get_raw(key)
    return (
        f'✏️ <b>{_esc(text_service.label_of(key))}</b>{NL}'
        f'{_where_line(key)}{NL}{NL}'
        f'নতুন টেক্সট লিখে পাঠান।{_ph_line(key)}{NL}{NL}'
        f'<i>বাতিল লিখে বন্ধ করতে পারেন।</i>{NL}{NL}'
        f'বর্তমান টেক্সট:{NL}<pre>{_esc(raw)}</pre>'
    )


def _cancel_kb(key: str, page: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text='⬅️ বাতিল', callback_data=f'txt:i:{key}:{page}', **danger())
    builder.adjust(1)
    return builder.as_markup()


def _parse_key_page(data: str) -> tuple[str, int]:
    # txt:<x>:<key>:<page>  (key তে কোলন থাকে না)
    parts = data.split(':')
    key = parts[2] if len(parts) > 2 else ''
    try:
        page = int(parts[3]) if len(parts) > 3 else 0
    except ValueError:
        page = 0
    return key, page


# ================= হ্যান্ডলার =================
@router.callback_query(F.data == 'txt:noop')
async def noop(callback: CallbackQuery) -> None:
    await callback.answer()


@router.callback_query(F.data == 'sys:txt')
async def open_texts(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await _edit_or_send(callback.message, _sections_title(), _sections_kb())
    await callback.answer()


@router.callback_query(F.data.startswith('txt:s:'))
async def open_section(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or '').split(':')
    slug = parts[2] if len(parts) > 2 else ''
    try:
        page = int(parts[3]) if len(parts) > 3 else 0
    except ValueError:
        page = 0
    if callback.message is not None:
        await _edit_or_send(callback.message, _items_title(slug), _items_kb(slug, page))
    await callback.answer()


@router.callback_query(F.data.startswith('txt:i:'))
async def open_item(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    key, page = _parse_key_page(callback.data or '')
    if not text_service.has_key(key):
        await callback.answer('টেক্সটটি পাওয়া যায়নি।', show_alert=True)
        return
    if callback.message is not None:
        await _edit_or_send(callback.message, _item_view(key), _item_kb(key, page))
    await callback.answer()


@router.callback_query(F.data.startswith('txt:r:'))
async def reset_item(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    key, page = _parse_key_page(callback.data or '')
    if not text_service.has_key(key):
        await callback.answer('টেক্সটটি পাওয়া যায়নি।', show_alert=True)
        return
    await text_service.reset(key)
    if callback.message is not None:
        await _edit_or_send(callback.message, _item_view(key), _item_kb(key, page))
    await callback.answer('♻️ ডিফল্টে ফেরানো হয়েছে।')


@router.callback_query(F.data.startswith('txt:e:'))
async def edit_item(callback: CallbackQuery, state: FSMContext) -> None:
    key, page = _parse_key_page(callback.data or '')
    if not text_service.has_key(key):
        await callback.answer('টেক্সটটি পাওয়া যায়নি।', show_alert=True)
        return
    await state.set_state(OwnerTextEdit.waiting_value)
    await state.update_data(tkey=key, tpage=page)
    if callback.message is not None:
        await _edit_or_send(callback.message, _edit_prompt(key), _cancel_kb(key, page))
    await callback.answer()


@router.message(OwnerTextEdit.waiting_value)
async def save_item(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    key = data.get('tkey', '')
    page = int(data.get('tpage', 0) or 0)
    value = message.text or message.caption or ''
    await state.clear()
    if not key or not text_service.has_key(key):
        await message.answer('টেক্সটটি পাওয়া যায়নি।')
        return
    if value.strip().lower() in _CANCEL_WORDS:
        await message.answer('❌ বাতিল করা হয়েছে।', reply_markup=_item_kb(key, page))
        await message.answer(_item_view(key), reply_markup=_item_kb(key, page))
        return
    await text_service.set(key, value)
    await message.answer('✅ টেক্সট আপডেট হয়েছে।')
    await message.answer(_item_view(key), reply_markup=_item_kb(key, page))
