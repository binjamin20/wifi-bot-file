"""পেমেন্ট হ্যান্ডলার — /payment, /history, /dues।"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.database.base import db
from app.keyboards.owner_kb import (
    cancel_kb,
    owner_main_menu,
    owner_skip_kb,
    payment_methods_kb,
)
from app.middlewares.auth import OwnerOnlyMiddleware
from app.repositories.customer_repo import CustomerRepository
from app.services.customer_service import customer_service
from app.services.payment_service import payment_service
from app.states.states import AddPayment
from app.utils import date_utils, validators
from app.utils.formatters import payment_row

router = Router(name="owner-payments")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())


# ===================== ADD PAYMENT =====================
@router.message(Command("payment"))
@router.message(F.text == "\U0001f4b3 পেমেন্ট")
async def payment_start(message: Message, state: FSMContext) -> None:
    await state.set_state(AddPayment.waiting_customer)
    await message.answer(
        "\U0001f4b3 কার পেমেন্ট? Customer ID / Telegram ID / ফোন / নাম লিখুন:",
        reply_markup=cancel_kb(),
    )


@router.message(AddPayment.waiting_customer)
async def payment_customer(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text.lower() in ("cancel", "বাতিল"):
        await state.clear()
        await message.answer("বাতিল।", reply_markup=owner_main_menu())
        return
    # নমনীয় খোঁজ — ID / Telegram ID / ফোন / নাম যেকোনোটি।
    match, matches = await customer_service.resolve_one(text)
    if not matches:
        await message.answer(
            "⚠ এই তথ্য দিয়ে কোনো গ্রাহক পাওয়া যায়নি। আবার চেষ্টা করুন:",
            reply_markup=cancel_kb(),
        )
        return
    if match is None:
        lines = ["একাধিক গ্রাহক মিলেছে — সঠিক Customer ID লিখুন:"]
        for c in matches[:20]:
            lines.append(f"#{c.id} · {c.name} · {c.phone}")
        await message.answer("\n".join(lines))
        return
    customer = match
    await state.update_data(customer_id=customer.id)
    await state.set_state(AddPayment.amount)
    await message.answer(
        f"\U0001f464 {customer.name} (#{customer.id})\n"
        f"❌ বকেয়া: {date_utils.fmt_money(customer.due_amount)}\n"
        f"\U0001f4b5 কত টাকা পেলেন?"
    )


@router.message(AddPayment.amount)
async def payment_amount(message: Message, state: FSMContext) -> None:
    try:
        amount = validators.validate_amount(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    await state.update_data(amount=amount)
    await state.set_state(AddPayment.method)
    await message.answer("\U0001f4b3 পেমেন্ট মেথড বেছে নিন:", reply_markup=payment_methods_kb())


@router.callback_query(AddPayment.method, F.data.startswith("paymethod:"))
async def payment_method(callback: CallbackQuery, state: FSMContext) -> None:
    method = callback.data.split(":", 1)[1]
    await state.update_data(method=method)
    await state.set_state(AddPayment.transaction_id)
    await callback.message.answer(
        f"✅ মেথড: {method}\n\U0001f9fe Transaction ID লিখুন (না থাকলে 'skip'):",
        reply_markup=owner_skip_kb("owner:skip:ptxn"),
    )
    await callback.answer()


@router.message(AddPayment.transaction_id)
async def payment_txn(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    txn = None if text.lower() in ("skip", "-", "না") else text
    await state.update_data(transaction_id=txn)
    await state.set_state(AddPayment.note)
    await message.answer(
        "\U0001f4dd নোট লিখুন (না থাকলে 'skip'):",
        reply_markup=owner_skip_kb("owner:skip:pnote"),
    )


async def _finalize_add_payment(state: FSMContext, note: str | None) -> str:
    """পেমেন্ট যোগ করে রেসপন্স টেক্সট ফেরত দেয় (note=None হলে স্কিপ)।"""
    data = await state.get_data()
    await state.clear()
    payment = await payment_service.add_payment(
        customer_id=data["customer_id"], amount=data["amount"],
        method=data["method"], transaction_id=data.get("transaction_id"), note=note,
    )
    if payment is None:
        return "গ্রাহক পাওয়া যায়নি।"
    customer = await customer_service.get(data["customer_id"])
    return (
        "✅ <b>পেমেন্ট যোগ হয়েছে!</b>\n"
        f"\U0001f4b5 পরিশোধ: {date_utils.fmt_money(payment.amount)}\n"
        f"❌ অবশিষ্ট বকেয়া: {date_utils.fmt_money(customer.due_amount if customer else 0)}"
    )


@router.message(AddPayment.note)
async def payment_save(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    note = None if text.lower() in ("skip", "-", "না") else text
    text_out = await _finalize_add_payment(state, note)
    await message.answer(text_out, reply_markup=owner_main_menu())


@router.callback_query(AddPayment.note, F.data == "owner:skip:pnote")
async def payment_save_skip(callback: CallbackQuery, state: FSMContext) -> None:
    text_out = await _finalize_add_payment(state, None)
    if callback.message is not None:
        await callback.message.answer(text_out, reply_markup=owner_main_menu())
    await callback.answer()


@router.callback_query(AddPayment.transaction_id, F.data == "owner:skip:ptxn")
async def payment_txn_skip(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(transaction_id=None)
    await state.set_state(AddPayment.note)
    if callback.message is not None:
        await callback.message.answer(
            "\U0001f4dd নোট লিখুন (না থাকলে 'skip'):",
            reply_markup=owner_skip_kb("owner:skip:pnote"),
        )
    await callback.answer()


# ===================== HISTORY / DUES =====================
@router.message(Command("history"))
async def payment_history(message: Message) -> None:
    parts = (message.text or "").split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("ব্যবহার: /history &lt;customer_id&gt;")
        return
    customer_id = int(parts[1])
    payments = await payment_service.history(customer_id)
    if not payments:
        await message.answer("এই গ্রাহকের কোনো পেমেন্ট নেই।")
        return
    rows = "\n".join(payment_row(p) for p in payments)
    await message.answer(f"\U0001f4b3 <b>পেমেন্ট ইতিহাস (#{customer_id}):</b>\n\n{rows}")


@router.message(Command("dues"))
@router.message(F.text == "\U0001f4cb বকেয়া")
async def dues_list(message: Message) -> None:
    async with db.session() as session:
        items = await CustomerRepository(session).with_due()
    if not items:
        await message.answer("\U0001f389 কারো কোনো বকেয়া নেই।", reply_markup=owner_main_menu())
        return
    lines = ["\U0001f4cb <b>বকেয়া গ্রাহক:</b>\n"]
    for c in items[:50]:
        days = date_utils.remaining_days(c.expiry_date)
        lines.append(
            f"• <b>{c.name}</b> — {date_utils.fmt_money(c.due_amount)} "
            f"({date_utils.to_bn_digits(days)} দিন)"
        )
    await message.answer("\n".join(lines), reply_markup=owner_main_menu())
