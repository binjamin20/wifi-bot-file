"""গ্রাহক ব্যবস্থাপনা হ্যান্ডলার — /addcustomer, /editcustomer,
/deletecustomer, /search, /customer।

এই router শুধু owner-এর জন্য (F.from_user.id ফিল্টার + OwnerOnlyMiddleware)।
"""

from __future__ import annotations

from contextlib import suppress

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.keyboards.owner_kb import (
    add_package_select_kb,
    cancel_kb,
    confirm_kb,
    customer_profile_kb,
    customers_list_kb,
    edit_fields_kb,
    initial_payment_kb,
    owner_main_menu,
    owner_skip_kb,
    tgid_conflict_kb,
)
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.customer_service import (
    DuplicateCustomerError,
    NewCustomerData,
    customer_service,
)
from app.services.package_service import package_service
from app.states.states import (
    AddCustomer,
    DeleteCustomer,
    EditCustomer,
    SearchCustomer,
)
from app.utils import date_utils, validators
from app.utils.formatters import customer_profile, customer_row, purchase_row
from app.utils.logger import get_logger

router = Router(name="owner-customers")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())

_CANCEL_WORDS = {"cancel", "/cancel", "বাতিল"}
_SKIP_WORDS = {"skip", "-", "না", "নাই"}

log = get_logger(__name__)


async def _cancelled(message: Message, state: FSMContext) -> bool:
    """ইউজার 'বাতিল' লিখলে FSM ক্লিয়ার করে True ফেরত দেয়।"""
    if (message.text or "").strip().lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return True
    return False


def _opt(text: str) -> str | None:
    """ঐচ্ছিক ফিল্ড — skip দিলে None।"""
    value = (text or "").strip()
    if value.lower() in _SKIP_WORDS or not value:
        return None
    return value


# ===================== ADD CUSTOMER =====================
@router.message(Command("addcustomer"))
@router.message(F.text == "➕ নতুন গ্রাহক")
async def add_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(AddCustomer.name)
    await message.answer(
        "➕ <b>নতুন গ্রাহক যোগ</b>\n\n"
        "👤 গ্রাহকের নাম লিখুন:\n"
        "<i>(যেকোনো সময় বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )


@router.message(AddCustomer.name)
async def add_name(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    try:
        name = validators.validate_name(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    await state.update_data(name=name)
    await state.set_state(AddCustomer.phone)
    await message.answer(
        "📞 ফোন নম্বর লিখুন (যেমন 01712345678):\n"
        "<i>না থাকলে ⏭ স্কিপ চাপুন।</i>",
        reply_markup=owner_skip_kb("owner:skip:phone"),
    )


@router.message(AddCustomer.phone)
async def add_phone(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    if _opt(message.text or "") is None:
        phone = ""
    else:
        try:
            phone = validators.validate_phone(message.text or "")
        except validators.ValidationError as exc:
            await message.answer(f"⚠ {exc}")
            return
    await state.update_data(phone=phone)
    await _ask_telegram_id(message, state)


@router.callback_query(AddCustomer.phone, F.data == "owner:skip:phone")
async def add_skip_phone(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(phone="")
    if callback.message is not None:
        await _ask_telegram_id(callback.message, state)
    await callback.answer()


async def _ask_telegram_id(msg: Message, state: FSMContext) -> None:
    await state.set_state(AddCustomer.telegram_id)
    await msg.answer(
        "💬 গ্রাহকের Telegram ID লিখুন (সংখ্যা)।\n"
        "<i>না থাকলে 'skip' লিখুন।</i>",
        reply_markup=owner_skip_kb("owner:skip:tgid"),
    )


@router.message(AddCustomer.telegram_id)
async def add_telegram_id(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    try:
        tg_id = validators.validate_telegram_id(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    if tg_id is not None:
        existing = await customer_service.get_by_telegram_id(tg_id)
        if existing is not None:
            await state.clear()
            await message.answer(
                "⚠ <b>এই Telegram ID দিয়ে আগেই একজন গ্রাহক যোগ করা আছে:</b>\n\n"
                + customer_profile(existing),
                reply_markup=owner_main_menu(),
            )
            return
    await state.update_data(telegram_id=tg_id)
    await _ask_package(message, state)


@router.message(AddCustomer.package_name)
async def add_package_name(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    package = (message.text or "").strip()
    if not package:
        await message.answer("⚠ প্যাকেজের নাম খালি রাখা যাবে না।")
        return
    await state.update_data(package_name=package)
    await state.set_state(AddCustomer.package_price)
    await message.answer("💵 প্যাকেজের দাম লিখুন (যেমন 500):")


@router.message(AddCustomer.package_price)
async def add_package_price(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    try:
        price = validators.validate_price(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    await state.update_data(package_price=price)
    await state.set_state(AddCustomer.duration)
    await message.answer("⏳ মেয়াদ কত দিন? (যেমন 30):")


@router.message(AddCustomer.duration)
async def add_duration(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    try:
        duration = validators.validate_duration(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    await state.update_data(duration=duration)
    data = await state.get_data()
    price = float(data.get("package_price") or 0)
    await state.set_state(AddCustomer.initial_payment)
    await message.answer(
        "💰 গ্রাহক কি এখন কোনো টাকা পরিশোধ করেছেন?",
        reply_markup=initial_payment_kb(price),
    )


@router.callback_query(AddCustomer.initial_payment, F.data.startswith("addpay:"))
async def add_initial_payment(callback: CallbackQuery, state: FSMContext) -> None:
    choice = callback.data.split(":", 1)[1]
    data = await state.get_data()
    price = float(data.get("package_price") or 0)
    if choice == "custom":
        await state.set_state(AddCustomer.custom_payment)
        await callback.message.answer("💵 গ্রাহক এখন কত টাকা দিয়েছেন? সংখ্যা লিখুন:")
        await callback.answer()
        return
    paid = price if choice == "full" else 0.0
    await state.update_data(paid_amount=paid)
    await state.set_state(AddCustomer.notes)
    await callback.message.answer(
        "📝 কোনো নোট থাকলে লিখুন (না থাকলে 'skip'):",
        reply_markup=owner_skip_kb("owner:skip:notes"),
    )
    await callback.answer()


@router.message(AddCustomer.custom_payment)
async def add_custom_payment(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    try:
        paid = validators.validate_price(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    await state.update_data(paid_amount=paid)
    await state.set_state(AddCustomer.notes)
    await message.answer(
        "📝 কোনো নোট থাকলে লিখুন (না থাকলে 'skip'):",
        reply_markup=owner_skip_kb("owner:skip:notes"),
    )


async def _finalize_add_customer(state: FSMContext, notes: str | None) -> str:
    """গ্রাহক তৈরি করে রেসপন্স টেক্সট ফেরত দেয় (notes=None হলে স্কিপ)।"""
    data = await state.get_data()
    await state.clear()
    try:
        customer = await customer_service.create(
            NewCustomerData(
                name=data["name"],
                phone=data["phone"],
                telegram_id=data.get("telegram_id"),
                package_name=data["package_name"],
                package_price=data["package_price"],
                duration=data["duration"],
                notes=notes,
                paid_amount=float(data.get("paid_amount") or 0),
            )
        )
    except DuplicateCustomerError as exc:
        try:
            return (
                "⚠ <b>এই গ্রাহক আগেই যোগ করা হয়েছে!</b>\n\n"
                + customer_profile(exc.existing)
            )
        except Exception:
            log.exception("Duplicate profile render failed")
            return "⚠ এই গ্রাহক আগেই যোগ করা হয়েছে!"
    except Exception:
        log.exception("Customer create failed")
        return "⚠ গ্রাহক যোগ করার সময় একটি সমস্যা হয়েছে। আবার চেষ্টা করুন।"
    # গ্রাহক সফলভাবে তৈরি ও সেভ হয়েছে — কনফার্মেশন অবশ্যই যাবে।
    try:
        return "✅ <b>গ্রাহক সফলভাবে যোগ হয়েছে!</b>\n\n" + customer_profile(customer)
    except Exception:
        log.exception("customer_profile render failed after create")
        cid = date_utils.to_bn_digits(getattr(customer, "id", 0) or 0)
        return f"✅ গ্রাহক সফলভাবে যোগ হয়েছে! (আইডি #{cid})"


@router.message(AddCustomer.notes)
async def add_save(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    text_out = await _finalize_add_customer(state, _opt(message.text or ""))
    await message.answer(text_out, reply_markup=owner_main_menu())


@router.callback_query(AddCustomer.notes, F.data == "owner:skip:notes")
async def add_skip_notes(callback: CallbackQuery, state: FSMContext) -> None:
    text_out = await _finalize_add_customer(state, None)
    if callback.message is not None:
        await callback.message.answer(text_out, reply_markup=owner_main_menu())
    await callback.answer()


@router.callback_query(AddCustomer.telegram_id, F.data == "owner:skip:tgid")
async def add_skip_tgid(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(telegram_id=None)
    if callback.message is not None:
        await _ask_package(callback.message, state)
    await callback.answer()


async def _ask_package(msg: Message, state: FSMContext) -> None:
    """সেভ করা অ্যাকটিভ প্যাকেজ থেকে সিলেকশন (না থাকলে ম্যানুয়াল টাইপ)।"""
    packages = await package_service.list_active()
    if not packages:
        await state.set_state(AddCustomer.package_name)
        await msg.answer(
            "📦 কোনো সেভ করা প্যাকেজ নেই। প্যাকেজের নাম লিখুন (যেমন 5Mbps মাসিক):"
        )
        return
    await state.set_state(AddCustomer.choosing_package)
    await msg.answer(
        "📦 <b>প্যাকেজ সিলেক্ট করুন:</b>",
        reply_markup=add_package_select_kb(packages),
    )


@router.callback_query(AddCustomer.choosing_package, F.data.startswith("addpkg:"))
async def add_package_chosen(callback: CallbackQuery, state: FSMContext) -> None:
    choice = callback.data.split(":", 1)[1]
    if choice == "custom":
        await state.set_state(AddCustomer.package_name)
        if callback.message is not None:
            await callback.message.answer(
                "📦 প্যাকেজের নাম লিখুন (যেমন 5Mbps মাসিক):"
            )
        await callback.answer()
        return
    if not choice.isdigit():
        await callback.answer()
        return
    pkg = await package_service.get(int(choice))
    if pkg is None:
        await callback.answer("প্যাকেজটি পাওয়া যায়নি।", show_alert=True)
        return
    await state.update_data(
        package_name=pkg.name,
        package_price=float(pkg.price),
        duration=int(pkg.duration_days),
    )
    await state.set_state(AddCustomer.initial_payment)
    if callback.message is not None:
        await callback.message.answer(
            f"✅ প্যাকেজ: <b>{pkg.name}</b> — {date_utils.fmt_money(pkg.price)} · "
            f"{date_utils.to_bn_digits(pkg.duration_days)} দিন\n\n"
            "💰 গ্রাহক কি এখন কোনো টাকা পরিশোধ করেছেন?",
            reply_markup=initial_payment_kb(float(pkg.price)),
        )
    await callback.answer()


# ===================== CUSTOMER PROFILE =====================
@router.message(Command("customer"))
async def customer_profile_cmd(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip():
        await message.answer("ব্যবহার: /customer &lt;আইডি / Telegram ID / ফোন&gt;")
        return
    term = parts[1].strip()
    single, matches = await customer_service.resolve_one(term)
    if single is not None:
        await message.answer(customer_profile(single), reply_markup=customer_profile_kb(single))
        return
    if not matches:
        await message.answer("⚠ এই তথ্য দিয়ে কোনো গ্রাহক পাওয়া যায়নি।")
        return
    lines = [f"🔍 <b>একাধিক গ্রাহক মিলেছে ({date_utils.to_bn_digits(len(matches))}):</b>\n"]
    for c in matches[:50]:
        lines.append(f"#{date_utils.to_bn_digits(c.id)} · {customer_row(c)}")
    lines.append("\n<i>সঠিক Customer ID দিয়ে আবার /customer দিন।</i>")
    await message.answer("\n".join(lines))


# ===================== SEARCH =====================
@router.message(Command("search"))
@router.message(F.text == "👤 গ্রাহক তথ্য")
async def search_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(SearchCustomer.waiting_term)
    await message.answer(
        "👤 <b>গ্রাহক তথ্য</b>\n\n"
        "যে গ্রাহকের তথ্য দেখতে চান তার Customer ID / Telegram ID / ফোন / নাম লিখুন:\n"
        "<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )


@router.message(SearchCustomer.waiting_term)
async def search_run(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    term = (message.text or "").strip()
    await state.clear()
    if not term:
        await message.answer("⚠ খালি সার্চ।", reply_markup=owner_main_menu())
        return
    single, matches = await customer_service.resolve_one(term)
    if single is not None:
        await message.answer(customer_profile(single), reply_markup=customer_profile_kb(single))
        return
    if not matches:
        await message.answer(
            f"😕 '{term}' দিয়ে কোনো গ্রাহক পাওয়া যায়নি।",
            reply_markup=owner_main_menu(),
        )
        return
    lines = [f"🔍 <b>একাধিক গ্রাহক মিলেছে ({date_utils.to_bn_digits(len(matches))}):</b>\n"]
    for c in matches[:50]:
        lines.append(f"#{date_utils.to_bn_digits(c.id)} · {customer_row(c)}")
    lines.append("\n<i>সঠিক Customer ID দিয়ে আবার চেষ্টা করুন বা /customer &lt;আইডি&gt; দিন।</i>")
    await message.answer("\n".join(lines), reply_markup=owner_main_menu())


# ===================== EDIT CUSTOMER =====================
_FIELD_LABELS = {
    "name": "নাম",
    "phone": "ফোন",
    "package_name": "প্যাকেজ",
    "package_price": "দাম",
    "notes": "নোট",
    "balance": "ব্যালান্স",
    "start_date": "শুরুর তারিখ",
    "expiry_date": "মেয়াদ শেষের তারিখ",
}


@router.message(Command("editcustomer"))
async def edit_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    parts = (message.text or "").split()
    if len(parts) >= 2 and parts[1].isdigit():
        await _edit_show_fields(message, state, int(parts[1]))
        return
    await state.set_state(EditCustomer.waiting_id)
    await message.answer("✏ কোন গ্রাহক এডিট করবেন? Customer ID লিখুন:")


@router.message(EditCustomer.waiting_id)
async def edit_pick(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    text = (message.text or "").strip()
    if not text.isdigit():
        await message.answer("⚠ Customer ID সংখ্যায় দিন।")
        return
    await _edit_show_fields(message, state, int(text))


async def _edit_show_fields(
    message: Message, state: FSMContext, customer_id: int
) -> None:
    customer = await customer_service.get(customer_id)
    if customer is None:
        await state.clear()
        await message.answer(
            "⚠ এই আইডির কোনো গ্রাহক পাওয়া যায়নি।",
            reply_markup=owner_main_menu(),
        )
        return
    await state.update_data(customer_id=customer_id)
    await state.set_state(EditCustomer.choosing_field)
    can_set_tgid = customer.telegram_id is None
    await message.answer(
        customer_profile(customer)
        + "\n\n✏ কোন তথ্য পরিবর্তন করবেন?",
        reply_markup=edit_fields_kb(customer_id, can_set_tgid=can_set_tgid),
    )


@router.callback_query(
    EditCustomer.choosing_field, F.data.startswith("editfield:")
)
async def edit_field_chosen(callback: CallbackQuery, state: FSMContext) -> None:
    _, _cid, field = callback.data.split(":")
    await state.update_data(field=field)
    await state.set_state(EditCustomer.waiting_value)
    label = _FIELD_LABELS.get(field, field)
    if field == "balance":
        hint = (
            "✏ নতুন ব্যালান্স লিখুন।\n"
            "<i>সরাসরি সংখ্যা দিলে সেট হবে; +100 / -50 দিলে বাড়বে/কমবে।</i>"
        )
    elif field in ("start_date", "expiry_date"):
        hint = f"✏ নতুন {label} লিখুন (যেমন 2026-06-15 বা 15-06-2026):"
    else:
        hint = f"✏ নতুন {label} লিখুন:"
    await callback.message.answer(hint, reply_markup=cancel_kb())
    await callback.answer()


@router.message(EditCustomer.waiting_value)
async def edit_value(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    data = await state.get_data()
    field = data.get("field")
    customer_id = data.get("customer_id")
    raw = message.text or ""
    if field == "balance":
        await _edit_balance(message, state, customer_id, raw)
        return
    if field in ("start_date", "expiry_date"):
        await _edit_date(message, state, customer_id, field, raw)
        return
    try:
        if field == "name":
            value: object = validators.validate_name(raw)
        elif field == "phone":
            value = validators.validate_phone(raw)
        elif field == "package_price":
            value = validators.validate_price(raw)
        else:  # package_name, notes
            value = raw.strip()
            if field == "notes":
                value = _opt(raw)
            elif not value:
                raise validators.ValidationError("খালি রাখা যাবে না।")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    await state.clear()
    customer = await customer_service.update_fields(customer_id, **{field: value})
    if customer is None:
        await message.answer(
            "⚠ গ্রাহক পাওয়া যায়নি।", reply_markup=owner_main_menu()
        )
        return
    await message.answer(
        "✅ <b>আপডেট হয়েছে!</b>\n\n" + customer_profile(customer),
        reply_markup=owner_main_menu(),
    )


# ---- Telegram ID সেট (ফাঁকা-আইডি গ্রাহকের জন্য) ----
@router.callback_query(F.data.startswith("settgid:start:"))
async def set_tgid_start(callback: CallbackQuery, state: FSMContext) -> None:
    customer_id = int(callback.data.split(":")[2])
    await state.clear()
    await state.update_data(customer_id=customer_id)
    await state.set_state(EditCustomer.waiting_tgid)
    if callback.message is not None:
        await callback.message.answer(
            "📲 এই গ্রাহকের জন্য Telegram ID লিখুন (সংখ্যা):",
            reply_markup=cancel_kb(),
        )
    await callback.answer()


@router.message(EditCustomer.waiting_tgid)
async def set_tgid_value(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer("⚠ Telegram ID শুধু সংখ্যা হতে হবে।")
        return
    tg_id = int(raw)
    data = await state.get_data()
    customer_id = data.get("customer_id")
    existing = await customer_service.get_by_telegram_id(tg_id)
    if existing is not None and existing.id != customer_id:
        await state.clear()
        await message.answer(
            "⚠ <b>এই Telegram ID দিয়ে আগেই একটি অ্যাকাউন্ট আছে:</b>\n\n"
            + customer_profile(existing)
            + "\n\n<b>এই অ্যাকাউন্টটি মুছে ফেললে</b> আইডিটি স্বয়ংক্রিয়ভাবে এই "
            "গ্রাহকের ঘরে বসে যাবে। কী করবেন?",
            reply_markup=tgid_conflict_kb(customer_id, tg_id),
        )
        return
    await state.clear()
    customer = await customer_service.update_fields(customer_id, telegram_id=tg_id)
    if customer is None:
        await message.answer("⚠ গ্রাহক পাওয়া যায়নি।", reply_markup=owner_main_menu())
        return
    await message.answer(
        "✅ <b>Telegram ID সেট হয়েছে!</b>\n\n" + customer_profile(customer),
        reply_markup=owner_main_menu(),
    )


@router.callback_query(F.data == "tgidconf:cancel")
async def tgid_conflict_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await callback.message.answer(
            "❌ বাতিল করা হয়েছে। আগের অ্যাকাউন্ট অপরিবর্তিত আছে।",
            reply_markup=owner_main_menu(),
        )
    await callback.answer()


@router.callback_query(F.data.startswith("tgidconf:del:"))
async def tgid_conflict_delete(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = callback.data.split(":")
    target_id = int(parts[2])
    tg_id = int(parts[3])
    existing = await customer_service.get_by_telegram_id(tg_id)
    if existing is not None and existing.id != target_id:
        await customer_service.delete(existing.id)
    customer = await customer_service.update_fields(target_id, telegram_id=tg_id)
    if callback.message is not None:
        if customer is None:
            await callback.message.answer(
                "⚠ গ্রাহক পাওয়া যায়নি।", reply_markup=owner_main_menu()
            )
        else:
            await callback.message.answer(
                "🗑 আগের অ্যাকাউন্টটি মুছে ফেলা হয়েছে এবং Telegram ID এই গ্রাহকের "
                "ঘরে বসানো হয়েছে।\n\n✅ <b>সম্পন্ন!</b>\n\n"
                + customer_profile(customer),
                reply_markup=owner_main_menu(),
            )
    await callback.answer()


# ===================== DELETE CUSTOMER =====================
@router.message(Command("deletecustomer"))
async def delete_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    parts = (message.text or "").split()
    if len(parts) >= 2 and parts[1].isdigit():
        await _delete_confirm_prompt(message, int(parts[1]))
        return
    await state.set_state(DeleteCustomer.waiting_id)
    await message.answer("🗑 কোন গ্রাহক মুছবেন? Customer ID লিখুন:")


@router.message(DeleteCustomer.waiting_id)
async def delete_pick(message: Message, state: FSMContext) -> None:
    if await _cancelled(message, state):
        return
    text = (message.text or "").strip()
    if not text.isdigit():
        await message.answer("⚠ Customer ID সংখ্যায় দিন।")
        return
    await state.clear()
    await _delete_confirm_prompt(message, int(text))


async def _delete_confirm_prompt(message: Message, customer_id: int) -> None:
    customer = await customer_service.get(customer_id)
    if customer is None:
        await message.answer(
            "⚠ এই আইডির কোনো গ্রাহক পাওয়া যায়নি।",
            reply_markup=owner_main_menu(),
        )
        return
    await message.answer(
        customer_profile(customer)
        + "\n\n⚠ <b>এই গ্রাহক স্থায়ীভাবে মুছে ফেলবেন?</b>",
        reply_markup=confirm_kb("delcustomer", customer_id),
    )


@router.callback_query(F.data.startswith("delcustomer:"))
async def delete_confirm(callback: CallbackQuery) -> None:
    _, decision, cid = callback.data.split(":")
    if decision == "yes":
        ok = await customer_service.delete(int(cid))
        text = (
            f"🗑 গ্রাহক #{cid} মুছে ফেলা হয়েছে।"
            if ok
            else "⚠ গ্রাহক পাওয়া যায়নি।"
        )
    else:
        text = "❌ মুছে ফেলা বাতিল করা হয়েছে।"
    if callback.message is not None:
        await callback.message.edit_text(text)
    await callback.answer()


async def _edit_balance(
    message: Message, state: FSMContext, customer_id: int, raw: str
) -> None:
    """ব্যালান্স এডিট — সরাসরি সেট অথবা +/- দিয়ে পরিবর্তন।"""
    text = raw.strip().replace("৳", "").strip()
    signed = bool(text) and text[0] in "+-"
    try:
        amount = float(text)
    except ValueError:
        await message.answer("⚠ সঠিক সংখ্যা দিন (যেমন 500, +100, -50)।")
        return
    await state.clear()
    if signed:
        customer = await customer_service.adjust_balance(customer_id, amount)
    else:
        customer = await customer_service.set_balance(customer_id, amount)
    if customer is None:
        await message.answer("⚠ গ্রাহক পাওয়া যায়নি।", reply_markup=owner_main_menu())
        return
    settled = float(getattr(customer, "last_settled", 0.0) or 0.0)
    settle_note = (
        f"🧾 বকেয়া কাটা হয়েছে: {date_utils.fmt_money(settled)}\n\n"
        if settled > 0 else ""
    )
    await message.answer(
        "✅ <b>ব্যালান্স আপডেট হয়েছে!</b>\n\n" + settle_note + customer_profile(customer),
        reply_markup=owner_main_menu(),
    )


async def _edit_date(
    message: Message, state: FSMContext, customer_id: int, field: str, raw: str
) -> None:
    """শুরু/মেয়াদের তারিখ এডিট।"""
    parsed = date_utils.parse_date(raw)
    if parsed is None:
        await message.answer(
            "⚠ তারিখ বুঝতে পারিনি। ফরম্যাট: 2026-06-15 বা 15-06-2026।",
            reply_markup=cancel_kb(),
        )
        return
    await state.clear()
    if field == "start_date":
        customer = await customer_service.update_dates(customer_id, start_date=parsed)
    else:
        customer = await customer_service.update_dates(customer_id, expiry_date=parsed)
    if customer is None:
        await message.answer("⚠ গ্রাহক পাওয়া যায়নি।", reply_markup=owner_main_menu())
        return
    await message.answer(
        "✅ <b>তারিখ আপডেট হয়েছে!</b>\n\n" + customer_profile(customer),
        reply_markup=owner_main_menu(),
    )


@router.message(Command("purchases"))
async def purchases_cmd(message: Message) -> None:
    """গ্রাহকের প্যাকেজ ক্রয় ইতিহাস।"""
    parts = (message.text or "").split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("ব্যবহার: /purchases &lt;আইডি&gt;")
        return
    customer_id = int(parts[1])
    customer = await customer_service.get(customer_id)
    if customer is None:
        await message.answer("⚠ এই আইডির কোনো গ্রাহক পাওয়া যায়নি।")
        return
    purchases = await customer_service.get_purchases(customer_id)
    if not purchases:
        await message.answer(
            f"📜 <b>{customer.name}</b> — কোনো প্যাকেজ ক্রয়ের রেকর্ড নেই।"
        )
        return
    lines = [f"📜 <b>{customer.name} — ক্রয় ইতিহাস</b>\n"]
    for p in purchases[:50]:
        lines.append(purchase_row(p))
    await message.answer("\n".join(lines))


# ===================== USER INFO (সব গ্রাহকের তালিকা → বিস্তারিত + এডিট) =====================
@router.message(Command("users"))
@router.message(F.text == "👤 ইউজার ইনফো")
async def users_info(message: Message, state: FSMContext) -> None:
    """সব গ্রাহকের নাম আলাদা বাটনে দেখায়।"""
    await state.clear()
    customers = await customer_service.list_all()
    if not customers:
        await message.answer(
            "👥 এখনো কোনো গ্রাহক যোগ করা হয়নি।",
            reply_markup=owner_main_menu(),
        )
        return
    await message.answer(
        f"👥 <b>মোট গ্রাহক: {date_utils.to_bn_digits(len(customers))}</b>\n"
        "নিচ থেকে যেকোনো গ্রাহকের নামে চাপ দিন — বিস্তারিত তথ্য ও এডিট অপশন আসবে।",
        reply_markup=customers_list_kb(customers),
    )


@router.callback_query(F.data.startswith("userinfo:"))
async def user_info_open(callback: CallbackQuery, state: FSMContext) -> None:
    _, cid = callback.data.split(":")
    await _show_user_info(callback.message, state, int(cid))
    await callback.answer()


async def _show_user_info(
    message: Message, state: FSMContext, customer_id: int
) -> None:
    """গ্রাহকের পূর্ণ প্রোফাইল + প্যাকেজ ক্রয় ইতিহাস + এডিট বাটন।"""
    customer = await customer_service.get(customer_id)
    if customer is None:
        await state.clear()
        await message.answer(
            "⚠ এই আইডির কোনো গ্রাহক পাওয়া যায়নি।",
            reply_markup=owner_main_menu(),
        )
        return
    text = customer_profile(customer)
    purchases = await customer_service.get_purchases(customer_id)
    if purchases:
        lines = ["\n\n📜 <b>প্যাকেজ ক্রয় ইতিহাস:</b>"]
        for p in purchases[:20]:
            lines.append(purchase_row(p))
        text += "\n".join(lines)
    await state.update_data(customer_id=customer_id)
    await state.set_state(EditCustomer.choosing_field)
    can_set_tgid = customer.telegram_id is None
    await message.answer(
        text + "\n\n✏ কোন তথ্য পরিবর্তন করবেন? (টাকা / তারিখ / সব)",
        reply_markup=edit_fields_kb(customer_id, can_set_tgid=can_set_tgid),
    )


# ===================== গ্লোবাল বাতিল (যেকোনো owner FSM ধাপ) =====================
@router.callback_query(F.data == "owner:cancel")
async def owner_cancel_cb(callback: CallbackQuery, state: FSMContext) -> None:
    """❌ বাতিল ইনলাইন বাটন চাপলে যেকোনো চলমান ধাপ বন্ধ করে মেনুতে ফেরত।"""
    await state.clear()
    if callback.message is not None:
        await callback.message.answer(
            "❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu()
        )
    await callback.answer()


# ===================== ব্যান / আনব্যান =====================
async def _set_ban_and_notify(callback: CallbackQuery, banned: bool) -> None:
    """গ্রাহককে ব্যান/আনব্যান করে, প্রোফাইল কার্ড হালনাগাদ করে ও গ্রাহককে জানায়।"""
    try:
        cid = int((callback.data or "").split(":")[1])
    except (IndexError, ValueError):
        await callback.answer("⚠ ভুল অনুরোধ।", show_alert=True)
        return
    customer = await customer_service.get(cid)
    if customer is None:
        await callback.answer("⚠ গ্রাহক পাওয়া যায়নি।", show_alert=True)
        return
    await customer_service.update_fields(cid, is_banned=banned)
    customer = await customer_service.get(cid)
    if callback.message is not None and customer is not None:
        with suppress(TelegramBadRequest):
            await callback.message.edit_text(
                customer_profile(customer),
                reply_markup=customer_profile_kb(customer),
            )
    if customer is not None and customer.telegram_id:
        if banned:
            note = (
                "⛔ <b>আপনাকে অ্যাডমিন ব্যান করেছেন।</b>\n"
                "আপাতত অ্যাডমিনের কাছে কোনো অনুরোধ (ডিপোজিট/প্যাকেজ) পাঠানো যাবে না।\n"
                "বিস্তারিত জানতে সাপোর্টে যোগাযোগ করুন।"
            )
        else:
            note = (
                "✅ <b>আপনার ব্যান তুলে নেওয়া হয়েছে।</b>\n"
                "এখন থেকে আবার স্বাভাবিকভাবে অনুরোধ পাঠাতে পারবেন।"
            )
        with suppress(Exception):
            await callback.bot.send_message(customer.telegram_id, note)
    await callback.answer("✅ ব্যান করা হয়েছে।" if banned else "✅ আনব্যান করা হয়েছে।")


@router.callback_query(F.data.startswith("custban:"))
async def customer_ban(callback: CallbackQuery) -> None:
    await _set_ban_and_notify(callback, True)


@router.callback_query(F.data.startswith("custunban:"))
async def customer_unban(callback: CallbackQuery) -> None:
    await _set_ban_and_notify(callback, False)
