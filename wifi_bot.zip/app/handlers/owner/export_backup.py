"""এক্সপোর্ট ও ব্যাকআপ হ্যান্ডলার — /export, /backup, /restore।"""

from __future__ import annotations

import os

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, Message

from app.config import settings
from app.keyboards.owner_kb import (
    export_backup_kb,
    import_confirm_kb,
    owner_main_menu,
)
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.backup_service import backup_service
from app.services.export_service import export_service
from app.states.states import ImportData
from app.utils.date_utils import to_bn_digits
from app.utils.logger import get_logger

log = get_logger(__name__)

router = Router(name="owner-export-backup")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())


@router.message(Command("export"))
@router.message(F.text == "\U0001f5c2 \u098f\u0995\u09cd\u09b8\u09aa\u09cb\u09b0\u09cd\u099f / \u09ac\u09cd\u09af\u09be\u0995\u0986\u09aa")
async def export_menu(message: Message) -> None:
    await message.answer("\U0001f5c2 \u0995\u09bf \u0995\u09b0\u09a4\u09c7 \u099a\u09be\u09a8?", reply_markup=export_backup_kb())


@router.callback_query(F.data == "export:excel")
async def export_excel(callback: CallbackQuery) -> None:
    await callback.answer("\u098f\u0995\u09cd\u09b8\u09aa\u09cb\u09b0\u09cd\u099f \u09b9\u099a\u09cd\u099b\u09c7...")
    path = await export_service.export_excel()
    await callback.message.answer_document(FSInputFile(path), caption="\U0001f4d7 Excel \u098f\u0995\u09cd\u09b8\u09aa\u09cb\u09b0\u09cd\u099f")


@router.callback_query(F.data == "export:csv")
async def export_csv(callback: CallbackQuery) -> None:
    await callback.answer("\u098f\u0995\u09cd\u09b8\u09aa\u09cb\u09b0\u09cd\u099f \u09b9\u099a\u09cd\u099b\u09c7...")
    paths = await export_service.export_csv()
    for path in paths:
        await callback.message.answer_document(FSInputFile(path))
    await callback.message.answer("\u2705 CSV \u098f\u0995\u09cd\u09b8\u09aa\u09cb\u09b0\u09cd\u099f \u09b6\u09c7\u09b7\u0964")


@router.callback_query(F.data == "backup:run")
async def backup_run(callback: CallbackQuery) -> None:
    await callback.answer("\u09ac\u09cd\u09af\u09be\u0995\u0986\u09aa \u09a8\u09c7\u0993\u09af\u09bc\u09be \u09b9\u099a\u09cd\u099b\u09c7...")
    result = await backup_service.run_full_backup()
    await callback.message.answer_document(FSInputFile(result["json"]), caption="\U0001f4be JSON \u09ac\u09cd\u09af\u09be\u0995\u0986\u09aa")
    if result.get("database"):
        await callback.message.answer_document(FSInputFile(result["database"]), caption="\U0001f5c4 \u09a1\u09be\u099f\u09be\u09ac\u09c7\u09b8 \u09ac\u09cd\u09af\u09be\u0995\u0986\u09aa")


@router.message(Command("backup"))
async def backup_cmd(message: Message) -> None:
    result = await backup_service.run_full_backup()
    await message.answer_document(FSInputFile(result["json"]), caption="\U0001f4be JSON \u09ac\u09cd\u09af\u09be\u0995\u0986\u09aa")
    if result.get("database"):
        await message.answer_document(FSInputFile(result["database"]), caption="\U0001f5c4 \u09a1\u09be\u099f\u09be\u09ac\u09c7\u09b8 \u09ac\u09cd\u09af\u09be\u0995\u0986\u09aa")


@router.message(Command("restore"))
async def restore_cmd(message: Message) -> None:
    """সর্বশেষ JSON ব্যাকআপ থেকে রিস্টোর।"""
    count = await backup_service.restore_json()
    if count < 0:
        await message.answer("\u26a0 \u0995\u09cb\u09a8\u09cb \u09ac\u09cd\u09af\u09be\u0995\u0986\u09aa \u09ab\u09be\u0987\u09b2 \u09aa\u09be\u0993\u09af\u09bc\u09be \u09af\u09be\u09af\u09bc\u09a8\u09bf\u0964", reply_markup=owner_main_menu())
        return
    from app.utils.date_utils import to_bn_digits
    await message.answer(f"\u2705 \u09b0\u09bf\u09b8\u09cd\u099f\u09cb\u09b0 \u09b8\u09ab\u09b2\u0964 {to_bn_digits(count)} \u099c\u09a8 \u0997\u09cd\u09b0\u09be\u09b9\u0995 \u09aa\u09c1\u09a8\u09b0\u09c1\u09a6\u09cd\u09a7\u09be\u09b0 \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964", reply_markup=owner_main_menu())


_IMPORT_DIR = os.path.join("backups", "imports")
_CANCEL_WORDS = {"বাতিল", "cancel", "/cancel"}
_TABLE_LABELS = {
    "customers": "গ্রাহক",
    "packages": "প্যাকেজ",
    "payments": "পেমেন্ট",
    "renewal_history": "রিনিউয়াল",
    "payment_requests": "পেমেন্ট রিকোয়েস্ট",
    "app_settings": "সেটিংস/টেক্সট",
    "redeem_codes": "রিডিম কোড",
    "redeem_uses": "রিডিম ব্যবহার",
    "package_purchases": "প্যাকেজ পারচেজ",
}


def _summary_text(counts: dict) -> str:
    lines = []
    for key, label in _TABLE_LABELS.items():
        lines.append(f"• {label}: {to_bn_digits(counts.get(key, 0))}")
    return "\n".join(lines)


@router.callback_query(F.data == "export:full")
async def export_full_cb(callback: CallbackQuery) -> None:
    await callback.answer("পূর্ণ এক্সপোর্ট হচ্ছে...")
    path = await backup_service.export_full()
    await callback.message.answer_document(
        FSInputFile(path),
        caption=(
            "🗄 <b>পূর্ণ এক্সপোর্ট</b>\n\n"
            "এই এক ফাইলেই বটের সব তথ্য আছে (গ্রাহক, প্যাকেজ, পেমেন্ট, সেটিংস — সব)।\n"
            "নিরাপদে রেখে দিন। পরে ফেরাতে ‘📥 ইমপোর্ট’ দিয়ে এই ফাইলটি পাঠান।"
        ),
    )


@router.callback_query(F.data == "import:start")
async def import_start_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(ImportData.waiting_file)
    if callback.message is not None:
        await callback.message.answer(
            "📥 <b>ইমপোর্ট / রিস্টোর</b>\n\n"
            "পূর্ণ এক্সপোর্ট করা <b>JSON ফাইলটি</b> এখানে ডকুমেন্ট হিসেবে পাঠান।\n\n"
            "<i>বাতিল করতে ‘বাতিল’ লিখুন।</i>"
        )
    await callback.answer()


@router.message(ImportData.waiting_file, F.document)
async def import_file_received(message: Message, state: FSMContext) -> None:
    document = message.document
    os.makedirs(_IMPORT_DIR, exist_ok=True)
    dest = os.path.join(_IMPORT_DIR, document.file_name or "import.json")
    try:
        tg_file = await message.bot.get_file(document.file_id)
        await message.bot.download_file(tg_file.file_path, dest)
    except Exception as exc:  # noqa: BLE001
        log.error("Import download failed: %s", exc)
        await state.clear()
        await message.answer(
            "⚠ ফাইলটি ডাউনলোড করা যায়নি। আবার চেষ্টা করুন।",
            reply_markup=owner_main_menu(),
        )
        return
    try:
        data = backup_service.load_export(dest)
    except ValueError as exc:
        await state.clear()
        await message.answer(
            f"⚠ {exc}\n\nসঠিক এক্সপোর্ট ফাইল পাঠিয়ে আবার চেষ্টা করুন।",
            reply_markup=owner_main_menu(),
        )
        return
    counts = backup_service.summarize(data)
    await state.update_data(import_path=dest)
    await state.set_state(ImportData.confirm)
    await message.answer(
        "⚠ <b>সতর্কতা — নিশ্চিত করুন</b>\n\n"
        "এই ফাইল থেকে রিস্টোর করলে <b>বর্তমান সব ডেটা মুছে</b> নিচের ডেটা বসবে:\n\n"
        + _summary_text(counts)
        + "\n\n<b>এটি ফেরানো যাবে না।</b> চালিয়ে যাবেন?",
        reply_markup=import_confirm_kb(),
    )


@router.message(ImportData.waiting_file)
async def import_waiting_text(message: Message, state: FSMContext) -> None:
    if (message.text or "").strip().lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ ইমপোর্ট বাতিল হয়েছে।", reply_markup=owner_main_menu())
        return
    await message.answer(
        "📄 অনুগ্রহ করে এক্সপোর্ট করা JSON ফাইলটি ডকুমেন্ট হিসেবে পাঠান, অথবা ‘বাতিল’ লিখুন।"
    )


@router.callback_query(F.data == "import:cancel")
async def import_cancel_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.answer("বাতিল হয়েছে।")
    if callback.message is not None:
        await callback.message.answer("❌ ইমপোর্ট বাতিল হয়েছে।", reply_markup=owner_main_menu())


@router.callback_query(F.data == "import:confirm", ImportData.confirm)
async def import_confirm_cb(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    path = data.get("import_path")
    await callback.answer("রিস্টোর হচ্ছে...")
    if not path or not os.path.exists(path):
        await state.clear()
        if callback.message is not None:
            await callback.message.answer(
                "⚠ ইমপোর্ট ফাইল পাওয়া যায়নি। আবার চেষ্টা করুন।",
                reply_markup=owner_main_menu(),
            )
        return
    try:
        export_data = backup_service.load_export(path)
        counts = await backup_service.import_full(export_data)
    except Exception as exc:  # noqa: BLE001
        log.error("Import failed: %s", exc)
        await state.clear()
        if callback.message is not None:
            await callback.message.answer(
                "⚠ রিস্টোর ব্যর্থ হয়েছে। ফাইলটি ঠিক আছে কিনা দেখে আবার চেষ্টা করুন।",
                reply_markup=owner_main_menu(),
            )
        return
    await state.clear()
    if callback.message is not None:
        await callback.message.answer(
            "✅ <b>রিস্টোর সফল!</b> বটের ডেটা হুবহু ফিরিয়ে আনা হয়েছে।\n\n"
            + _summary_text(counts)
            + "\n\n<i>এখন বটে /start চাপুন।</i>",
            reply_markup=owner_main_menu(),
        )
