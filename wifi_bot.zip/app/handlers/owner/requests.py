"""পেমেন্ট অনুরোধ হ্যান্ডলার (Admin) — pending তালিকা, Approve / Reject।"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.keyboards.owner_kb import owner_main_menu, request_action_kb
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.request_service import request_service
from app.utils import date_utils
from app.utils.formatters import request_card
from app.utils.logger import get_logger

log = get_logger(__name__)

router = Router(name="owner-requests")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())


async def _strip_buttons(callback: CallbackQuery) -> None:
    try:
        await callback.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass


async def _notify_customer(callback: CallbackQuery, customer, text: str) -> None:
    if customer is None or not customer.telegram_id:
        return
    try:
        await callback.bot.send_message(customer.telegram_id, text)
    except Exception as exc:
        log.warning("Customer notify failed: %s", exc)


@router.message(Command("requests"))
@router.message(F.text == "📥 অনুরোধ")
async def requests_menu(message: Message) -> None:
    pending = await request_service.list_pending()
    if not pending:
        await message.answer(
            "✅ এই মুহূর্তে কোনো অপেক্ষমাণ অনুরোধ নেই।",
            reply_markup=owner_main_menu(),
        )
        return
    await message.answer(
        f"📥 <b>অপেক্ষমাণ অনুরোধ:</b> {date_utils.to_bn_digits(len(pending))} টি"
    )
    for req in pending:
        await message.answer(request_card(req), reply_markup=request_action_kb(req.id))


@router.callback_query(F.data.startswith("req:approve:"))
async def req_approve(callback: CallbackQuery) -> None:
    req_id = int(callback.data.split(":")[2])
    code, req, customer, info = await request_service.approve(req_id)
    if code == "not_found":
        await callback.answer("অনুরোধটি পাওয়া যায়নি।", show_alert=True)
        return
    if code == "already":
        await callback.answer("এই অনুরোধটি ইতিমধ্যে প্রক্রিয়া করা হয়েছে।", show_alert=True)
        await _strip_buttons(callback)
        return
    if code == "no_customer":
        await callback.answer(
            "সংশ্লিষ্ট গ্রাহক পাওয়া যায়নি। আগে গ্রাহক যোগ করুন।",
            show_alert=True,
        )
        return
    if code == "insufficient":
        await callback.answer(
            "গ্রাহকের ব্যালান্স যথেষ্ট নয়। গ্রাহককে আগে টাকা জমা করতে বলুন।",
            show_alert=True,
        )
        return
    await _strip_buttons(callback)
    if code == "deposit_ok":
        applied = float(info.get("applied_to_due") or 0.0)
        due_line = (
            f"\n🧾 বকেয়া পরিশোধ: {date_utils.fmt_money(applied)}" if applied > 0 else ""
        )
        await callback.message.answer(
            "✅ ডিপোজিট অনুমোদিত।\n"
            f"👤 {customer.name} (#{date_utils.to_bn_digits(customer.id)})\n"
            f"💵 {date_utils.fmt_money(req.amount)} যোগ হয়েছে।"
            f"{due_line}\n"
            f"💰 নতুন ব্যালান্স: {date_utils.fmt_money(customer.balance)}"
        )
        if applied > 0:
            cust_text = (
                f"✅ আপনার {date_utils.fmt_money(req.amount)} ডিপোজিট অনুমোদিত হয়েছে।\n"
                f"🧾 এখান থেকে আপনার বকেয়া {date_utils.fmt_money(applied)} কেটে নেওয়া হয়েছে।\n"
                f"💰 বর্তমান ব্যালান্স: {date_utils.fmt_money(customer.balance)}"
            )
        else:
            cust_text = (
                f"✅ আপনার {date_utils.fmt_money(req.amount)} ডিপোজিট অনুমোদিত হয়েছে।\n"
                f"💰 বর্তমান ব্যালান্স: {date_utils.fmt_money(customer.balance)}"
            )
        await _notify_customer(callback, customer, cust_text)
    elif code == "package_ok":
        new_due = float(info.get("new_due") or 0.0)
        pay_now = float(info.get("pay_now") or 0.0)
        owner_credit = (
            f"\n💵 নগদ (ব্যালান্স): {date_utils.fmt_money(pay_now)}"
            f"\n❌ বকেয়া: {date_utils.fmt_money(new_due)}"
            if new_due > 0 else ""
        )
        await callback.message.answer(
            "✅ প্যাকেজ অনুমোদিত।\n"
            f"👤 {customer.name} (#{date_utils.to_bn_digits(customer.id)})\n"
            f"📦 {req.package_name}"
            f"{owner_credit}\n"
            f"⏳ নতুন মেয়াদ: {date_utils.fmt_date(customer.expiry_date)}\n"
            f"💰 অবশিষ্ট ব্যালান্স: {date_utils.fmt_money(customer.balance)}"
        )
        cust_credit = (
            f"\n🧾 এখন {date_utils.fmt_money(pay_now)} কাটা হয়েছে, "
            f"বকেয়া {date_utils.fmt_money(new_due)} রইল।"
            if new_due > 0 else ""
        )
        await _notify_customer(
            callback,
            customer,
            f"✅ আপনার প্যাকেজ <b>{req.package_name}</b> চালু হয়েছে।"
            f"{cust_credit}\n"
            f"⏳ মেয়াদ: {date_utils.fmt_date(customer.expiry_date)} পর্যন্ত\n"
            f"💰 অবশিষ্ট ব্যালান্স: {date_utils.fmt_money(customer.balance)}",
        )
    await callback.answer("অনুমোদিত হয়েছে।")


@router.callback_query(F.data.startswith("req:reject:"))
async def req_reject(callback: CallbackQuery) -> None:
    req_id = int(callback.data.split(":")[2])
    req = await request_service.reject(req_id)
    if req is None:
        await callback.answer("অনুরোধটি পাওয়া যায়নি।", show_alert=True)
        return
    await _strip_buttons(callback)
    await callback.message.answer("❌ অনুরোধটি বাতিল করা হয়েছে।")
    if req.telegram_id:
        try:
            await callback.bot.send_message(
                req.telegram_id,
                "❌ দুঃখিত, আপনার পেমেন্ট অনুরোধটি এডমিন বাতিল করেছেন।\n"
                "প্রয়োজনে এডমিনের সাথে যোগাযোগ করুন।",
            )
        except Exception as exc:
            log.warning("Reject notify failed: %s", exc)
    await callback.answer("বাতিল করা হয়েছে।")
