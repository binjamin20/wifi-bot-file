"""রিডিম কোড ব্যবস্থাপনা হ্যান্ডলার (owner)।"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings as app_settings
from app.keyboards.owner_kb import cancel_kb, owner_main_menu, redeem_admin_kb
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.redeem_service import redeem_service
from app.states.states import RedeemAdmin
from app.utils.date_utils import fmt_money, to_bn_digits

router = Router(name="owner-redeem")
router.message.filter(F.from_user.id == app_settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())

_CANCEL_WORDS = {"cancel", "/cancel", "বাতিল"}


async def _redeem_view():
    codes = await redeem_service.list_all()
    lines = ["🎟 <b>রিডিম কোড</b>\n"]
    if not codes:
        lines.append("<i>এখনো কোনো কোড তৈরি হয়নি।</i>")
    else:
        for rc in codes[:30]:
            badge = "🟢" if rc.is_active else "⚪"
            lines.append(
                f"{badge} <code>{rc.code}</code> — {fmt_money(rc.amount)} "
                f"({to_bn_digits(rc.used_count)}/{to_bn_digits(rc.max_uses)} ব্যবহার)"
            )
    return "\n".join(lines), redeem_admin_kb(codes)


async def _show_redeem(message: Message) -> None:
    text, kb = await _redeem_view()
    await message.answer(text, reply_markup=kb)


@router.message(Command("redeem"))
@router.message(F.text == "🎟 রিডিম কোড")
async def redeem_menu(message: Message, state: FSMContext) -> None:
    await state.clear()
    await _show_redeem(message)


@router.callback_query(F.data == "redeem:new")
async def redeem_new(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(RedeemAdmin.waiting_amount)
    await callback.message.answer(
        "💰 কোডের টাকার পরিমাণ লিখুন:\n"
        "<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


@router.message(RedeemAdmin.waiting_amount)
async def redeem_amount(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    try:
        amount = float(raw)
    except ValueError:
        await message.answer("⚠ সঠিক সংখ্যা দিন।")
        return
    if amount <= 0:
        await message.answer("⚠ পরিমাণ ০-এর বেশি হতে হবে।")
        return
    await state.update_data(amount=amount)
    await state.set_state(RedeemAdmin.waiting_uses)
    await message.answer("👥 এই কোড সর্বোচ্চ কতবার ব্যবহার করা যাবে? (সংখ্যা):")


@router.message(RedeemAdmin.waiting_uses)
async def redeem_uses(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("⚠ ১ বা তার বেশি সংখ্যা দিন।")
        return
    data = await state.get_data()
    await state.clear()
    amount = float(data.get("amount") or 0)
    rc = await redeem_service.create(amount=amount, max_uses=int(raw))
    await message.answer(
        "✅ <b>রিডিম কোড তৈরি হয়েছে!</b>\n\n"
        f"🎟 কোড: <code>{rc.code}</code>\n"
        f"💰 পরিমাণ: {fmt_money(rc.amount)}\n"
        f"👥 ব্যবহারসীমা: {to_bn_digits(rc.max_uses)} বার",
        reply_markup=owner_main_menu(),
    )


@router.callback_query(F.data.startswith("redeem:off:"))
async def redeem_off(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    try:
        code_id = int(callback.data.split(":")[2])
    except (IndexError, ValueError):
        await callback.answer("ভুল অনুরোধ।", show_alert=True)
        return
    codes = await redeem_service.list_all()
    target = next((c for c in codes if c.id == code_id), None)
    if target is None:
        await callback.answer("কোড পাওয়া যায়নি।", show_alert=True)
        return
    if not target.is_active:
        await callback.answer("এই কোড আগেই বন্ধ আছে।", show_alert=True)
        return
    await redeem_service.set_active(code_id, False)
    await callback.answer("⏸ কোডটি স্থায়ীভাবে বন্ধ করা হয়েছে।")
    text, kb = await _redeem_view()
    try:
        await callback.message.edit_text(text, reply_markup=kb)
    except Exception:
        await callback.message.answer(text, reply_markup=kb)
