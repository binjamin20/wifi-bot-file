"""Owner ড্যাশবোর্ড হ্যান্ডলার — /start (owner), /dashboard।"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

from app.config import settings
from app.keyboards.owner_kb import owner_main_menu
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.report_service import report_service
from app.utils.date_utils import fmt_money, to_bn_digits

router = Router(name="owner-dashboard")
# এই router শুধু owner-এর জন্য
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())


async def _render_dashboard() -> str:
    d = await report_service.dashboard()
    return (
        "\U0001f4ca <b>\u098f\u09a1\u09ae\u09bf\u09a8 \u09a1\u09cd\u09af\u09be\u09b6\u09ac\u09cb\u09b0\u09cd\u09a1</b>\n\n"
        f"\U0001f465 \u09ae\u09cb\u099f \u0997\u09cd\u09b0\u09be\u09b9\u0995: {to_bn_digits(d.total)}\n"
        f"\U0001f7e2 \u098f\u0995\u09cd\u099f\u09bf\u09ad: {to_bn_digits(d.active)}\n"
        f"\U0001f534 \u09ae\u09c7\u09af\u09bc\u09be\u09a6\u09cb\u09a4\u09cd\u09a4\u09c0\u09b0\u09cd\u09a3: {to_bn_digits(d.expired)}\n"
        f"\u26a0 \u09b6\u09c0\u0998\u09cd\u09b0\u0987 \u09b6\u09c7\u09b7: {to_bn_digits(d.expiring_soon)}\n"
        f"\U0001f4b0 \u0986\u099c\u0995\u09c7\u09b0 \u0986\u09a6\u09be\u09af\u09bc: {fmt_money(d.today_collection)}\n"
        f"\U0001f4b0 \u098f \u09ae\u09be\u09b8\u09c7\u09b0 \u0986\u09a6\u09be\u09af\u09bc: {fmt_money(d.month_collection)}\n"
        f"\U0001f4cb \u09ae\u09cb\u099f \u09ac\u0995\u09c7\u09af\u09bc\u09be: {fmt_money(d.total_due)}"
    )


@router.message(CommandStart())
async def owner_start(message: Message) -> None:
    """Owner /start — স্বাগতম + মেনু।"""
    await message.answer(
        "\U0001f44b <b>\u09b8\u09cd\u09ac\u09be\u0997\u09a4\u09ae, \u098f\u09a1\u09ae\u09bf\u09a8!</b>\n"
        "\u09a8\u09bf\u099a\u09c7\u09b0 \u09ae\u09c7\u09a8\u09c1 \u09a5\u09c7\u0995\u09c7 \u0995\u09be\u099c \u09ac\u09c7\u099b\u09c7 \u09a8\u09bf\u09a8 \U0001f447",
        reply_markup=owner_main_menu(),
    )


@router.message(Command("dashboard"))
@router.message(F.text == "\U0001f4ca \u09a1\u09cd\u09af\u09be\u09b6\u09ac\u09cb\u09b0\u09cd\u09a1")
async def show_dashboard(message: Message) -> None:
    await message.answer(await _render_dashboard(), reply_markup=owner_main_menu())
