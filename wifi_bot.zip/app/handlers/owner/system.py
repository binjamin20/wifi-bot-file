"""সিস্টেম মেনু হ্যান্ডলার — Force Join, প্যাকেজ, পেমেন্ট সেটিংস ও ইউজার ম্যানেজমেন্ট।

শুধু এডমিন (owner_id) এই মেনুগুলো ব্যবহার করতে পারবে।
"""

from __future__ import annotations

from datetime import timedelta

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.handlers.owner.packages import _show_list as _show_packages
from app.handlers.owner.settings import _show_settings as _show_payment_settings
from app.keyboards.owner_kb import (
    back_user_kb,
    banned_user_kb,
    banned_users_list_kb,
    cancel_kb,
    force_join_menu_kb,
    manage_balance_kb,
    manage_date_kb,
    manage_details_kb,
    system_menu_kb,
    um_tgid_conflict_kb,
    user_manage_kb,
    user_mgmt_list_kb,
)
from app.services.customer_service import customer_service
from app.services.settings_service import settings_service
from app.states.states import ForceJoinAdmin, ManageUser
from app.utils import date_utils, validators
from app.utils.date_utils import fmt_date, fmt_money, to_bn_digits
from app.utils.formatters import customer_profile

router = Router(name="owner-system")
router.message.filter(F.from_user.id == settings.owner_id)
router.callback_query.filter(F.from_user.id == settings.owner_id)

NL = chr(10)
PAGE_SIZE = 8
_CANCEL_WORDS = {"cancel", "/cancel", "বাতিল"}

_SYSTEM_TEXT = f"🛠 <b>সিস্টেম মেনু</b>{NL}{NL}নিচ থেকে যা ম্যানেজ করতে চান বেছে নিন:"


# ===================== সিস্টেম মেনু =====================
@router.message(Command("system"))
@router.message(F.text == "\U0001f6e0 সিস্টেম")
async def system_open(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(_SYSTEM_TEXT, reply_markup=system_menu_kb())


@router.callback_query(F.data == "sys:open")
async def system_open_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        try:
            await callback.message.edit_text(_SYSTEM_TEXT, reply_markup=system_menu_kb())
        except Exception:
            await callback.message.answer(_SYSTEM_TEXT, reply_markup=system_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "sys:close")
async def system_close_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        try:
            await callback.message.delete()
        except Exception:
            pass
    await callback.answer("মূল মেনুতে ফিরে গেলেন।")


@router.callback_query(F.data == "sys:pkg")
async def system_packages_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await _show_packages(callback.message)
    await callback.answer()


@router.callback_query(F.data == "sys:pay")
async def system_payment_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await _show_payment_settings(callback.message)
    await callback.answer()


# ===================== ফোর্স জয়েন =====================
async def _render_force_join(target: Message, edit: bool = False) -> None:
    enabled = await settings_service.is_force_join_enabled()
    channels = await settings_service.list_force_join_channels()
    status = "🟢 চালু" if enabled else "🔴 বন্ধ"
    if channels:
        ch_lines = NL.join(f"• {c}" for c in channels)
    else:
        ch_lines = "<i>কোনো চ্যানেল যোগ করা হয়নি।</i>"
    text = (
        f"🔗 <b>ফোর্স জয়েন সিস্টেম</b>{NL}{NL}"
        f"স্ট্যাটাস: <b>{status}</b>{NL}{NL}"
        f"<b>চ্যানেল তালিকা:</b>{NL}{ch_lines}{NL}{NL}"
        f"⚠ চালু থাকলে গ্রাহক চ্যানেলে জয়েন না করা পর্যন্ত বট ব্যবহার করতে পারবে না।{NL}"
        "<i>বটকে অবশ্যই ঐ চ্যানেলগুলোতে এডমিন হতে হবে।</i>"
    )
    kb = force_join_menu_kb(enabled, channels)
    if edit:
        try:
            await target.edit_text(text, reply_markup=kb)
            return
        except Exception:
            pass
    await target.answer(text, reply_markup=kb)


@router.callback_query(F.data == "sys:fj")
async def force_join_open_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await _render_force_join(callback.message, edit=True)
    await callback.answer()


@router.callback_query(F.data == "fja:toggle")
async def force_join_toggle_cb(callback: CallbackQuery) -> None:
    enabled = await settings_service.is_force_join_enabled()
    await settings_service.set_force_join_enabled(not enabled)
    if callback.message is not None:
        await _render_force_join(callback.message, edit=True)
    await callback.answer("✅ স্ট্যাটাস পরিবর্তিত হয়েছে।")


@router.callback_query(F.data == "fja:add")
async def force_join_add_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(ForceJoinAdmin.waiting_channel)
    if callback.message is not None:
        await callback.message.answer(
            "➕ চ্যানেলের ইউজারনেম বা লিংক পাঠান (যেমন @mychannel বা https://t.me/mychannel):",
            reply_markup=cancel_kb(),
        )
    await callback.answer()


@router.message(ForceJoinAdmin.waiting_channel)
async def force_join_add_value(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল হয়েছে।", reply_markup=system_menu_kb())
        return
    ch = await settings_service.add_force_join_channel(raw)
    await state.clear()
    if ch is None:
        await message.answer("⚠ সঠিক চ্যানেল ইউজারনেম/লিংক দিন।")
    else:
        await message.answer(f"✅ চ্যানেল যোগ হয়েছে: {ch}")
    await _render_force_join(message)


@router.callback_query(F.data.startswith("fja:del:"))
async def force_join_del_cb(callback: CallbackQuery) -> None:
    ch = (callback.data or "").split(":", 2)[2]
    removed = await settings_service.remove_force_join_channel(ch)
    if callback.message is not None:
        await _render_force_join(callback.message, edit=True)
    await callback.answer("🗑 মুছে ফেলা হয়েছে।" if removed else "পাওয়া যায়নি।")


# ===================== ইউজার ম্যানেজমেন্ট =====================
async def _render_user_list(target: Message, page: int, edit: bool = False) -> None:
    customers = await customer_service.list_all()
    today = date_utils.today()
    total = len(customers)
    active = sum(1 for c in customers if c.expiry_date is not None and c.expiry_date >= today)
    expired = total - active
    if page < 0:
        page = 0
    start = page * PAGE_SIZE
    if start >= total and total > 0:
        page = (total - 1) // PAGE_SIZE
        start = page * PAGE_SIZE
    page_items = customers[start:start + PAGE_SIZE]
    has_prev = page > 0
    has_next = start + PAGE_SIZE < total
    text = (
        f"👤 <b>ইউজার ম্যানেজমেন্ট</b>{NL}{NL}"
        f"মোট: <b>{to_bn_digits(total)}</b> · 🟢 এক্টিভ: <b>{to_bn_digits(active)}</b> · 🔴 মেয়াদোত্তীর্ণ: <b>{to_bn_digits(expired)}</b>{NL}{NL}"
        f"পৃষ্ঠা {to_bn_digits(page + 1)}"
    )
    if total == 0:
        text += f"{NL}{NL}<i>কোনো গ্রাহক নেই।</i>"
    kb = user_mgmt_list_kb(page_items, page, has_prev, has_next, today)
    if edit:
        try:
            await target.edit_text(text, reply_markup=kb)
            return
        except Exception:
            pass
    await target.answer(text, reply_markup=kb)


@router.callback_query(F.data == "sys:um")
async def user_mgmt_open_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await _render_user_list(callback.message, 0, edit=True)
    await callback.answer()


@router.callback_query(F.data.startswith("um:page:"))
async def user_mgmt_page_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    page = int((callback.data or "um:page:0").split(":")[2])
    if callback.message is not None:
        await _render_user_list(callback.message, page, edit=True)
    await callback.answer()


async def _render_banned_list(target: Message, page: int, edit: bool = False) -> None:
    customers = [c for c in await customer_service.list_all() if getattr(c, "is_banned", False)]
    total = len(customers)
    if page < 0:
        page = 0
    start = page * PAGE_SIZE
    if start >= total and total > 0:
        page = (total - 1) // PAGE_SIZE
        start = page * PAGE_SIZE
    page_items = customers[start:start + PAGE_SIZE]
    has_prev = page > 0
    has_next = start + PAGE_SIZE < total
    text = (
        f"🚫 <b>ব্যান্ড ইউজার</b>{NL}{NL}"
        f"মোট ব্যান: <b>{to_bn_digits(total)}</b>{NL}"
        f"পৃষ্ঠা {to_bn_digits(page + 1)}"
    )
    if total == 0:
        text += f"{NL}{NL}<i>কোনো ব্যান করা ইউজার নেই।</i>"
    kb = banned_users_list_kb(page_items, page, has_prev, has_next)
    if edit:
        try:
            await target.edit_text(text, reply_markup=kb)
            return
        except Exception:
            pass
    await target.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("um:banned:"))
async def banned_list_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    page = int((callback.data or "um:banned:0").split(":")[2])
    if callback.message is not None:
        await _render_banned_list(callback.message, page, edit=True)
    await callback.answer()


@router.callback_query(F.data.startswith("um:bshow:"))
async def banned_show_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    page = int(parts[3])
    customer = await customer_service.get(customer_id)
    if callback.message is not None and customer is not None:
        text = customer_profile(customer)
        try:
            await callback.message.edit_text(text, reply_markup=banned_user_kb(customer_id, page))
        except Exception:
            await callback.message.answer(text, reply_markup=banned_user_kb(customer_id, page))
    await callback.answer()


@router.callback_query(F.data.startswith("um:unban:"))
async def banned_unban_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    page = int(parts[3])
    customer = await customer_service.get(customer_id)
    if customer is None:
        await callback.answer("⚠ গ্রাহক পাওয়া যায়নি।", show_alert=True)
        return
    await customer_service.update_fields(customer_id, is_banned=False)
    if customer.telegram_id:
        note = (
            "✅ <b>আপনার ব্যান তুলে নেওয়া হয়েছে।</b>" + NL
            + "এখন থেকে আবার স্বাভাবিকভাবে অনুরোধ পাঠাতে পারবেন।"
        )
        try:
            await callback.bot.send_message(customer.telegram_id, note)
        except Exception:
            pass
    if callback.message is not None:
        await _render_banned_list(callback.message, page, edit=True)
    await callback.answer("✅ আনব্যান করা হয়েছে।")


async def _render_user_menu(target: Message, customer_id: int, page: int, edit: bool = False) -> None:
    customer = await customer_service.get(customer_id)
    if customer is None:
        await target.answer("⚠ গ্রাহক পাওয়া যায়নি।")
        return
    text = customer_profile(customer)
    kb = user_manage_kb(customer_id, page)
    if edit:
        try:
            await target.edit_text(text, reply_markup=kb)
            return
        except Exception:
            pass
    await target.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("um:user:"))
async def user_open_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    page = int(parts[3])
    if callback.message is not None:
        await _render_user_menu(callback.message, customer_id, page, edit=True)
    await callback.answer()


@router.callback_query(F.data.startswith("um:profile:"))
async def user_profile_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    page = int(parts[3])
    customer = await customer_service.get(customer_id)
    if callback.message is not None and customer is not None:
        text = customer_profile(customer)
        try:
            await callback.message.edit_text(text, reply_markup=back_user_kb(customer_id, page))
        except Exception:
            await callback.message.answer(text, reply_markup=back_user_kb(customer_id, page))
    await callback.answer()


@router.callback_query(F.data.startswith("um:details:"))
async def details_open_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    page = int(parts[3])
    customer = await customer_service.get(customer_id)
    if callback.message is not None and customer is not None:
        text = customer_profile(customer) + f"{NL}{NL}<i>নিচ থেকে যেকোনো তথ্য এডিট করুন (টাকা ও তারিখ আলাদা মেনুতে):</i>"
        try:
            await callback.message.edit_text(text, reply_markup=manage_details_kb(customer_id, page))
        except Exception:
            await callback.message.answer(text, reply_markup=manage_details_kb(customer_id, page))
    await callback.answer()


# ----- ব্যালেন্স -----
@router.callback_query(F.data.startswith("um:bal:"))
async def balance_open_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    page = int(parts[3])
    customer = await customer_service.get(customer_id)
    if callback.message is not None and customer is not None:
        text = (
            f"💰 <b>ব্যালেন্স ম্যানেজ</b>{NL}{NL}"
            f"গ্রাহক: <b>{customer.name}</b>{NL}"
            f"বর্তমান ব্যালেন্স: <b>{fmt_money(customer.balance)}</b>"
        )
        try:
            await callback.message.edit_text(text, reply_markup=manage_balance_kb(customer_id, page))
        except Exception:
            await callback.message.answer(text, reply_markup=manage_balance_kb(customer_id, page))
    await callback.answer()


@router.callback_query(F.data.startswith("um:baladd:"))
async def balance_add_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    await state.set_state(ManageUser.balance)
    await state.update_data(cid=int(parts[2]), page=int(parts[3]), op="add")
    if callback.message is not None:
        await callback.message.answer("➕ কত টাকা যোগ করবেন? পরিমাণ লিখুন:", reply_markup=cancel_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("um:balsub:"))
async def balance_sub_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    await state.set_state(ManageUser.balance)
    await state.update_data(cid=int(parts[2]), page=int(parts[3]), op="sub")
    if callback.message is not None:
        await callback.message.answer("➖ কত টাকা বিয়োগ করবেন? পরিমাণ লিখুন:", reply_markup=cancel_kb())
    await callback.answer()


@router.message(ManageUser.balance)
async def balance_value(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল হয়েছে।")
        return
    try:
        amount = validators.validate_amount(raw)
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    data = await state.get_data()
    cid = data.get("cid")
    page = data.get("page", 0)
    op = data.get("op", "add")
    delta = amount if op == "add" else -amount
    customer = await customer_service.adjust_balance(cid, delta)
    await state.clear()
    if customer is None:
        await message.answer("⚠ গ্রাহক পাওয়া যায়নি।")
        return
    settled = float(getattr(customer, "last_settled", 0.0) or 0.0)
    due_line = (
        f"\n🧾 বকেয়া কাটা হয়েছে: {fmt_money(settled)}"
        f"\n❌ অবশিষ্ট বকেয়া: {fmt_money(customer.due_amount)}"
        if settled > 0 else ""
    )
    await message.answer(
        f"✅ ব্যালেন্স আপডেট হয়েছে। নতুন ব্যালেন্স: <b>{fmt_money(customer.balance)}</b>"
        f"{due_line}"
    )
    await _render_user_menu(message, cid, page)


# ----- ডেট -----
@router.callback_query(F.data.startswith("um:date:"))
async def date_open_cb(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    page = int(parts[3])
    customer = await customer_service.get(customer_id)
    if callback.message is not None and customer is not None:
        text = (
            f"📅 <b>ডেট ম্যানেজ</b>{NL}{NL}"
            f"গ্রাহক: <b>{customer.name}</b>{NL}"
            f"শুরুর তারিখ: <b>{fmt_date(customer.start_date)}</b>{NL}"
            f"মেয়াদ শেষ: <b>{fmt_date(customer.expiry_date)}</b>{NL}{NL}"
            "<i>সরাসরি তারিখ এডিট করুন (স্বাধীনভাবে) অথবা দিন +/- করুন।</i>"
        )
        try:
            await callback.message.edit_text(text, reply_markup=manage_date_kb(customer_id, page))
        except Exception:
            await callback.message.answer(text, reply_markup=manage_date_kb(customer_id, page))
    await callback.answer()


@router.callback_query(F.data.startswith("um:dstart:"))
async def date_start_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    await state.set_state(ManageUser.date_value)
    await state.update_data(cid=int(parts[2]), page=int(parts[3]), field="start")
    if callback.message is not None:
        await callback.message.answer("📅 নতুন শুরুর তারিখ লিখুন (YYYY-MM-DD বা DD-MM-YYYY):", reply_markup=cancel_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("um:dend:"))
async def date_end_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    await state.set_state(ManageUser.date_value)
    await state.update_data(cid=int(parts[2]), page=int(parts[3]), field="end")
    if callback.message is not None:
        await callback.message.answer("⏳ নতুন মেয়াদ তারিখ লিখুন (YYYY-MM-DD বা DD-MM-YYYY):", reply_markup=cancel_kb())
    await callback.answer()


@router.message(ManageUser.date_value)
async def date_value_set(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল হয়েছে।")
        return
    parsed = date_utils.parse_date(raw)
    if parsed is None:
        await message.answer("⚠ সঠিক তারিখ দিন (YYYY-MM-DD বা DD-MM-YYYY)।")
        return
    data = await state.get_data()
    cid = data.get("cid")
    page = data.get("page", 0)
    field = data.get("field")
    if field == "start":
        customer = await customer_service.update_dates(cid, start_date=parsed)
    else:
        customer = await customer_service.update_dates(cid, expiry_date=parsed)
    await state.clear()
    if customer is None:
        await message.answer("⚠ গ্রাহক পাওয়া যায়নি।")
        return
    await message.answer("✅ তারিখ আপডেট হয়েছে।")
    await _render_user_menu(message, cid, page)


@router.callback_query(F.data.startswith("um:dadd:"))
async def day_add_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    await state.set_state(ManageUser.days)
    await state.update_data(cid=int(parts[2]), page=int(parts[3]), op="add")
    if callback.message is not None:
        await callback.message.answer("➕ কত দিন যোগ করবেন? সংখ্যা লিখুন:", reply_markup=cancel_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("um:dsub:"))
async def day_sub_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    await state.set_state(ManageUser.days)
    await state.update_data(cid=int(parts[2]), page=int(parts[3]), op="sub")
    if callback.message is not None:
        await callback.message.answer("➖ কত দিন বিয়োগ করবেন? সংখ্যা লিখুন:", reply_markup=cancel_kb())
    await callback.answer()


@router.message(ManageUser.days)
async def day_value(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল হয়েছে।")
        return
    try:
        days = validators.validate_duration(raw)
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    data = await state.get_data()
    cid = data.get("cid")
    page = data.get("page", 0)
    op = data.get("op", "add")
    customer = await customer_service.get(cid)
    if customer is None or customer.expiry_date is None:
        await state.clear()
        await message.answer("⚠ গ্রাহক বা তারিখ পাওয়া যায়নি।")
        return
    delta = timedelta(days=days if op == "add" else -days)
    new_expiry = customer.expiry_date + delta
    await customer_service.update_dates(cid, expiry_date=new_expiry)
    await state.clear()
    await message.answer("✅ মেয়াদ আপডেট হয়েছে।")
    await _render_user_menu(message, cid, page)


# ----- ফিল্ড এডিট -----
_EDIT_LABELS = {
    "name": "নাম",
    "phone": "ফোন",
    "mac_address": "MAC এড্রেস",
    "notes": "নোট",
}


@router.callback_query(F.data.startswith("um:edit:"))
async def field_edit_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    customer_id = int(parts[2])
    field = parts[3]
    page = int(parts[4])
    await state.set_state(ManageUser.field_value)
    await state.update_data(cid=customer_id, page=page, field=field)
    if callback.message is not None:
        await callback.message.answer(f"✏️ নতুন {_EDIT_LABELS.get(field, field)} লিখুন:", reply_markup=cancel_kb())
    await callback.answer()


@router.message(ManageUser.field_value)
async def field_value_set(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল হয়েছে।")
        return
    data = await state.get_data()
    cid = data.get("cid")
    page = data.get("page", 0)
    field = data.get("field")
    try:
        if field == "name":
            value: object = validators.validate_name(raw)
        elif field == "phone":
            value = validators.validate_phone(raw)
        elif field == "mac_address":
            value = validators.validate_mac(raw)
        elif field == "notes":
            value = raw or None
        else:
            value = raw
            if not value:
                raise validators.ValidationError("খালি রাখা যাবে না।")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    customer = await customer_service.update_fields(cid, **{field: value})
    await state.clear()
    if customer is None:
        await message.answer("⚠ গ্রাহক পাওয়া যায়নি।")
        return
    await message.answer("✅ তথ্য আপডেট হয়েছে।")
    await _render_user_menu(message, cid, page)


# ----- Telegram ID সেট -----
@router.callback_query(F.data.startswith("um:tgid:"))
async def tgid_set_cb(callback: CallbackQuery, state: FSMContext) -> None:
    parts = (callback.data or "").split(":")
    await state.set_state(ManageUser.tgid_value)
    await state.update_data(cid=int(parts[2]), page=int(parts[3]))
    if callback.message is not None:
        await callback.message.answer(
            "📲 নতুন Telegram ID লিখুন (শুধু সংখ্যা)।" + NL + NL
            + "<i>গ্রাহক বটে /start দিলে যে সংখ্যা-আইডি পাওয়া যায় সেটিই বসবে। বাতিল করতে 'বাতিল' লিখুন।</i>",
            reply_markup=cancel_kb(),
        )
    await callback.answer()


@router.message(ManageUser.tgid_value)
async def tgid_value_set(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল হয়েছে।")
        return
    try:
        tg_id = validators.validate_telegram_id(raw)
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    if tg_id is None:
        await message.answer("⚠ সঠিক Telegram ID (সংখ্যা) দিন।")
        return
    data = await state.get_data()
    cid = data.get("cid")
    page = data.get("page", 0)
    existing = await customer_service.get_by_telegram_id(tg_id)
    if existing is not None and existing.id != cid:
        await state.set_state(ManageUser.tgid_conflict)
        await state.update_data(tg_id=tg_id, conflict_id=existing.id)
        await message.answer(
            "⚠ <b>এই Telegram ID দিয়ে আগেই একজন গ্রাহক আছে:</b>" + NL + NL
            + customer_profile(existing)
            + NL + NL + "<i>এই অ্যাকাউন্টটি ডিলিট করে আইডিটি নতুন গ্রাহকে বসাবেন, নাকি বাতিল করবেন?</i>",
            reply_markup=um_tgid_conflict_kb(),
        )
        return
    customer = await customer_service.update_fields(cid, telegram_id=tg_id)
    await state.clear()
    if customer is None:
        await message.answer("⚠ গ্রাহক পাওয়া যায়নি।")
        return
    await message.answer(f"✅ Telegram ID সেট হয়েছে: <b>{to_bn_digits(tg_id)}</b>")
    await _render_user_menu(message, cid, page)


@router.callback_query(F.data == "um:tgcancel")
async def tgid_conflict_cancel_cb(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    cid = data.get("cid")
    page = data.get("page", 0)
    await state.clear()
    await callback.answer("বাতিল হয়েছে।")
    if callback.message is not None and cid is not None:
        await _render_user_menu(callback.message, cid, page)


@router.callback_query(F.data == "um:tgdel")
async def tgid_conflict_delete_cb(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    cid = data.get("cid")
    page = data.get("page", 0)
    tg_id = data.get("tg_id")
    conflict_id = data.get("conflict_id")
    await state.clear()
    if cid is None or tg_id is None or conflict_id is None:
        await callback.answer("তথ্য পাওয়া যায়নি।", show_alert=True)
        return
    await customer_service.delete(conflict_id)
    customer = await customer_service.update_fields(cid, telegram_id=tg_id)
    if callback.message is not None:
        if customer is None:
            await callback.message.answer("⚠ গ্রাহক পাওয়া যায়নি।")
        else:
            await callback.message.answer(
                f"🗑 পুরনো অ্যাকাউন্ট ডিলিট হয়েছে; Telegram ID <b>{to_bn_digits(tg_id)}</b> নতুন গ্রাহকে বসেছে।"
            )
            await _render_user_menu(callback.message, cid, page)
    await callback.answer()
