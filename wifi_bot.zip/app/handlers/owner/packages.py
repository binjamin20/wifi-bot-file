"""প্যাকেজ ব্যবস্থাপনা হ্যান্ডলার (Owner)।

এডমিন প্যাকেজ তালিকা দেখতে, নতুন প্যাকেজ যোগ করতে, মেয়াদ/দাম
এডিট করতে, চালু/বন্ধ ও মুছতে পারে।
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.keyboards.owner_kb import (
    cancel_kb,
    owner_main_menu,
    package_detail_kb,
    packages_admin_kb,
)
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.package_service import package_service
from app.states.states import PackageAdmin, PackageEditValue
from app.utils import validators
from app.utils.formatters import package_detail
from app.utils.logger import get_logger

log = get_logger(__name__)

router = Router(name="owner-packages")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())

_CANCEL_WORDS = {"cancel", "/cancel", "\u09ac\u09be\u09a4\u09bf\u09b2"}


def _is_cancel(message: Message) -> bool:
    return (message.text or "").strip().lower() in _CANCEL_WORDS


async def _show_list(target: Message) -> None:
    packages = await package_service.list_all()
    if not packages:
        await target.answer(
            "\U0001f4e6 \u098f\u0996\u09a8\u09cb \u0995\u09cb\u09a8\u09cb \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09a8\u09c7\u0987\u0964 \u09a8\u09bf\u099a\u09c7\u09b0 \u09ac\u09be\u099f\u09a8 \u09a6\u09bf\u09af\u09bc\u09c7 \u09a8\u09a4\u09c1\u09a8 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09af\u09cb\u0997 \u0995\u09b0\u09c1\u09a8\u0964",
            reply_markup=packages_admin_kb([]),
        )
        return
    await target.answer(
        "\U0001f4e6 <b>\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09a4\u09be\u09b2\u09bf\u0995\u09be</b>\n\n"
        "\u09ac\u09bf\u09b8\u09cd\u09a4\u09be\u09b0\u09bf\u09a4 \u09a6\u09c7\u0996\u09a4\u09c7 / \u098f\u09a1\u09bf\u099f \u0995\u09b0\u09a4\u09c7 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c\u09c7 \u0995\u09cd\u09b2\u09bf\u0995 \u0995\u09b0\u09c1\u09a8\u0983",
        reply_markup=packages_admin_kb(packages),
    )


@router.message(Command("packages"))
@router.message(F.text == "\U0001f4e6 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c")
async def packages_menu(message: Message, state: FSMContext) -> None:
    await state.clear()
    await _show_list(message)


@router.callback_query(F.data == "pkglist")
async def pkg_list(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await _show_list(callback.message)
    await callback.answer()


@router.callback_query(F.data.startswith("pkgview:"))
async def pkg_view(callback: CallbackQuery) -> None:
    package_id = int(callback.data.split(":")[1])
    package = await package_service.get(package_id)
    if package is None:
        await callback.answer("\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09aa\u09be\u0993\u09af\u09bc\u09be \u09af\u09be\u09af\u09bc\u09a8\u09bf\u0964", show_alert=True)
        return
    await callback.message.answer(
        package_detail(package), reply_markup=package_detail_kb(package)
    )
    await callback.answer()


# ---- নতুন প্যাকেজ ----
@router.callback_query(F.data == "pkgadd")
async def pkg_add(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(PackageAdmin.waiting_name)
    await callback.message.answer(
        "\U0001f4e6 \u09a8\u09a4\u09c1\u09a8 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c\u09c7\u09b0 \u09a8\u09be\u09ae \u09b2\u09bf\u0996\u09c1\u09a8 (\u09af\u09c7\u09ae\u09a8: \u09ed \u09a6\u09bf\u09a8\u09c7\u09b0 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c):",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


@router.message(PackageAdmin.waiting_name)
async def pkg_add_name(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("\u09ac\u09be\u09a4\u09bf\u09b2\u0964", reply_markup=owner_main_menu())
        return
    name = (message.text or "").strip()
    if len(name) < 2:
        await message.answer("\u26a0 \u09a8\u09be\u09ae \u0995\u09ae\u09aa\u0995\u09cd\u09b7\u09c7 \u09e8 \u0985\u0995\u09cd\u09b7\u09b0 \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964")
        return
    await state.update_data(name=name)
    await state.set_state(PackageAdmin.waiting_duration)
    await message.answer("\U0001f4c5 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c\u099f\u09bf \u0995\u09a4 \u09a6\u09bf\u09a8\u09c7\u09b0? \u09a6\u09bf\u09a8 \u09b8\u0982\u0996\u09cd\u09af\u09be\u09af\u09bc \u09b2\u09bf\u0996\u09c1\u09a8 (\u09af\u09c7\u09ae\u09a8: 30):")


@router.message(PackageAdmin.waiting_duration)
async def pkg_add_duration(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("\u09ac\u09be\u09a4\u09bf\u09b2\u0964", reply_markup=owner_main_menu())
        return
    try:
        duration = validators.validate_duration(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"\u26a0 {exc}")
        return
    await state.update_data(duration=duration)
    await state.set_state(PackageAdmin.waiting_price)
    await message.answer("\U0001f4b5 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c\u09c7\u09b0 \u09a6\u09be\u09ae \u09b2\u09bf\u0996\u09c1\u09a8 (\u09af\u09c7\u09ae\u09a8: 500):")


@router.message(PackageAdmin.waiting_price)
async def pkg_add_price(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("\u09ac\u09be\u09a4\u09bf\u09b2\u0964", reply_markup=owner_main_menu())
        return
    try:
        price = validators.validate_price(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"\u26a0 {exc}")
        return
    data = await state.get_data()
    await state.clear()
    package = await package_service.create(
        name=data["name"], duration_days=data["duration"], price=price
    )
    await message.answer("\u2705 \u09a8\u09a4\u09c1\u09a8 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09af\u09cb\u0997 \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964", reply_markup=owner_main_menu())
    await message.answer(package_detail(package), reply_markup=package_detail_kb(package))


# ---- এডিট ----
@router.callback_query(F.data.startswith("pkgedit:"))
async def pkg_edit_start(callback: CallbackQuery, state: FSMContext) -> None:
    parts = callback.data.split(":")
    pkg_id, field = int(parts[1]), parts[2]
    package = await package_service.get(pkg_id)
    if package is None:
        await callback.answer("\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09aa\u09be\u0993\u09af\u09bc\u09be \u09af\u09be\u09af\u09bc\u09a8\u09bf\u0964", show_alert=True)
        return
    await state.set_state(PackageEditValue.waiting_value)
    await state.update_data(package_id=pkg_id, field=field)
    prompts = {
        "name": "\u09a8\u09a4\u09c1\u09a8 \u09a8\u09be\u09ae \u09b2\u09bf\u0996\u09c1\u09a8:",
        "duration": "\u09a8\u09a4\u09c1\u09a8 \u09ae\u09c7\u09af\u09bc\u09be\u09a6 (\u09a6\u09bf\u09a8) \u09b2\u09bf\u0996\u09c1\u09a8:",
        "price": "\u09a8\u09a4\u09c1\u09a8 \u09a6\u09be\u09ae \u09b2\u09bf\u0996\u09c1\u09a8:",
    }
    await callback.message.answer("\u270f " + prompts.get(field, "\u09a8\u09a4\u09c1\u09a8 \u09ae\u09be\u09a8 \u09b2\u09bf\u0996\u09c1\u09a8:"))
    await callback.answer()


@router.message(PackageEditValue.waiting_value)
async def pkg_edit_value(message: Message, state: FSMContext) -> None:
    if _is_cancel(message):
        await state.clear()
        await message.answer("\u09ac\u09be\u09a4\u09bf\u09b2\u0964", reply_markup=owner_main_menu())
        return
    data = await state.get_data()
    field = data.get("field")
    pkg_id = int(data.get("package_id"))
    raw = (message.text or "").strip()
    try:
        if field == "name":
            if len(raw) < 2:
                raise validators.ValidationError("\u09a8\u09be\u09ae \u0995\u09ae\u09aa\u0995\u09cd\u09b7\u09c7 \u09e8 \u0985\u0995\u09cd\u09b7\u09b0 \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964")
            package = await package_service.update_fields(pkg_id, name=raw)
        elif field == "duration":
            duration = validators.validate_duration(raw)
            package = await package_service.update_fields(pkg_id, duration_days=duration)
        elif field == "price":
            price = validators.validate_price(raw)
            package = await package_service.update_fields(pkg_id, price=price)
        else:
            await state.clear()
            await message.answer("\u0985\u099c\u09be\u09a8\u09be \u09ab\u09bf\u09b2\u09cd\u09a1\u0964", reply_markup=owner_main_menu())
            return
    except validators.ValidationError as exc:
        await message.answer(f"\u26a0 {exc}")
        return
    await state.clear()
    if package is None:
        await message.answer("\u26a0 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09aa\u09be\u0993\u09af\u09bc\u09be \u09af\u09be\u09af\u09bc\u09a8\u09bf\u0964", reply_markup=owner_main_menu())
        return
    await message.answer("\u2705 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u0986\u09aa\u09a1\u09c7\u099f \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964")
    await message.answer(package_detail(package), reply_markup=package_detail_kb(package))


# ---- টগল ----
@router.callback_query(F.data.startswith("pkgtoggle:"))
async def pkg_toggle(callback: CallbackQuery) -> None:
    pkg_id = int(callback.data.split(":")[1])
    package = await package_service.toggle_active(pkg_id)
    if package is None:
        await callback.answer("\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09aa\u09be\u0993\u09af\u09bc\u09be \u09af\u09be\u09af\u09bc\u09a8\u09bf\u0964", show_alert=True)
        return
    state_txt = "\u099a\u09be\u09b2\u09c1" if package.is_active else "\u09ac\u09a8\u09cd\u09a7"
    await callback.answer(f"\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u098f\u0996\u09a8 {state_txt}\u0964")
    await callback.message.answer(
        package_detail(package), reply_markup=package_detail_kb(package)
    )


# ---- মুছে ফেলা ----
@router.callback_query(F.data.startswith("pkgdel:"))
async def pkg_delete(callback: CallbackQuery) -> None:
    pkg_id = int(callback.data.split(":")[1])
    ok = await package_service.delete(pkg_id)
    if not ok:
        await callback.answer("\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09aa\u09be\u0993\u09af\u09bc\u09be \u09af\u09be\u09af\u09bc\u09a8\u09bf\u0964", show_alert=True)
        return
    await callback.answer("\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09ae\u09c1\u099b\u09c7 \u09ab\u09c7\u09b2\u09be \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964")
    await _show_list(callback.message)
