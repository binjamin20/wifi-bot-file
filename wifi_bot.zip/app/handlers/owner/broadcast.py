"""ব্রডকাস্ট হ্যান্ডলার — /broadcast (সব গ্রাহককে মেসেজ)।"""

from __future__ import annotations

import asyncio

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.database.base import db
from app.keyboards.owner_kb import cancel_kb, confirm_kb, owner_main_menu
from app.middlewares.auth import OwnerOnlyMiddleware
from app.repositories.customer_repo import CustomerRepository
from app.states.states import Broadcast, DirectMessage
from app.utils.date_utils import to_bn_digits
from app.utils.logger import get_logger

log = get_logger(__name__)

router = Router(name="owner-broadcast")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())


@router.message(Command("broadcast"))
@router.message(F.text == "\U0001f4e2 \u09ac\u09cd\u09b0\u09a1\u0995\u09be\u09b8\u09cd\u099f")
async def broadcast_start(message: Message, state: FSMContext) -> None:
    await state.set_state(Broadcast.waiting_message)
    await message.answer(
        "\U0001f4e2 \u09b8\u09ac \u0997\u09cd\u09b0\u09be\u09b9\u0995\u0995\u09c7 \u09af\u09c7 \u09ae\u09c7\u09b8\u09c7\u099c \u09aa\u09be\u09a0\u09be\u09a4\u09c7 \u099a\u09be\u09a8 \u09b2\u09bf\u0996\u09c1\u09a8:",
        reply_markup=cancel_kb(),
    )


@router.message(Broadcast.waiting_message)
async def broadcast_preview(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text.lower() in ("cancel", "\u09ac\u09be\u09a4\u09bf\u09b2"):
        await state.clear()
        await message.answer("\u09ac\u09be\u09a4\u09bf\u09b2\u0964", reply_markup=owner_main_menu())
        return
    if not text:
        await message.answer("\u26a0 \u0996\u09be\u09b2\u09bf \u09ae\u09c7\u09b8\u09c7\u099c \u09aa\u09be\u09a0\u09be\u09a8\u09cb \u09af\u09be\u09ac\u09c7 \u09a8\u09be\u0964")
        return
    await state.update_data(text=text)
    await state.set_state(Broadcast.confirm)
    await message.answer(
        f"\U0001f4e2 <b>\u09aa\u09cd\u09b0\u09bf\u09ad\u09bf\u0989:</b>\n\n{text}\n\n\u09b8\u09ac \u0997\u09cd\u09b0\u09be\u09b9\u0995\u0995\u09c7 \u09aa\u09be\u09a0\u09be\u09ac\u09c7\u09a8?",
        reply_markup=confirm_kb("bcast", 0),
    )


@router.callback_query(Broadcast.confirm, F.data.startswith("bcast:"))
async def broadcast_send(callback: CallbackQuery, state: FSMContext) -> None:
    _, decision, _ = callback.data.split(":")
    if decision == "no":
        await state.clear()
        await callback.message.edit_text("\u09ac\u09be\u09a4\u09bf\u09b2 \u0995\u09b0\u09be \u09b9\u09b2\u09cb\u0964")
        await callback.answer()
        return
    data = await state.get_data()
    await state.clear()
    text = data["text"]
    async with db.session() as session:
        recipients = await CustomerRepository(session).with_telegram()
    await callback.message.edit_text("\U0001f4e4 \u09aa\u09be\u09a0\u09be\u09a8\u09cb \u09b6\u09c1\u09b0\u09c1 \u09b9\u09b2\u09cb...")
    sent, failed = 0, 0
    for customer in recipients:
        try:
            await callback.bot.send_message(customer.telegram_id, f"\U0001f4e2 {text}")
            sent += 1
        except Exception as exc:  # ব্লক/ডিলিটেড ইউজার স্কিপ
            failed += 1
            log.warning("Broadcast failed for %s: %s", customer.telegram_id, exc)
        await asyncio.sleep(0.05)  # flood এড়াতে
    await callback.message.answer(
        f"\u2705 \u09ac\u09cd\u09b0\u09a1\u0995\u09be\u09b8\u09cd\u099f \u09b6\u09c7\u09b7!\n\u09aa\u09be\u09a0\u09be\u09a8\u09cb: {to_bn_digits(sent)} \u00b7 \u09ac\u09cd\u09af\u09b0\u09cd\u09a5: {to_bn_digits(failed)}",
        reply_markup=owner_main_menu(),
    )
    await callback.answer()


# ===================== নির্দিষ্ট ইউজারকে মেসেজ (শুধু বাটন) =====================
@router.message(F.text == "📨 মেসেজ পাঠান")
async def dm_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(DirectMessage.waiting_user)
    await message.answer(
        "📨 <b>নির্দিষ্ট ইউজারকে মেসেজ</b>\n\n"
        "যাকে মেসেজ পাঠাতে চান তার <b>Telegram ID</b> লিখুন:\n"
        "<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )


@router.message(DirectMessage.waiting_user)
async def dm_user(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in ("cancel", "/cancel", "বাতিল"):
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    if not raw.lstrip("-").isdigit():
        await message.answer("⚠ সঠিক সংখ্যাসূচক Telegram ID দিন।")
        return
    await state.update_data(target_id=int(raw))
    await state.set_state(DirectMessage.waiting_text)
    await message.answer(
        f"✍ এবার <code>{raw}</code> কে যে মেসেজটি পাঠাবেন তা লিখুন:\n"
        "<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )


@router.message(DirectMessage.waiting_text)
async def dm_text(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in ("cancel", "/cancel", "বাতিল"):
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    if not raw:
        await message.answer("⚠ খালি মেসেজ পাঠানো যাবে না।")
        return
    data = await state.get_data()
    await state.clear()
    target_id = data.get("target_id")
    try:
        await message.bot.send_message(target_id, f"📢 <b>অ্যাডমিনের বার্তা:</b>\n\n{raw}")
        await message.answer(
            f"✅ <code>{target_id}</code> কে মেসেজ পাঠানো হয়েছে।",
            reply_markup=owner_main_menu(),
        )
    except Exception as exc:
        log.warning("Direct message failed for %s: %s", target_id, exc)
        await message.answer(
            "⚠ মেসেজ পাঠানো যায়নি। ইউজার বটটি চালু করেনি, আইডি ভুল, অথবা ব্লক করেছে।",
            reply_markup=owner_main_menu(),
        )
