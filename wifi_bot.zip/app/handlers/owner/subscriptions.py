"""সাবস্ক্রিপশন হ্যান্ডলার — /renew, /expiring, /expired।"""

from __future__ import annotations

from datetime import timedelta

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.database.base import db
from app.keyboards.owner_kb import cancel_kb, owner_main_menu, renew_durations_kb
from app.middlewares.auth import OwnerOnlyMiddleware
from app.repositories.customer_repo import CustomerRepository
from app.services.customer_service import customer_service
from app.states.states import RenewFlow
from app.utils import date_utils, validators
from app.utils.formatters import customer_profile, customer_row

router = Router(name="owner-subscriptions")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())


# ===================== RENEW =====================
@router.message(Command("renew"))
@router.message(F.text == "\U0001f504 রিনিউ")
async def renew_start(message: Message, state: FSMContext) -> None:
    await state.set_state(RenewFlow.waiting_customer)
    await message.answer(
        "\U0001f504 কোন গ্রাহককে রিনিউ করবেন? Customer ID / Telegram ID / ফোন / নাম লিখুন:",
        reply_markup=cancel_kb(),
    )


@router.message(RenewFlow.waiting_customer)
async def renew_pick(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text.lower() in ("cancel", "বাতিল"):
        await state.clear()
        await message.answer("বাতিল।", reply_markup=owner_main_menu())
        return
    match, matches = await customer_service.resolve_one(text)
    if not matches:
        await message.answer(
            "⚠ এই তথ্য দিয়ে কোনো গ্রাহক পাওয়া যায়নি। আবার চেষ্টা করুন:",
            reply_markup=cancel_kb(),
        )
        return
    if match is None:
        lines = ["একাধিক গ্রাহক মিলেছে — সঠিক Customer ID লিখুন:"]
        for c in matches[:20]:
            lines.append(f"#{c.id} · {c.name} · {c.phone}")
        await message.answer("\n".join(lines))
        return
    customer = match
    await state.clear()
    await message.answer(
        f"\U0001f504 <b>{customer.name}</b> (#{customer.id}) — মেয়াদ কতদিন বাড়াবেন?",
        reply_markup=renew_durations_kb(customer.id),
    )


@router.callback_query(F.data.startswith("renew:"))
async def renew_apply(callback: CallbackQuery, state: FSMContext) -> None:
    _, customer_id, value = callback.data.split(":")
    if value == "custom":
        await state.update_data(customer_id=int(customer_id))
        await state.set_state(RenewFlow.custom_duration)
        await callback.message.answer("✏ কত দিন বাড়াবেন? সংখ্যা লিখুন:")
        await callback.answer()
        return
    customer = await customer_service.renew(int(customer_id), int(value))
    if customer is None:
        await callback.message.edit_text("গ্রাহক পাওয়া যায়নি।")
        await callback.answer()
        return
    await callback.message.edit_text(
        f"✅ <b>রিনিউ সফল!</b> (+{date_utils.to_bn_digits(value)} দিন)\n\n" + customer_profile(customer)
    )
    await callback.answer("রিনিউ হয়েছে!")


@router.message(RenewFlow.custom_duration)
async def renew_custom(message: Message, state: FSMContext) -> None:
    try:
        duration = validators.validate_duration(message.text or "")
    except validators.ValidationError as exc:
        await message.answer(f"⚠ {exc}")
        return
    data = await state.get_data()
    await state.clear()
    customer = await customer_service.renew(data["customer_id"], duration)
    if customer is None:
        await message.answer("গ্রাহক পাওয়া যায়নি।", reply_markup=owner_main_menu())
        return
    await message.answer(
        f"✅ <b>রিনিউ সফল!</b> (+{date_utils.to_bn_digits(duration)} দিন)\n\n" + customer_profile(customer),
        reply_markup=owner_main_menu(),
    )


# ===================== EXPIRING / EXPIRED =====================
@router.message(Command("expiring"))
@router.message(F.text == "⏳ মেয়াদ")
async def expiring_list(message: Message) -> None:
    today = date_utils.today()
    async with db.session() as session:
        repo = CustomerRepository(session)
        today_list = await repo.expiring_between(today, today)
        tomorrow = await repo.expiring_between(today + timedelta(days=1), today + timedelta(days=1))
        within3 = await repo.expiring_between(today, today + timedelta(days=3))
        within7 = await repo.expiring_between(today, today + timedelta(days=7))

    def block(title: str, items) -> str:
        if not items:
            return f"<b>{title}:</b> নেই"
        rows = "\n".join(f"  • {customer_row(c)}" for c in items)
        return f"<b>{title}:</b>\n{rows}"

    text = "⏳ <b>মেয়াদ শেষের তালিকা</b>\n\n" + "\n\n".join([
        block("\U0001f4cd আজই শেষ", today_list),
        block("\U0001f4c5 আগামীকাল", tomorrow),
        block("৩ দিনের মধ্যে", within3),
        block("৭ দিনের মধ্যে", within7),
    ])
    await message.answer(text, reply_markup=owner_main_menu())


@router.message(Command("expired"))
async def expired_list(message: Message) -> None:
    async with db.session() as session:
        items = await CustomerRepository(session).expired(date_utils.today())
    if not items:
        await message.answer("\U0001f389 কোনো মেয়াদোত্তীর্ণ গ্রাহক নেই।", reply_markup=owner_main_menu())
        return
    rows = "\n".join(f"• #{c.id} {customer_row(c)}" for c in items[:50])
    await message.answer(f"\U0001f534 <b>মেয়াদোত্তীর্ণ গ্রাহক ({len(items)}):</b>\n\n{rows}", reply_markup=owner_main_menu())
