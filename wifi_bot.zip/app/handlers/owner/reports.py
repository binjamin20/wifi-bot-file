"""রিপোর্ট হ্যান্ডলার — /dailyreport, /monthlyreport।"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from app.config import settings
from app.keyboards.owner_kb import owner_main_menu, reports_kb
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.report_service import report_service
from app.utils.date_utils import fmt_money, to_bn_digits

router = Router(name="owner-reports")
router.message.filter(F.from_user.id == settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())


async def render_daily_report() -> str:
    d = await report_service.daily_report()
    return (
        "\U0001f4c5 <b>\u09a1\u09c7\u0987\u09b2\u09bf \u09b0\u09bf\u09aa\u09cb\u09b0\u09cd\u099f</b>\n\n"
        f"\U0001f465 \u09ae\u09cb\u099f \u0997\u09cd\u09b0\u09be\u09b9\u0995: {to_bn_digits(d.total)}\n"
        f"\U0001f7e2 \u098f\u0995\u09cd\u099f\u09bf\u09ad: {to_bn_digits(d.active)}\n"
        f"\U0001f534 \u09ae\u09c7\u09af\u09bc\u09be\u09a6\u09cb\u09a4\u09cd\u09a4\u09c0\u09b0\u09cd\u09a3: {to_bn_digits(d.expired)}\n"
        f"\U0001f4cd \u0986\u099c \u09ae\u09c7\u09af\u09bc\u09be\u09a6 \u09b6\u09c7\u09b7: {to_bn_digits(d.expiring_today)}\n"
        f"\u26a0 3\u09a6\u09bf\u09a8\u09c7\u09b0 \u09ae\u09a7\u09cd\u09af\u09c7: {to_bn_digits(d.expiring_3_days)}\n"
        f"\U0001f4b0 \u0986\u099c\u0995\u09c7\u09b0 \u0986\u09a6\u09be\u09af\u09bc: {fmt_money(d.today_collection)}\n"
        f"\U0001f4b0 \u0997\u09a4\u0995\u09be\u09b2\u09c7\u09b0 \u0986\u09a6\u09be\u09af\u09bc: {fmt_money(d.yesterday_collection)}\n"
        f"\U0001f504 \u0986\u099c\u0995\u09c7\u09b0 \u09b0\u09bf\u09a8\u09bf\u0989: {to_bn_digits(d.renewals)}\n"
        f"\U0001f4cb \u09ae\u09cb\u099f \u09ac\u0995\u09c7\u09af\u09bc\u09be: {fmt_money(d.total_due)}"
    )


async def render_monthly_report() -> str:
    d = await report_service.monthly_report()
    return (
        "\U0001f5d3 <b>\u09ae\u09be\u09b8\u09bf\u0995 \u09b0\u09bf\u09aa\u09cb\u09b0\u09cd\u099f</b>\n\n"
        f"\U0001f4b0 \u09ae\u09be\u09b8\u09c7\u09b0 \u0986\u09a6\u09be\u09af\u09bc: {fmt_money(d.month_collection)}\n"
        f"\U0001f504 \u09ae\u09be\u09b8\u09c7\u09b0 \u09b0\u09bf\u09a8\u09bf\u0989: {to_bn_digits(d.month_renewals)}\n"
        f"\U0001f4cb \u09ae\u09cb\u099f \u09ac\u0995\u09c7\u09af\u09bc\u09be: {fmt_money(d.total_due)}\n"
        f"\U0001f465 \u09ae\u09cb\u099f \u0997\u09cd\u09b0\u09be\u09b9\u0995: {to_bn_digits(d.total_customers)}"
    )


@router.message(Command("reports"))
@router.message(F.text == "\U0001f4c8 \u09b0\u09bf\u09aa\u09cb\u09b0\u09cd\u099f")
async def reports_menu(message: Message) -> None:
    await message.answer("\U0001f4c8 \u0995\u09cb\u09a8 \u09b0\u09bf\u09aa\u09cb\u09b0\u09cd\u099f \u09a6\u09c7\u0996\u09a4\u09c7 \u099a\u09be\u09a8?", reply_markup=reports_kb())


@router.message(Command("dailyreport"))
async def daily_cmd(message: Message) -> None:
    await message.answer(await render_daily_report(), reply_markup=owner_main_menu())


@router.message(Command("monthlyreport"))
async def monthly_cmd(message: Message) -> None:
    await message.answer(await render_monthly_report(), reply_markup=owner_main_menu())


@router.callback_query(F.data == "report:daily")
async def daily_cb(callback: CallbackQuery) -> None:
    await callback.message.answer(await render_daily_report())
    await callback.answer()


@router.callback_query(F.data == "report:monthly")
async def monthly_cb(callback: CallbackQuery) -> None:
    await callback.message.answer(await render_monthly_report())
    await callback.answer()
