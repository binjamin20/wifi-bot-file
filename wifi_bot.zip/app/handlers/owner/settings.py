"""পেমেন্ট সেটিংস হ্যান্ডলার (owner)।

pায়মেন্ট মাধ্যম যোগ/বাদ/নম্বর এডিট ও সর্বনিম্ন ডিপোজিট সেট করা যায়।
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.config import settings as app_settings
from app.keyboards.owner_kb import cancel_kb, owner_main_menu
from app.middlewares.auth import OwnerOnlyMiddleware
from app.services.settings_service import settings_service
from app.states.states import MacVideoSettings, OwnerSettings
from app.utils.date_utils import fmt_money

router = Router(name="owner-settings")
router.message.filter(F.from_user.id == app_settings.owner_id)
router.message.middleware(OwnerOnlyMiddleware())
router.callback_query.middleware(OwnerOnlyMiddleware())

_CANCEL_WORDS = {"cancel", "/cancel", "বাতিল"}


def _settings_kb(methods: list[dict], cash_enabled: bool = True) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for m in methods:
        name = m["name"]
        builder.button(text=f"✏ {name}", callback_data=f"setnum:{name}")
        builder.button(text=f"🗑 {name}", callback_data=f"delmethod:{name}")
    if cash_enabled:
        builder.button(text="🤝 ক্যাশ: 🟢 চালু (বন্ধ করতে চাপুন)", callback_data="togglecash")
    else:
        builder.button(text="🤝 ক্যাশ: 🔴 বন্ধ (চালু করতে চাপুন)", callback_data="togglecash")
    builder.button(text="➕ নতুন মাধ্যম", callback_data="addmethod")
    builder.button(text="💵 সর্বনিম্ন ডিপোজিট", callback_data="setmindep")
    builder.button(text="📹 MAC ভিডিও সেটিং", callback_data="macvid:open")
    builder.adjust(*([2] * len(methods)), 1, 1, 1, 1)
    return builder.as_markup()


async def _show_settings(message: Message) -> None:
    methods = await settings_service.list_payment_methods()
    min_dep = await settings_service.get_min_deposit()
    cash_enabled = await settings_service.is_cash_enabled()
    lines = ["⚙ <b>পেমেন্ট সেটিংস</b>\n"]
    if methods:
        for m in methods:
            number = m["number"] or "— সেট করা নেই —"
            lines.append(f"• {m['name']}: <code>{number}</code>")
    else:
        lines.append("<i>কোনো পেমেন্ট মাধ্যম নেই। নিচে থেকে যোগ করুন।</i>")
    lines.append(f"\n🤝 ক্যাশ পেমেন্ট: {'🟢 চালু' if cash_enabled else '🔴 বন্ধ'}")
    lines.append(f"💵 সর্বনিম্ন ডিপোজিট: {fmt_money(min_dep)}")
    lines.append("\n<i>✏ = নম্বর এডিট · 🗑 = মাধ্যম বাদ</i>")
    await message.answer("\n".join(lines), reply_markup=_settings_kb(methods, cash_enabled))


@router.message(Command("settings"))
@router.message(F.text == "⚙ পেমেন্ট সেটিংস")
async def settings_menu(message: Message, state: FSMContext) -> None:
    await state.clear()
    await _show_settings(message)


@router.callback_query(F.data == "togglecash")
async def toggle_cash(callback: CallbackQuery) -> None:
    enabled = await settings_service.is_cash_enabled()
    await settings_service.set_cash_enabled(not enabled)
    await callback.answer(
        "🤝 ক্যাশ পেমেন্ট " + ("বন্ধ করা হয়েছে।" if enabled else "চালু করা হয়েছে।"),
        show_alert=True,
    )
    if callback.message is not None:
        await _show_settings(callback.message)


# ---- নম্বর এডিট ----
@router.callback_query(F.data.startswith("setnum:"))
async def setnum_chosen(callback: CallbackQuery, state: FSMContext) -> None:
    name = callback.data.split(":", 1)[1]
    await state.update_data(method_name=name)
    await state.set_state(OwnerSettings.waiting_value)
    await callback.message.answer(
        f"✏ <b>{name}</b> এর নতুন নম্বর লিখুন:\n"
        "<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


@router.message(OwnerSettings.waiting_value)
async def setnum_value(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    data = await state.get_data()
    name = data.get("method_name")
    await state.clear()
    if not name:
        await message.answer("⚠ অজানা মাধ্যম।", reply_markup=owner_main_menu())
        return
    if not raw:
        await message.answer("⚠ নম্বর খালি রাখা যাবে না।", reply_markup=owner_main_menu())
        return
    await settings_service.set_payment_number(name, raw)
    await message.answer(
        f"✅ <b>{name}</b> নম্বর আপডেট হয়েছে: <code>{raw}</code>",
        reply_markup=owner_main_menu(),
    )
    await _show_settings(message)


# ---- মাধ্যম বাদ ----
@router.callback_query(F.data.startswith("delmethod:"))
async def delmethod(callback: CallbackQuery) -> None:
    name = callback.data.split(":", 1)[1]
    removed = await settings_service.remove_payment_method(name)
    if removed:
        await callback.answer(f"🗑 {name} বাদ দেওয়া হয়েছে।", show_alert=True)
    else:
        await callback.answer("⚠ মাধ্যমটি পাওয়া যায়নি।", show_alert=True)
    if callback.message is not None:
        await _show_settings(callback.message)


# ---- নতুন মাধ্যম ----
@router.callback_query(F.data == "addmethod")
async def addmethod_start(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(OwnerSettings.waiting_method_name)
    await callback.message.answer(
        "➕ নতুন পেমেন্ট মাধ্যমের নাম লিখুন (যেমন Upay):\n"
        "<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


@router.message(OwnerSettings.waiting_method_name)
async def addmethod_name(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    if not raw:
        await message.answer("⚠ নাম খালি রাখা যাবে না।")
        return
    await state.update_data(new_method=raw)
    await state.set_state(OwnerSettings.waiting_method_number)
    await message.answer(
        f"📲 <b>{raw}</b> এর নম্বর লিখুন:", reply_markup=cancel_kb()
    )


@router.message(OwnerSettings.waiting_method_number)
async def addmethod_number(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    data = await state.get_data()
    name = data.get("new_method")
    await state.clear()
    if not name:
        await message.answer("⚠ আবার চেষ্টা করুন।", reply_markup=owner_main_menu())
        return
    await settings_service.add_payment_method(name, raw)
    await message.answer(
        f"✅ <b>{name}</b> যোগ হয়েছে: <code>{raw or '—'}</code>",
        reply_markup=owner_main_menu(),
    )
    await _show_settings(message)


# ---- সর্বনিম্ন ডিপোজিট ----
@router.callback_query(F.data == "setmindep")
async def setmindep_start(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(OwnerSettings.waiting_min_deposit)
    await callback.message.answer(
        "💵 নতুন সর্বনিম্ন ডিপোজিট (সংখ্যা) লিখুন:\n"
        "<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


@router.message(OwnerSettings.waiting_min_deposit)
async def setmindep_value(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    try:
        value = float(raw)
    except ValueError:
        await message.answer("⚠ সঠিক সংখ্যা দিন।")
        return
    if value < 0:
        value = 0.0
    await state.clear()
    await settings_service.set_min_deposit(value)
    await message.answer(
        f"✅ সর্বনিম্ন ডিপোজিট সেট হয়েছে: {fmt_money(value)}",
        reply_markup=owner_main_menu(),
    )
    await _show_settings(message)


# ---- MAC ভিডিও সেটিং ----
def _mac_video_kb(has_url: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔗 ভিডিও লিংক", callback_data="macvid:url")
    builder.button(text="🏷 ভিডিও বাটন লেখা", callback_data="macvid:label")
    builder.button(text="⏭ স্কিপ বাটন লেখা", callback_data="macvid:skip")
    builder.button(text="📝 MAC মেসেজ টেক্সট", callback_data="macvid:text")
    if has_url:
        builder.button(text="🗑 ভিডিও লিংক মুছুন", callback_data="macvid:clear")
    builder.button(text="⬅️ পিছনে", callback_data="macvid:back")
    builder.adjust(2, 2, 1, 1)
    return builder.as_markup()


async def _show_mac_video(message: Message) -> None:
    url = await settings_service.get_mac_video_url()
    label = await settings_service.get_mac_video_label()
    skip_label = await settings_service.get_mac_skip_label()
    ask_text = await settings_service.get_mac_ask_text()
    lines = [
        "📹 <b>MAC ভিডিও সেটিং</b>\n",
        f"🔗 ভিডিও লিংক: {url or '— সেট করা নেই (বাটন লুকানো) —'}",
        f"🏷 ভিডিও বাটন লেখা: {label}",
        f"⏭ স্কিপ বাটন লেখা: {skip_label}",
        "📝 MAC মেসেজ টেক্সট:",
        f"<code>{ask_text}</code>",
        "\n<i>ভিডিও লিংক না থাকলে গ্রাহক MAC ধাপে ভিডিও বাটন দেখবে না।</i>",
    ]
    await message.answer("\n".join(lines), reply_markup=_mac_video_kb(bool(url)))


@router.callback_query(F.data == "macvid:open")
async def macvid_open(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await _show_mac_video(callback.message)
    await callback.answer()


@router.callback_query(F.data == "macvid:back")
async def macvid_back(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message is not None:
        await _show_settings(callback.message)
    await callback.answer()


@router.callback_query(F.data == "macvid:clear")
async def macvid_clear(callback: CallbackQuery) -> None:
    await settings_service.set_mac_video_url("")
    await callback.answer("🗑 ভিডিও লিংক মুছে ফেলা হয়েছে।", show_alert=True)
    if callback.message is not None:
        await _show_mac_video(callback.message)


_MAC_FIELD_PROMPTS = {
    "url": "🔗 ভিডিও লিংক (URL) লিখুন (যেমন https://youtu.be/...):",
    "label": "🏷 ভিডিও বাটনে কী লেখা থাকবে লিখুন:",
    "skip": "⏭ স্কিপ বাটনে কী লেখা থাকবে লিখুন:",
    "text": "📝 MAC চাওয়ার মেসেজ টেক্সট লিখুন:",
}


@router.callback_query(F.data.in_({"macvid:url", "macvid:label", "macvid:skip", "macvid:text"}))
async def macvid_edit_start(callback: CallbackQuery, state: FSMContext) -> None:
    field = callback.data.split(":", 1)[1]
    await state.update_data(mac_field=field)
    await state.set_state(MacVideoSettings.waiting_value)
    if callback.message is not None:
        await callback.message.answer(
            _MAC_FIELD_PROMPTS[field] + "\n<i>(বন্ধ করতে নিচের ❌ বাতিল বাটনে চাপুন)</i>",
            reply_markup=cancel_kb(),
        )
    await callback.answer()


@router.message(MacVideoSettings.waiting_value)
async def macvid_value(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.lower() in _CANCEL_WORDS:
        await state.clear()
        await message.answer("❌ বাতিল করা হয়েছে।", reply_markup=owner_main_menu())
        return
    data = await state.get_data()
    field = data.get("mac_field")
    await state.clear()
    if not field:
        await message.answer("⚠ আবার চেষ্টা করুন।", reply_markup=owner_main_menu())
        return
    if not raw:
        await message.answer("⚠ খালি রাখা যাবে না।", reply_markup=owner_main_menu())
        return
    if field == "url":
        if not raw.lower().startswith(("http://", "https://")):
            await message.answer("⚠ সঠিক লিংক দিন (http:// বা https:// দিয়ে শুরু)।", reply_markup=owner_main_menu())
            return
        await settings_service.set_mac_video_url(raw)
    elif field == "label":
        await settings_service.set_mac_video_label(raw)
    elif field == "skip":
        await settings_service.set_mac_skip_label(raw)
    elif field == "text":
        await settings_service.set_mac_ask_text(raw)
    await message.answer("✅ সেভ হয়েছে।")
    await _show_mac_video(message)
