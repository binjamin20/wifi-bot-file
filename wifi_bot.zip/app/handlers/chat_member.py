"""বট কোনো গ্রুপ/চ্যানেলে যুক্ত বা অ্যাডমিন হলে তার chat_id সংরক্ষণ করি।

এতে ফোর্স-জয়েন সিস্টেম প্রাইভেট গ্রুপ/চ্যানেলেও মেম্বারশিপ যাচাই করতে পারে
এবং owner চাইলে chat_id/ইউজারনেম দিয়ে সেটিংসে যোগ করতে পারেন।
"""

from __future__ import annotations

from aiogram import Router
from aiogram.types import ChatMemberUpdated

from app.config import settings
from app.services.settings_service import settings_service
from app.utils.logger import get_logger

router = Router(name="chat-member")
log = get_logger(__name__)

_PRESENT_STATUSES = {"member", "administrator", "creator", "restricted"}


@router.my_chat_member()
async def on_my_chat_member(event: ChatMemberUpdated) -> None:
    """বটের নিজের স্ট্যাটাস পরিবর্তন — গ্রুপ/চ্যানেলে যুক্ত হলে chat_id সংরক্ষণ।"""
    chat = event.chat
    # শুধু গ্রুপ/সুপারগ্রুপ/চ্যানেল — প্রাইভেট ইউজার চ্যাট এড়াই
    if getattr(chat, "type", None) not in ("group", "supergroup", "channel"):
        return
    status = getattr(event.new_chat_member, "status", "")
    status = getattr(status, "value", status)
    if status not in _PRESENT_STATUSES:
        return
    username = getattr(chat, "username", None)
    title = getattr(chat, "title", None)
    try:
        await settings_service.remember_chat(chat.id, username, title)
    except Exception as exc:
        log.warning("remember_chat failed: %s", exc)
    try:
        uname = f"@{username}" if username else "—"
        await event.bot.send_message(
            settings.owner_id,
            "🤝 <b>বট একটি চ্যাটে যুক্ত হয়েছে</b>\n\n"
            f"📛 শিরোনাম: {title or '—'}\n"
            f"🔗 ইউজারনেম: {uname}\n"
            f"🆔 Chat ID: <code>{chat.id}</code>\n\n"
            "ফোর্স-জয়েনে যোগ করতে চাইলে এই ইউজারনেম অথবা Chat ID সেটিংসে দিন।",
        )
    except Exception as exc:
        log.warning("notify owner chat-add failed: %s", exc)
