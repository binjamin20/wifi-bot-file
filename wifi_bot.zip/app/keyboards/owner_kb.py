"""Owner প্যানেলের কীবোর্ড।

বাটনের রঙ app.utils.ui থেকে আসে (Bot API 9.4 — aiogram >= 3.25)।
"""

from __future__ import annotations

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    KeyboardButton,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from app.utils.date_utils import fmt_money, to_bn_digits
from app.utils.ui import primary, success, danger

# রিনিউয়াল কুইক বাটন (দিন)
RENEW_DURATIONS = [7, 15, 30, 60, 90]
# পেমেন্ট মেথড
PAYMENT_METHODS = ["Cash", "Bkash", "Nagad", "Rocket", "Bank"]


def owner_main_menu() -> ReplyKeyboardMarkup:
    """Owner-এর মূল রিপ্লাই মেনু।"""
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="\U0001f4ca ড্যাশবোর্ড", **primary()), KeyboardButton(text="\u2795 নতুন গ্রাহক", **success()))
    builder.row(KeyboardButton(text="👤 গ্রাহক তথ্য", **primary()), KeyboardButton(text="\U0001f504 রিনিউ", **success()))
    builder.row(KeyboardButton(text="\U0001f4b3 পেমেন্ট", **primary()), KeyboardButton(text="\u23f3 মেয়াদ", **primary()))
    builder.row(KeyboardButton(text="\U0001f4cb বকেয়া", **danger()), KeyboardButton(text="\U0001f4c8 রিপোর্ট", **primary()))
    builder.row(KeyboardButton(text="\U0001f4e2 ব্রডকাস্ট", **success()), KeyboardButton(text="\U0001f5c2 এক্সপোর্ট / ব্যাকআপ", **primary()))
    builder.row(KeyboardButton(text="\U0001f4e5 অনুরোধ", **success()), KeyboardButton(text="\U0001f39f রিডিম কোড", **primary()))
    builder.row(KeyboardButton(text="\U0001f6e0 সিস্টেম", **primary()), KeyboardButton(text="📨 মেসেজ পাঠান", **success()))
    return builder.as_markup(resize_keyboard=True)


def customer_profile_kb(customer) -> InlineKeyboardMarkup:
    """গ্রাহক প্রোফাইল কার্ডের অ্যাকশন — ব্যান/আনব্যান টগল।"""
    builder = InlineKeyboardBuilder()
    if getattr(customer, "is_banned", False):
        builder.button(
            text="✅ আনব্যান করুন",
            callback_data=f"custunban:{customer.id}",
            **success(),
        )
    else:
        builder.button(
            text="🚫 ব্যান করুন",
            callback_data=f"custban:{customer.id}",
            **danger(),
        )
    builder.adjust(1)
    return builder.as_markup()


def renew_durations_kb(customer_id: int) -> InlineKeyboardMarkup:
    """রিনিউ কুইক বাটন।"""
    builder = InlineKeyboardBuilder()
    for days in RENEW_DURATIONS:
        builder.button(
            text=f"{to_bn_digits(days)} দিন",
            callback_data=f"renew:{customer_id}:{days}",
            **primary(),
        )
    builder.button(text="\u270f কাস্টম", callback_data=f"renew:{customer_id}:custom", **success())
    builder.adjust(3, 3)
    return builder.as_markup()


def payment_methods_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for method in PAYMENT_METHODS:
        builder.button(text=method, callback_data=f"paymethod:{method}", **primary())
    builder.adjust(3, 2)
    return builder.as_markup()


def initial_payment_kb(price: float) -> InlineKeyboardMarkup:
    """নতুন গ্রাহক যোগের সময় প্রাথমিক পরিশোধ জিজ্ঞাসা।"""
    builder = InlineKeyboardBuilder()
    builder.button(text=f"\u2705 পুরো ({fmt_money(price)})", callback_data="addpay:full", **success())
    builder.button(text="\U0001f4b5 আংশিক / কাস্টম", callback_data="addpay:custom", **primary())
    builder.button(text="\u274c বকেয়া (০)", callback_data="addpay:none", **danger())
    builder.adjust(1, 2)
    return builder.as_markup()


def confirm_kb(action: str, target_id: int) -> InlineKeyboardMarkup:
    """কনফার্ম/ক্যানসেল ইনলাইন।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="\u2705 হ্যাঁ", callback_data=f"{action}:yes:{target_id}", **success())
    builder.button(text="\u274c না", callback_data=f"{action}:no:{target_id}", **danger())
    return builder.as_markup()


def edit_fields_kb(customer_id: int, can_set_tgid: bool = False) -> InlineKeyboardMarkup:
    """কোন ফিল্ড এডিট হবে।"""
    fields = [
        ("name", "নাম"),
        ("phone", "ফোন"),
        ("package_name", "প্যাকেজ"),
        ("package_price", "দাম"),
        ("notes", "নোট"),
        ("balance", "\U0001f4b0 ব্যালান্স"),
        ("start_date", "\U0001f4c5 শুরুর তারিখ"),
        ("expiry_date", "\u23f3 মেয়াদ"),
    ]
    builder = InlineKeyboardBuilder()
    for key, label in fields:
        builder.button(text=label, callback_data=f"editfield:{customer_id}:{key}", **primary())
    if can_set_tgid:
        builder.button(
            text="\U0001f4f2 Telegram ID সেট",
            callback_data=f"settgid:start:{customer_id}",
            **success(),
        )
        builder.adjust(3, 3, 2, 1)
    else:
        builder.adjust(3, 3, 3)
    return builder.as_markup()


def add_package_select_kb(packages) -> InlineKeyboardMarkup:
    """নতুন গ্রাহক যোগে সেভ করা প্যাকেজ থেকে সিলেকশন।"""
    builder = InlineKeyboardBuilder()
    for pkg in packages:
        builder.button(
            text=f"{pkg.name} ({to_bn_digits(pkg.duration_days)}দিন · {fmt_money(pkg.price)})",
            callback_data=f"addpkg:{pkg.id}",
            **primary(),
        )
    builder.button(text="✏ কাস্টম প্যাকেজ", callback_data="addpkg:custom", **success())
    builder.adjust(1)
    return builder.as_markup()


def tgid_conflict_kb(target_id: int, tg_id: int) -> InlineKeyboardMarkup:
    """Telegram ID অন্য অ্যাকাউন্টে থাকলে — ডিলিট/ক্যান্সেল।"""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="🗑 ডিলিট করুন",
        callback_data=f"tgidconf:del:{target_id}:{tg_id}",
        **danger(),
    )
    builder.button(text="❌ ক্যান্সেল করুন", callback_data="tgidconf:cancel", **primary())
    builder.adjust(1)
    return builder.as_markup()


def settings_kb() -> InlineKeyboardMarkup:
    """পেমেন্ট সেটিংস এডিট করার বাটন।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="Bkash নম্বর", callback_data="setcfg:bkash", **primary())
    builder.button(text="Nagad নম্বর", callback_data="setcfg:nagad", **primary())
    builder.button(text="Rocket নম্বর", callback_data="setcfg:rocket", **primary())
    builder.button(text="\U0001f4b5 সর্বনিম্ন ডিপোজিট", callback_data="setcfg:mindeposit", **success())
    builder.adjust(3, 1)
    return builder.as_markup()


def redeem_admin_kb(codes: list | None = None) -> InlineKeyboardMarkup:
    """রিডিম কোড ম্যানেজমেন্ট — নতুন কোড + সক্রিয় কোড এক ক্লিকে স্থায়ীভাবে বন্ধ।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ নতুন রিডিম কোড", callback_data="redeem:new", **success())
    for rc in codes or []:
        if not rc.is_active:
            continue
        if rc.used_count >= rc.max_uses:
            continue
        builder.button(
            text=f"⏸ {rc.code} বন্ধ করুন",
            callback_data=f"redeem:off:{rc.id}",
            **danger(),
        )
    builder.adjust(1)
    return builder.as_markup()


def export_backup_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="\U0001f4d7 Excel", callback_data="export:excel", **primary())
    builder.button(text="\U0001f4c4 CSV", callback_data="export:csv", **primary())
    builder.button(text="\U0001f4be ব্যাকআপ নিন", callback_data="backup:run", **success())
    builder.button(text="🗄 পূর্ণ এক্সপোর্ট", callback_data="export:full", **success())
    builder.button(text="📥 ইমপোর্ট (রিস্টোর)", callback_data="import:start", **primary())
    builder.adjust(2, 1, 1, 1)
    return builder.as_markup()


def reports_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="\U0001f4c5 ডেইলি রিপোর্ট", callback_data="report:daily", **primary())
    builder.button(text="\U0001f5d3 মাসিক রিপোর্ট", callback_data="report:monthly", **primary())
    builder.adjust(2)
    return builder.as_markup()


def pagination_kb(prefix: str, page: int, has_next: bool) -> InlineKeyboardMarkup:
    """সাধারণ pagination কন্ট্রোল।"""
    builder = InlineKeyboardBuilder()
    if page > 0:
        builder.button(text="\u2b05 আগে", callback_data=f"{prefix}:page:{page - 1}", **primary())
    if has_next:
        builder.button(text="পরে \u27a1", callback_data=f"{prefix}:page:{page + 1}", **primary())
    return builder.as_markup()


def request_action_kb(request_id: int) -> InlineKeyboardMarkup:
    """অনুরোধ Approve/Reject বাটন।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="\u2705 অনুমোদন", callback_data=f"req:approve:{request_id}", **success())
    builder.button(text="\u274c বাতিল", callback_data=f"req:reject:{request_id}", **danger())
    builder.adjust(2)
    return builder.as_markup()


def packages_admin_kb(packages) -> InlineKeyboardMarkup:
    """প্যাকেজ তালিকা — প্রতিটি ক্লিক করলে বিস্তারিত।"""
    builder = InlineKeyboardBuilder()
    for pkg in packages:
        state = "\U0001f7e2" if pkg.is_active else "\u26aa"
        builder.button(
            text=f"{state} {pkg.name} ({to_bn_digits(pkg.duration_days)}\u09a6\u09bf\u09a8 \u00b7 {fmt_money(pkg.price)})",
            callback_data=f"pkgview:{pkg.id}",
            **primary(),
        )
    builder.button(text="\u2795 নতুন প্যাকেজ", callback_data="pkgadd", **success())
    builder.adjust(1)
    return builder.as_markup()


def package_detail_kb(package) -> InlineKeyboardMarkup:
    """একটি প্যাকেজের এডিট/টগল/মুছে ফেলা বাটন।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="\u270f নাম", callback_data=f"pkgedit:{package.id}:name", **primary())
    builder.button(text="\U0001f4c5 মেয়াদ", callback_data=f"pkgedit:{package.id}:duration", **primary())
    builder.button(text="\U0001f4b5 দাম", callback_data=f"pkgedit:{package.id}:price", **primary())
    if package.is_active:
        builder.button(text="\u26aa বন্ধ করুন", callback_data=f"pkgtoggle:{package.id}", **danger())
    else:
        builder.button(text="\U0001f7e2 চালু করুন", callback_data=f"pkgtoggle:{package.id}", **success())
    builder.button(text="\U0001f5d1 মুছুন", callback_data=f"pkgdel:{package.id}", **danger())
    builder.button(text="\u2b05 তালিকা", callback_data="pkglist", **primary())
    builder.adjust(3, 2, 1)
    return builder.as_markup()


def customers_list_kb(customers) -> InlineKeyboardMarkup:
    """প্রতিটি গ্রাহকের নাম আলাদা বাটন — ক্লিক করলে বিস্তারিত ইনফো।"""
    builder = InlineKeyboardBuilder()
    for c in customers:
        builder.button(text=f"👤 {c.name}", callback_data=f"userinfo:{c.id}", **primary())
    builder.adjust(1)
    return builder.as_markup()


def cancel_kb() -> InlineKeyboardMarkup:
    """❌ বাতিল ইনলাইন বাটন — যেকোনো ধাপ বন্ধ করতে।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ বাতিল", callback_data="owner:cancel", **danger())
    return builder.as_markup()


def owner_skip_kb(skip_data: str) -> InlineKeyboardMarkup:
    """⏭ স্কিপ + ❌ বাতিল ইনলাইন বাটন — owner-এর ঐচ্ছিক ধাপে।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="⏭ স্কিপ", callback_data=skip_data, **primary())
    builder.button(text="❌ বাতিল", callback_data="owner:cancel", **danger())
    builder.adjust(2)
    return builder.as_markup()


# ===================== সিস্টেম / ইউজার ম্যানেজমেন্ট =====================
def system_menu_kb() -> InlineKeyboardMarkup:
    """🛠 সিস্টেম মেনু।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="🔗 ফোর্স জয়েন সিস্টেম", callback_data="sys:fj", **primary())
    builder.button(text="📦 প্যাকেজ", callback_data="sys:pkg", **primary())
    builder.button(text="⚙ পেমেন্ট সেটিংস", callback_data="sys:pay", **primary())
    builder.button(text="👤 ইউজার ম্যানেজমেন্ট", callback_data="sys:um", **success())
    builder.button(text="📝 ইউজার প্যানেল টেক্সট এডিট", callback_data="sys:txt", **primary())
    builder.button(text="⬅️ মূল মেনু", callback_data="sys:close", **danger())
    builder.adjust(1, 2, 1, 1, 1)
    return builder.as_markup()


def force_join_menu_kb(enabled: bool, channels: list[str]) -> InlineKeyboardMarkup:
    """🔗 ফোর্স জয়েন মেনু — টগল + চ্যানেল তালিকা।"""
    builder = InlineKeyboardBuilder()
    if enabled:
        builder.button(text="🟢 স্ট্যাটাস: চালু — বন্ধ করতে চাপুন", callback_data="fja:toggle", **success())
    else:
        builder.button(text="🔴 স্ট্যাটাস: বন্ধ — চালু করতে চাপুন", callback_data="fja:toggle", **danger())
    for ch in channels:
        builder.button(text=f"❌ Delete: {ch}", callback_data=f"fja:del:{ch}", **danger())
    builder.button(text="➕ চ্যানেল যোগ", callback_data="fja:add", **primary())
    builder.button(text="⬅️ পিছনে", callback_data="sys:open", **primary())
    builder.adjust(1)
    return builder.as_markup()


def user_mgmt_list_kb(customers, page: int, has_prev: bool, has_next: bool, today) -> InlineKeyboardMarkup:
    """ইউজার তালিকা (পেজিনেটেড) — এক্টিভ সবুজ, মেয়াদোত্তীর্ণ লাল।"""
    builder = InlineKeyboardBuilder()
    for c in customers:
        active = c.expiry_date is not None and c.expiry_date >= today
        dot = "🟢" if active else "🔴"
        style = success() if active else danger()
        builder.button(text=f"{dot} {c.name}", callback_data=f"um:user:{c.id}:{page}", **style)
    nav = 0
    if has_prev:
        builder.button(text="⬅️ আগে", callback_data=f"um:page:{page - 1}", **primary())
        nav += 1
    if has_next:
        builder.button(text="পরে ➡️", callback_data=f"um:page:{page + 1}", **primary())
        nav += 1
    builder.button(text="🚫 ব্যান্ড ইউজার", callback_data="um:banned:0", **danger())
    builder.button(text="⬅️ সিস্টেম মেনু", callback_data="sys:open", **danger())
    sizes = [1] * len(customers)
    if nav:
        sizes.append(nav)
    sizes.append(1)
    sizes.append(1)
    builder.adjust(*sizes)
    return builder.as_markup()


def banned_users_list_kb(customers, page: int, has_prev: bool, has_next: bool) -> InlineKeyboardMarkup:
    """ব্যান করা ইউজারদের তালিকা (পেজিনেটেড)।"""
    builder = InlineKeyboardBuilder()
    for c in customers:
        builder.button(text=f"🚫 {c.name}", callback_data=f"um:bshow:{c.id}:{page}", **danger())
    nav = 0
    if has_prev:
        builder.button(text="⬅️ আগে", callback_data=f"um:banned:{page - 1}", **primary())
        nav += 1
    if has_next:
        builder.button(text="পরে ➡️", callback_data=f"um:banned:{page + 1}", **primary())
        nav += 1
    builder.button(text="⬅️ ইউজার তালিকা", callback_data="um:page:0", **primary())
    sizes = [1] * len(customers)
    if nav:
        sizes.append(nav)
    sizes.append(1)
    builder.adjust(*sizes)
    return builder.as_markup()


def banned_user_kb(customer_id: int, page: int) -> InlineKeyboardMarkup:
    """একটি ব্যান করা ইউজার — আনব্যান + ফিরে যাওয়া।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ আনব্যান করুন", callback_data=f"um:unban:{customer_id}:{page}", **success())
    builder.button(text="⬅️ ব্যান্ড তালিকা", callback_data=f"um:banned:{page}", **primary())
    builder.adjust(1)
    return builder.as_markup()


def user_manage_kb(customer_id: int, page: int) -> InlineKeyboardMarkup:
    """একটি ইউজারের ম্যানেজ মেনু।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="💰 ম্যানেজ ব্যালেন্স", callback_data=f"um:bal:{customer_id}:{page}", **success())
    builder.button(text="📅 ম্যানেজ ডেট", callback_data=f"um:date:{customer_id}:{page}", **primary())
    builder.button(text="👤 ইউজার প্রোফাইল", callback_data=f"um:profile:{customer_id}:{page}", **primary())
    builder.button(text="🧾 সব তথ্য ম্যানেজ", callback_data=f"um:details:{customer_id}:{page}", **primary())
    builder.button(text="📲 Telegram ID সেট", callback_data=f"um:tgid:{customer_id}:{page}", **success())
    builder.button(text="⬅️ তালিকায় ফিরুন", callback_data=f"um:page:{page}", **danger())
    builder.adjust(2, 2, 1, 1)
    return builder.as_markup()


def manage_balance_kb(customer_id: int, page: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ যোগ করুন", callback_data=f"um:baladd:{customer_id}:{page}", **success())
    builder.button(text="➖ বিয়োগ করুন", callback_data=f"um:balsub:{customer_id}:{page}", **danger())
    builder.button(text="⬅️ পিছনে", callback_data=f"um:user:{customer_id}:{page}", **primary())
    builder.adjust(2, 1)
    return builder.as_markup()


def manage_date_kb(customer_id: int, page: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📅 শুরুর তারিখ সেট", callback_data=f"um:dstart:{customer_id}:{page}", **primary())
    builder.button(text="⏳ মেয়াদ তারিখ সেট", callback_data=f"um:dend:{customer_id}:{page}", **primary())
    builder.button(text="➕ দিন যোগ", callback_data=f"um:dadd:{customer_id}:{page}", **success())
    builder.button(text="➖ দিন বিয়োগ", callback_data=f"um:dsub:{customer_id}:{page}", **danger())
    builder.button(text="⬅️ পিছনে", callback_data=f"um:user:{customer_id}:{page}", **primary())
    builder.adjust(2, 2, 1)
    return builder.as_markup()


def manage_details_kb(customer_id: int, page: int) -> InlineKeyboardMarkup:
    """সব তথ্য এডিট (টাকা ও তারিখ বাদে)।"""
    builder = InlineKeyboardBuilder()
    fields = [
        ("name", "নাম"),
        ("phone", "ফোন"),
        ("mac_address", "MAC এড্রেস"),
        ("notes", "নোট"),
    ]
    for key, label in fields:
        builder.button(text=f"✏️ {label}", callback_data=f"um:edit:{customer_id}:{key}:{page}", **primary())
    builder.button(text="⬅️ পিছনে", callback_data=f"um:user:{customer_id}:{page}", **danger())
    builder.adjust(2, 2, 1)
    return builder.as_markup()


def back_user_kb(customer_id: int, page: int) -> InlineKeyboardMarkup:
    """⬅️ ইউজার মেনুতে ফিরুন।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="⬅️ পিছনে", callback_data=f"um:user:{customer_id}:{page}", **primary())
    return builder.as_markup()



def um_tgid_conflict_kb() -> InlineKeyboardMarkup:
    """Telegram ID কনফ্লিক্ট — পুরনো অ্যাকাউন্ট ডিলিট অথবা বাতিল।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="🗑 ডিলিট করুন", callback_data="um:tgdel", **danger())
    builder.button(text="❌ ক্যান্সেল করুন", callback_data="um:tgcancel", **primary())
    builder.adjust(1)
    return builder.as_markup()



def import_confirm_kb() -> InlineKeyboardMarkup:
    """ইমপোর্ট — সব মুছে রিপ্লেস কনফার্ম।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ নিশ্চিত করুন", callback_data="import:confirm", **danger())
    builder.button(text="❌ বাতিল", callback_data="import:cancel", **primary())
    builder.adjust(1)
    return builder.as_markup()
