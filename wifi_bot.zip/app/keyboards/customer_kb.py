"""Customer প্যানেলের কীবোর্ড।

মূল মেনুটি owner-এর মতো স্ক্রিনের নিচে স্থায়ী Reply Keyboard।
সাব-ফ্লো (মাধ্যম বাছাই, প্যাকেজ তালিকা) ইনলাইন বাটনই থাকে।
বাটনের রঙ app.utils.ui থেকে আসে (Bot API 9.4)।
"""

from __future__ import annotations

from aiogram.types import InlineKeyboardMarkup, ReplyKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from app.utils.date_utils import fmt_money, to_bn_digits
from app.utils.ui import primary, success, danger

# ---- মূল মেনুর বাটন টেক্সট (Reply Keyboard) ----
# এই ধ্রুবকগুলো panel.py-তে টেক্সট হ্যান্ডলারে ব্যবহার হয়, তাই হুবহু মিলতে হবে।
CM_BALANCE = "💰 আমার ব্যালান্স"
CM_DEPOSIT = "➕ টাকা জমা"
CM_BUY = "📦 প্যাকেজ কিনুন"
CM_MYID = "🆔 আমার আইডি"
CM_REDEEM = "🎟 রিডিম কোড"
CM_PACKAGE = "📶 আমার WiFi"
CM_HISTORY = "💳 পেমেন্ট ইতিহাস"
CM_CONTACT = "🎧 সাপোর্ট সেন্টার"


def skip_kb(data: str = "skip") -> InlineKeyboardMarkup:
    """একটি ‘স্কিপ’ ইনলাইন বাটন — টাইপ করার বদলে ক্লিক করা যায়।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="⏭ স্কিপ", callback_data=data, **primary())
    return builder.as_markup()


def deposit_proof_kb(
    skip_data: str = "deposit:skipproof",
    cant_data: str = "deposit:cantpay",
    back_data: str = "dep:back:amount",
) -> InlineKeyboardMarkup:
    """ডিপোজিট প্রমাণ ধাপ — স্কিপ + 'টাকা পাঠাতে পারি নি' + পিছনে।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="⏭ স্কিপ", callback_data=skip_data, **primary())
    builder.button(text="❌ টাকা পাঠাতে পারি নি", callback_data=cant_data, **danger())
    builder.button(text="🔙 পিছনে", callback_data=back_data, **primary())
    builder.adjust(1)
    return builder.as_markup()


def buy_mac_kb(
    video_url: str | None = None,
    video_label: str = "📹 ভিডিও দেখুন",
    skip_label: str = "⏭ স্কিপ",
    skip_data: str = "buymac:skip",
    back_data: str | None = None,
) -> InlineKeyboardMarkup:
    """MAC অ্যাড্রেস ধাপের কীবোর্ড — ভিডিও লিংক থাকলে স্কিপের উপরে সবুজ ভিডিও বাটন।"""
    builder = InlineKeyboardBuilder()
    if video_url:
        builder.button(text=video_label, url=video_url, **success())
    builder.button(text=skip_label, callback_data=skip_data, **primary())
    if back_data:
        builder.button(text="🔙 পিছনে", callback_data=back_data, **primary())
    builder.adjust(1)
    return builder.as_markup()


def customer_menu(registered: bool = False) -> ReplyKeyboardMarkup:
    """গ্রাহকের মূল মেনু — স্ক্রিনের নিচে স্থায়ী বাটন (Reply Keyboard)।"""
    builder = ReplyKeyboardBuilder()
    builder.button(text=CM_BALANCE, **primary())
    builder.button(text=CM_DEPOSIT, **success())
    builder.button(text=CM_BUY, **primary())
    builder.button(text=CM_REDEEM, **success())
    builder.button(text=CM_MYID, **primary())
    if registered:
        builder.button(text=CM_PACKAGE, **primary())
        builder.button(text=CM_HISTORY, **primary())
    builder.button(text=CM_CONTACT, **success())
    builder.adjust(2)
    return builder.as_markup(resize_keyboard=True, is_persistent=True)


def my_id_kb(phone_set: bool = False) -> InlineKeyboardMarkup | None:
    """‘আমার আইডি’ স্ক্রিনের বাটন।

    নম্বর একবার সেট হলে আর সেট করা যাবে না — তখন কোনো বাটন দেখাবে না।"""
    if phone_set:
        return None
    builder = InlineKeyboardBuilder()
    builder.button(text="📱 নিজের নম্বর সেট করুন", callback_data="cust:setphone", **primary())
    builder.adjust(1)
    return builder.as_markup()


def customer_pay_methods_kb(methods: list[str], cash_enabled: bool = True) -> InlineKeyboardMarkup:
    """গ্রাহকের পেমেন্ট মাধ্যম বাছাই (ডায়নামিক)।"""
    builder = InlineKeyboardBuilder()
    for method in methods:
        builder.button(text=method, callback_data=f"custpay:{method}", **primary())
    if cash_enabled:
        builder.button(text="🤝 ক্যাশ পেমেন্ট", callback_data="custpay:Cash", **success())
    builder.button(text="❌ বাতিল", callback_data="custpay:cancel", **danger())
    builder.adjust(2)
    return builder.as_markup()


def deposit_methods_kb(
    methods: list[str],
    cash_enabled: bool = True,
    last_method: str | None = None,
) -> InlineKeyboardMarkup:
    """ব্যালান্স ডিপোজিটের মাধ্যম বাছাই (ডায়নামিক)। শেষ ব্যবহৃত মাধ্যমে ⭐।"""
    builder = InlineKeyboardBuilder()
    for method in methods:
        label = f"⭐ {method}" if last_method and method == last_method else method
        builder.button(text=label, callback_data=f"dep:{method}", **primary())
    if cash_enabled:
        builder.button(text="🤝 ক্যাশ পেমেন্ট", callback_data="dep:Cash", **success())
    builder.button(text="❌ বাতিল", callback_data="dep:cancel", **danger())
    builder.adjust(2)
    return builder.as_markup()


def deposit_amount_kb(
    presets: tuple[int, ...] = (100, 200, 500, 1000),
    back_data: str = "dep:back:method",
) -> InlineKeyboardMarkup:
    """ডিপোজিট পরিমাণ ধাপ — প্রি-সেট অ্যামাউন্ট বাটন + পিছনে।"""
    builder = InlineKeyboardBuilder()
    for amt in presets:
        builder.button(
            text=f"৳ {to_bn_digits(amt)}",
            callback_data=f"dep:amt:{amt}",
            **success(),
        )
    builder.button(text="🔙 পিছনে", callback_data=back_data, **primary())
    builder.adjust(2, 2, 1)
    return builder.as_markup()


def deposit_confirm_kb(
    confirm_data: str = "dep:confirm",
    back_data: str = "dep:back:confirm",
) -> InlineKeyboardMarkup:
    """ডিপোজিট চূড়ান্ত নিশ্চিতকরণ।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ নিশ্চিত করুন", callback_data=confirm_data, **success())
    builder.button(text="🔙 পিছনে", callback_data=back_data, **primary())
    builder.adjust(1)
    return builder.as_markup()


def back_kb(back_data: str = "dep:back") -> InlineKeyboardMarkup:
    """শুধু একটি '🔙 পিছনে' বাটন।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="🔙 পিছনে", callback_data=back_data, **primary())
    return builder.as_markup()


def packages_buy_kb(packages) -> InlineKeyboardMarkup:
    """কেনার জন্য সক্রিয় প্যাকেজের তালিকা।"""
    builder = InlineKeyboardBuilder()
    for pkg in packages:
        builder.button(
            text=f"{pkg.name} — {fmt_money(pkg.price)} ({to_bn_digits(pkg.duration_days)} দিন)",
            callback_data=f"buy:{pkg.id}",
            **primary(),
        )
    builder.button(text="❌ বাতিল", callback_data="buy:cancel", **danger())
    builder.adjust(1)
    return builder.as_markup()


def buy_credit_kb(package_id: int, back_data: str | None = None) -> InlineKeyboardMarkup:
    """ব্যালান্স কম হলে বাকিতে কেনার নিশ্চিতকরণ বাটন।"""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="🧾 বাকিতে কিনুন",
        callback_data=f"buycredit:{package_id}",
        **success(),
    )
    if back_data:
        builder.button(text="🔙 পিছনে", callback_data=back_data, **primary())
    builder.button(text="❌ বাতিল", callback_data="buy:cancel", **danger())
    builder.adjust(1)
    return builder.as_markup()


def due_pay_kb() -> InlineKeyboardMarkup:
    """বকেয়া থাকলে ব্যালান্স স্ক্রিনে 'বকেয়া পরিশোধ' বাটন।"""
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 বকেয়া পরিশোধ", callback_data="cust:duepay", **primary())
    builder.adjust(1)
    return builder.as_markup()
