"""এন্ট্রি পয়েন্ট — বট চালু করার জায়গা।

কাজের ক্রম:
1. লগিং চালু
2. ডাটাবেস টেবিল তৈরি
3. Bot + Dispatcher তৈরি, middleware ও router রেজিস্টার
4. শিডিউলার চালু
5. পলিং শুরু
"""

from __future__ import annotations

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from app.config import settings
from app.database.base import db
from app.handlers import register_all_handlers
from app.middlewares.auth import RoleMiddleware
from app.middlewares.force_join import ForceJoinMiddleware
from app.middlewares.private_only import PrivateOnlyMiddleware
from app.middlewares.text_override import TextOverrideMiddleware
from app.middlewares.throttling import ThrottlingMiddleware
from app.scheduler import setup_scheduler
from app.services.package_service import package_service
from app.services.text_service import text_service
from app.utils.logger import get_logger, setup_logging

log = get_logger(__name__)


async def on_startup(bot: Bot) -> None:
    """চালু হওয়ার সময় owner কে জানানো।"""
    try:
        await bot.send_message(settings.owner_id, "\u2705 \u09ac\u099f \u099a\u09be\u09b2\u09c1 \u09b9\u09af\u09bc\u09c7\u099b\u09c7\u0964 /start \u09a6\u09bf\u09af\u09bc\u09c7 \u09b6\u09c1\u09b0\u09c1 \u0995\u09b0\u09c1\u09a8\u0964")
    except Exception as exc:
        log.warning("Startup owner notify failed: %s", exc)


async def main() -> None:
    setup_logging()
    log.info("WiFi bot \u099a\u09be\u09b2\u09c1 \u09b9\u099a\u09cd\u099b\u09c7...")

    # ডাটাবেস টেবিল তৈরি (না থাকলে)
    await db.create_all()
    # প্রথমবার চালু হলে ডিফল্ট প্যাকেজ সিড করি
    await package_service.ensure_defaults()
    # এডমিন-এডিটযোগ্য টেক্সট override গুলো মেমোরিতে লোড করি
    await text_service.preload()
    log.info("\u09a1\u09be\u099f\u09be\u09ac\u09c7\u09b8 \u09aa\u09cd\u09b0\u09b8\u09cd\u09a4\u09c1\u09a4\u0964")

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())

    # TextOverrideMiddleware: পাঠানোর মুহূর্তে owner-এর এডিট করা টেক্সট বসায়
    # (owner কিছু এডিট না করলে কিছুই বদলায় না — নিরাপদ পাস-থ্রু)
    bot.session.middleware(TextOverrideMiddleware())

    # --- Middleware ---
    # RoleMiddleware: প্রতি আপডেটে is_owner ইনজেক্ট করে
    dp.message.middleware(RoleMiddleware())
    dp.callback_query.middleware(RoleMiddleware())
    # ThrottlingMiddleware: flood protection
    dp.message.middleware(ThrottlingMiddleware(rate=settings.throttle_rate))
    # ForceJoinMiddleware: চ্যানেলে জয়েন বাধ্যতামূলক করার গেট
    # outer_middleware: হ্যান্ডলার-হীন “জয়েন করেছি” কলব্যাকেও গেট কাজ করে
    # PrivateOnlyMiddleware: group/channel ignore -- private chat only.
    # MUST run before ForceJoin so group updates are dropped first.
    dp.message.outer_middleware(PrivateOnlyMiddleware())
    dp.callback_query.outer_middleware(PrivateOnlyMiddleware())
    dp.message.outer_middleware(ForceJoinMiddleware())
    dp.callback_query.outer_middleware(ForceJoinMiddleware())

    # --- Routers ---
    register_all_handlers(dp)

    # --- Scheduler ---
    scheduler = setup_scheduler(bot)
    scheduler.start()
    log.info("\u09b6\u09bf\u09a1\u09bf\u0989\u09b2\u09be\u09b0 \u099a\u09be\u09b2\u09c1\u0964")

    await on_startup(bot)

    try:
        # webhook মুছে polling শুরু
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
    finally:
        scheduler.shutdown(wait=False)
        await bot.session.close()
        await db.dispose()
        log.info("\u09ac\u099f \u09ac\u09a8\u09cd\u09a7 \u09b9\u09b2\u09cb\u0964")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        log.info("\u09ac\u09cd\u09af\u09ac\u09b9\u09be\u09b0\u0995\u09be\u09b0\u09c0 \u09ac\u09a8\u09cd\u09a7 \u0995\u09b0\u09b2\u09c7\u09a8\u0964")
