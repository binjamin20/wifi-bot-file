"""কনফিগারেশন লেয়ার।

.env ফাইল থেকে সব সেটিংস নিরাপদভাবে লোড করে।
Frontend/handler কোথাও hard-coded টোকেন বা owner id রাখা হয় না — সব এখানে।
"""

from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """অ্যাপের সব এনভায়রনমেন্ট ভ্যারিয়েবল।"""

    # --- Telegram ---
    bot_token: str
    owner_id: int
    # গ্রাহক প্যানেলে "Contact Owner" এ দেখানো হবে (ফোন/ইউজারনেম)
    owner_contact: str = ""

    # --- Database ---
    database_url: str = "sqlite+aiosqlite:///data/wifi_bot.db"

    # --- Timezone / Scheduler ---
    timezone: str = "Asia/Dhaka"
    daily_report_hour: int = 8
    daily_report_minute: int = 0
    reminder_hour: int = 9
    reminder_minute: int = 0
    backup_hour: int = 2
    backup_minute: int = 0
    # বকেয়া রিমাইন্ডার কখন যাবে (প্রতিদিন একবার)
    due_reminder_hour: int = 11
    due_reminder_minute: int = 0

    # --- Business rules ---
    expiring_soon_days: int = 7
    throttle_rate: float = 0.6
    log_level: str = "INFO"
    # বাকিতে প্যাকেজ নিতে হলে এখনই ন্যূনতম যত অংশ দিতে হবে (০.৫ = ৫০%)
    credit_min_pay_ratio: float = 0.5

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    """সেটিংস সিঙ্গেলটন (একবারই লোড হয়)।"""
    return Settings()  # type: ignore[call-arg]


settings = get_settings()
