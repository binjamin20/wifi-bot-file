"""Force Join middleware — চ্যানেল জয়েন বাধ্যতামূলক করা (চালু থাকলে)।

- এডমিন সবসময় বাইপাস করে।
- সিস্টেম বন্ধ থাকলে বা কোনো চ্যানেল না থাকলে কিছুই হয় না।
- চেক করতে বটকে ঐ চ্যানেলে অ্যাডমিন হতে হবে; না পারলে ঐ চ্যানেল স্কিপ হয়।
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.config import settings
from app.keyboards.customer_kb import customer_menu
from app.services.customer_service import customer_service
from app.services.settings_service import settings_service
from app.utils.logger import get_logger
from app.utils.ui import primary, success

log = get_logger(__name__)

_JOINED_STATUSES = {"creator", "administrator", "member"}


async def _check(bot, target, user_id):
    """একটি চ্যানেলে মেম্বারশিপ চেক — True=জয়েন, False=জয়েন করেনি, None=যাচাই করা যায়নি।"""
    try:
        member = await bot.get_chat_member(target, user_id)
        status = getattr(member, "status", "")
        status = getattr(status, "value", status)
        if status in _JOINED_STATUSES or (
            status == "restricted" and getattr(member, "is_member", False)
        ):
            return True
        return False
    except Exception as exc:  # বট অ্যাডমিন না হলে / চ্যানেল না পেলে
        log.warning("Force-join check failed for %s: %s", target, exc)
        return None


async def _evaluate(bot, channels: list[str], user_id: int):
    """ফেরত: (blocked, to_show)।

    - blocked: অন্তত একটি চ্যানেলে নিশ্চিতভাবে জয়েন করেননি।
    - to_show: যেসব চ্যানেলের জয়েন বাটন দেখাতে হবে (নিশ্চিত না-জয়েন + যাচাই-অযোগ্য)।
    যাচাই করা না গেলে (বট অ্যাডমিন নয়) সেটির জন্য ব্লক করি না — যেন কেউ চিরতরে আটকে না যায়।
    """
    not_joined: list[str] = []
    unverifiable: list[str] = []
    for ch in channels:
        target = await settings_service.resolve_chat_target(ch)
        result = await _check(bot, target, user_id)
        if result is True:
            continue
        if result is False:
            not_joined.append(ch)
        else:
            unverifiable.append(ch)
    return (len(not_joined) > 0), (not_joined + unverifiable)


def _channel_button(builder, ch: str, meta_map: dict) -> bool:
    """একটি চ্যানেলের জয়েন বাটন যোগ করে; URL বানানো গেলে True।"""
    meta = meta_map.get(ch) or {}
    uname = (meta.get("username") or "").lstrip("@")
    raw = ch.lstrip("@")
    if uname:
        url, label = "https://t.me/" + uname, "@" + uname
    elif raw.startswith("+"):
        url, label = "https://t.me/" + raw, (meta.get("title") or "চ্যানেল/গ্রুপ")
    elif raw.lstrip("-").isdigit():
        url, label = None, (meta.get("title") or "চ্যানেল/গ্রুপ")
    else:
        url, label = "https://t.me/" + raw, "@" + raw
    if not url:
        return False
    builder.button(text=f"📢 জয়েন: {label}", url=url, **primary())
    return True


def _gate_kb(channels: list[str], meta_map: dict | None = None):
    meta_map = meta_map or {}
    builder = InlineKeyboardBuilder()
    for ch in channels:
        _channel_button(builder, ch, meta_map)
    builder.button(text="✅ জয়েন করেছি / চেক করুন", callback_data="fjverify", **success())
    builder.adjust(1)
    return builder.as_markup()


class ForceJoinMiddleware(BaseMiddleware):
    """চালু থাকলে নন-এডমিন ইউজারকে জয়েন করতে বাধ্য করে।"""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = getattr(event, "from_user", None)
        if user is None or user.id == settings.owner_id:
            return await handler(event, data)
        if not await settings_service.is_force_join_enabled():
            return await handler(event, data)
        channels = await settings_service.list_force_join_channels()
        if not channels:
            return await handler(event, data)
        bot = data.get("bot")
        if bot is None:
            return await handler(event, data)
        blocked, to_show = await _evaluate(bot, channels, user.id)
        if not blocked:
            if isinstance(event, CallbackQuery) and event.data == "fjverify":
                await event.answer("✅ ধন্যবাদ! আপনি সফলভাবে জয়েন করেছেন।", show_alert=True)
                if event.message is not None:
                    try:
                        await event.message.edit_text(
                            "✅ <b>ধন্যবাদ! সব চ্যানেলে জয়েন সম্পন্ন হয়েছে।</b>"
                        )
                    except Exception:
                        pass
                    try:
                        registered = (
                            await customer_service.get_by_telegram_id(user.id)
                        ) is not None
                        await event.message.answer(
                            "🎉 এখন থেকে আপনি বট ব্যবহার করতে পারবেন।\n"
                            "নিচের মেনু থেকে বেছে নিন। 👇",
                            reply_markup=customer_menu(registered),
                        )
                    except Exception:
                        pass
                return None
            return await handler(event, data)
        text = (
            "🔒 <b>বট ব্যবহার করতে হলে</b>\n"
            "নিচের চ্যানেল(গুলো)তে জয়েন করুন, তারপর \"✅ জয়েন করেছি\" চাপুন:"
        )
        meta_map = await settings_service.get_chat_meta_map()
        kb = _gate_kb(to_show or channels, meta_map)
        if isinstance(event, CallbackQuery):
            await event.answer("❌ আপনি এখনো সব চ্যানেলে জয়েন করেননি।", show_alert=True)
            if event.message is not None:
                try:
                    await event.message.answer(text, reply_markup=kb)
                except Exception:
                    pass
        elif isinstance(event, Message):
            await event.answer(text, reply_markup=kb)
        return None
