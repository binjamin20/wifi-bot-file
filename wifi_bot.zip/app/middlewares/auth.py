"""Role-based access middleware।

প্রতিটি আপডেটে `is_owner` ফ্ল্যাগ হ্যান্ডলারে ইনজেক্ট করে।
Owner-only রাউটারে OwnerOnlyMiddleware লাগানো হয় — অন্য কেউ ডাকলে ব্লক।
Database-backed owner id .env থেকে আসে — কখনো hard-coded নয়।
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject, User

from app.config import settings
from app.utils.logger import get_logger

log = get_logger(__name__)


def _extract_user(event: TelegramObject) -> User | None:
    return getattr(event, "from_user", None)


class RoleMiddleware(BaseMiddleware):
    """সব আপডেটে is_owner ফ্ল্যাগ যোগ করে।"""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = _extract_user(event)
        data["is_owner"] = bool(user and user.id == settings.owner_id)
        return await handler(event, data)


class OwnerOnlyMiddleware(BaseMiddleware):
    """Owner-only router-এ লাগানো হয় — অন্য ইউজার হলে ব্লক করে।"""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = _extract_user(event)
        if not user or user.id != settings.owner_id:
            log.warning("Unauthorized owner action attempt by user_id=%s", getattr(user, "id", None))
            if isinstance(event, CallbackQuery):
                await event.answer("\u26d4 \u098f\u0987 \u0995\u09ae\u09be\u09a8\u09cd\u09a1 \u09b6\u09c1\u09a7\u09c1 \u098f\u09a1\u09ae\u09bf\u09a8 \u098f\u09b0 \u099c\u09a8\u09cd\u09af\u0964", show_alert=True)
            elif isinstance(event, Message):
                await event.answer("\u26d4 \u098f\u0987 \u0995\u09ae\u09be\u09a8\u09cd\u09a1 \u09b6\u09c1\u09a7\u09c1 \u098f\u09a1\u09ae\u09bf\u09a8 \u09ac\u09cd\u09af\u09ac\u09b9\u09be\u09b0 \u0995\u09b0\u09a4\u09c7 \u09aa\u09be\u09b0\u09ac\u09c7\u09a8\u0964")
            return None
        return await handler(event, data)
