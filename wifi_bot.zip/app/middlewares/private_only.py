"""Private-only guard — বট শুধু প্রাইভেট চ্যাটে সাড়া দেবে।

গ্রুপ/সুপারগ্রুপ/চ্যানেলের মেসেজ ও কলব্যাক চুপচাপ উপেক্ষা করে (বট যুক্ত
থাকতে পারে, শুধু সেখানকার মেম্বারদের সাথে কথা বলে না)। ForceJoin-সহ বাকি সব
মিডলওয্যারের আগে (outer) রেজিস্টার করতে হবে, যেন গ্রুপ আপডেট শুরুতেই বাদ পড়ে।
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject


class PrivateOnlyMiddleware(BaseMiddleware):
    """প্রাইভেট চ্যাট ছাড়া সব আপডেট ড্রপ করে।"""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        chat = None
        if isinstance(event, Message):
            chat = event.chat
        elif isinstance(event, CallbackQuery):
            chat = event.message.chat if event.message is not None else None
        # প্রাইভেট চ্যাট না হলে সম্পূর্ণ উপেক্ষা
        if chat is not None and getattr(chat, "type", None) != "private":
            if isinstance(event, CallbackQuery):
                try:
                    await event.answer()
                except Exception:
                    pass
            return None
        return await handler(event, data)
