"""টেক্সট override মিডলওয়্যার — আউটগোইং API কল এর সময় টেক্সট বদলায়।

বট যখন মেসেজ/ক্যাপশন/ইনলাইন বাটন পাঠায়, ঠিক তখন owner-এর এডিট করা
টেক্সট থাকলে বসিয়ে দেয়। owner কিছু এডিট না করলে এটি পিওর পাস-থ্রু —
কিছুই বদলায় না (ভাঙার ঝুঁকি শূন্য)।

নিরাপত্তা: শুধু message text, caption ও *ইনলাইন* কিবোর্ড বাটনের লেখা বদলায়।
রিপ্লাই কিবোর্ড (নিচের মেনু) বাদ — ওগুলো text দিয়ে ম্যাচ হয় বলে লেখা বদলালে বট ভাঙতো।
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiogram.client.session.middlewares.base import BaseRequestMiddleware

from app.services.text_service import text_service
from app.utils.logger import get_logger

if TYPE_CHECKING:  # শুধু টাইপ-চেকিং; রানটাইমে ইমপোর্ট হয় না
    from aiogram import Bot
    from aiogram.client.session.middlewares.base import NextRequestMiddlewareType
    from aiogram.methods import TelegramMethod
    from aiogram.methods.base import Response, TelegramType

log = get_logger(__name__)


def _set(obj: Any, name: str, value: str) -> None:
    try:
        setattr(obj, name, value)
    except Exception:
        try:
            object.__setattr__(obj, name, value)
        except Exception:
            pass


class TextOverrideMiddleware(BaseRequestMiddleware):
    """আউটগোইং Telegram মেথডে owner-এর এডিট করা টেক্সট বসায়।"""

    async def __call__(
        self,
        make_request: "NextRequestMiddlewareType[TelegramType]",
        bot: "Bot",
        method: "TelegramMethod[TelegramType]",
    ) -> "Response[TelegramType]":
        try:
            if text_service.has_overrides():
                self._apply(method)
        except Exception as exc:  # এই লেয়ার যেন কখনও মেসেজ পাঠানো আটকাতে না পারে
            log.warning("Text override apply failed: %s", exc)
        return await make_request(bot, method)

    def _apply(self, method: Any) -> None:
        text = getattr(method, "text", None)
        if isinstance(text, str) and text:
            new = text_service.apply(text)
            if new != text:
                _set(method, "text", new)

        caption = getattr(method, "caption", None)
        if isinstance(caption, str) and caption:
            new = text_service.apply(caption)
            if new != caption:
                _set(method, "caption", new)

        markup = getattr(method, "reply_markup", None)
        rows = getattr(markup, "inline_keyboard", None)  # শুধু ইনলাইন কিবোর্ড
        if rows:
            for row in rows:
                for btn in row:
                    label = getattr(btn, "text", None)
                    if isinstance(label, str) and label:
                        new = text_service.apply(label)
                        if new != label:
                            _set(btn, "text", new)
