"""Flood protection / throttling middleware।

একই ইউজারের দ্রুত পরপর অ্যাকশন সীমিত করে (in-memory)।
"""

from __future__ import annotations

import time
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from app.config import settings


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, rate: float | None = None) -> None:
        self.rate = rate if rate is not None else settings.throttle_rate
        self._last_seen: dict[int, float] = {}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = getattr(event, "from_user", None)
        if user is not None:
            now = time.monotonic()
            last = self._last_seen.get(user.id, 0.0)
            if now - last < self.rate:
                # অতিরিক্ত দ্রুত — নীরবে ড্রপ (callback হলে ছোট জবাব)
                if isinstance(event, CallbackQuery):
                    await event.answer("\u23f3 \u0985\u09a8\u09c1\u0997\u09cd\u09b0\u09b9 \u0995\u09b0\u09c7 \u098f\u0995\u099f\u09c1 \u0985\u09aa\u09c7\u0995\u09cd\u09b7\u09be \u0995\u09b0\u09c1\u09a8\u0964")
                return None
            self._last_seen[user.id] = now
        return await handler(event, data)
