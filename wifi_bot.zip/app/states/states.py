"""Aiogram FSM স্টেট গ্রুপ — মাল্টি-স্টেপ কথোপকথন।"""

from __future__ import annotations

from aiogram.fsm.state import State, StatesGroup


class AddCustomer(StatesGroup):
    name = State()
    phone = State()
    telegram_id = State()
    choosing_package = State()  # সেভ করা প্যাকেজ থেকে সিলেকশন
    address = State()
    package_name = State()
    package_price = State()
    duration = State()
    initial_payment = State()  # গ্রাহক এখন টাকা দিয়েছে কিনা
    custom_payment = State()  # কাস্টম পরিশোধ পরিমাণ
    notes = State()


class EditCustomer(StatesGroup):
    waiting_id = State()
    choosing_field = State()
    waiting_value = State()
    waiting_tgid = State()  # ফাঁকা-আইডি গ্রাহকের Telegram ID সেট


class DeleteCustomer(StatesGroup):
    waiting_id = State()
    confirm = State()


class SearchCustomer(StatesGroup):
    waiting_term = State()


class AddPayment(StatesGroup):
    waiting_customer = State()
    amount = State()
    method = State()
    transaction_id = State()
    note = State()


class RenewFlow(StatesGroup):
    waiting_customer = State()
    choosing_duration = State()
    custom_duration = State()


class Broadcast(StatesGroup):
    waiting_message = State()
    confirm = State()


# ---- প্যাকেজ ব্যবস্থাপনা (এডমিন) ----
class PackageAdmin(StatesGroup):
    """নতুন প্যাকেজ যোগ করার ধাপ।"""

    waiting_name = State()
    waiting_duration = State()
    waiting_price = State()


class PackageEditValue(StatesGroup):
    """একটি প্যাকেজের কোনো ফিল্ড এডিটের নতুন মান।"""

    waiting_value = State()


# ---- গ্রাহক প্যানেলের FSM ----
class CustomerDeposit(StatesGroup):
    """গ্রাহকের নিজের অ্যাকাউন্টে টাকা ডিপোজিট করার ধাপ।"""

    choosing_method = State()
    waiting_amount = State()
    waiting_proof = State()
    waiting_number = State()
    waiting_confirm = State()  # চূড়ান্ত নিশ্চিতকরণ ধাপ


class CustomerBuy(StatesGroup):
    """প্যাকেজ কেনার সময় MAC অ্যাড্রেস নেওয়া।"""

    choosing_package = State()  # package list screen
    waiting_mac = State()
    waiting_confirm = State()  # final confirmation


class CustomerRedeem(StatesGroup):
    """রিডিম কোড লিখে ব্যালান্স যোগ।"""

    waiting_code = State()


class CustomerSetPhone(StatesGroup):
    """গ্রাহক নিজের মোবাইল নম্বর সেট করে (১১ ডিজিট, 01)।"""

    waiting_phone = State()


class OwnerSettings(StatesGroup):
    """owner পেমেন্ট মাধ্যম/নম্বর/সর্বনিম্ন ডিপোজিট সেট করে।"""

    waiting_value = State()
    waiting_method_name = State()
    waiting_method_number = State()
    waiting_min_deposit = State()


class RedeemAdmin(StatesGroup):
    """এডমিন নতুন রিডিম কোড তৈরি করে।"""

    waiting_amount = State()
    waiting_uses = State()


class ManageUser(StatesGroup):
    """এডমিন কোনো ইউজারের ব্যালান্স/তারিখ/তথ্য ম্যানেজ করে।"""

    balance = State()       # +/- ব্যালান্স অ্যাডজাস্ট
    date_value = State()    # সরাসরি start/end তারিখ এডিট
    days = State()          # দিন +/- ইনপুট
    field_value = State()   # প্রোফাইল ফিল্ড এডিট
    tgid_value = State()    # Telegram ID সেট (সংখ্যা ইনপুট)
    tgid_conflict = State() # আইডি কনফ্লিক্ট — ডিলিট/ক্যান্সেল


class ForceJoinAdmin(StatesGroup):
    """এডমিন Force Join চ্যানেল যোগ করে।"""

    waiting_channel = State()


class DirectMessage(StatesGroup):
    """এডমিন নির্দিষ্ট ইউজারকে সরাসরি মেসেজ পাঠায়।"""

    waiting_user = State()
    waiting_text = State()


class MacVideoSettings(StatesGroup):
    """এডমিন MAC ভিডিও সেটিং (লিংক/লেবেল/টেক্সট) এডিট করে।"""

    waiting_value = State()


class OwnerTextEdit(StatesGroup):
    """এডমিন বটের যেকোনো টেক্সট এডিট করে (অল টেক্সট এডিট)।"""

    waiting_value = State()


class OwnerTextSearch(StatesGroup):
    """এডমিন অল টেক্সট এডিট-এ টেক্সট খুঁজে।"""

    waiting_query = State()


class ImportData(StatesGroup):
    """পূর্ণ ইমপোর্ট — ফাইল আপলোড ও কনফার্মেশন।"""

    waiting_file = State()  # owner JSON ফাইল পাঠাবে
    confirm = State()       # সব মুছে রিপ্লেস কনফার্ম
