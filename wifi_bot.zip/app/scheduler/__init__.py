"""শিডিউলার প্যাকেজ।"""

from app.scheduler.jobs import setup_scheduler

__all__ = ["setup_scheduler"]
