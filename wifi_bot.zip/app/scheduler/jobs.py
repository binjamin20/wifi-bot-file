"""APScheduler ভিত্তিক স্বয়ংক্রিয় টাস্ক।

এখানে তিন ধরনের জব চলে:
1. গ্রাহক রিমাইন্ডার (7/3/1 দিন আগে + মেয়াদোত্তীর্ণ নোটিশ) — প্রতিদিন
2. owner এর ডেইলি রিপোর্ট — সকাল ৮টা
3. স্বয়ংক্রিয় ডেইলি ব্যাকআপ
"""

from __future__ import annotations

from datetime import timedelta

from aiogram import Bot
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.config import settings
from app.database.base import db
from app.repositories.customer_repo import CustomerRepository
from app.services.backup_service import backup_service
from app.services.customer_service import customer_service
from app.utils import date_utils
from app.utils.logger import get_logger

log = get_logger(__name__)

# কতদিন আগে রিমাইন্ডার পাঠানো হবে → বার্তা
REMINDER_DAYS = {
    7: "\u26a0 \u0986\u09aa\u09a8\u09be\u09b0 WiFi \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09e7 \u09a6\u09bf\u09a8 \u09aa\u09b0 \u09b6\u09c7\u09b7 \u09b9\u09ac\u09c7\u0964",
    3: "\u26a0 \u0986\u09aa\u09a8\u09be\u09b0 WiFi \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09e9 \u09a6\u09bf\u09a8 \u09aa\u09b0 \u09b6\u09c7\u09b7 \u09b9\u09ac\u09c7\u0964",
    1: "\u26a0 \u0986\u09aa\u09a8\u09be\u09b0 WiFi \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u0986\u0997\u09be\u09ae\u09c0\u0995\u09be\u09b2 \u09b6\u09c7\u09b7 \u09b9\u099a\u09cd\u099b\u09c7\u0964",
}
EXPIRED_TEXT = (
    "\u274c \u0986\u09aa\u09a8\u09be\u09b0 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c\u09c7\u09b0 \u09ae\u09c7\u09af\u09bc\u09be\u09a6 \u09b6\u09c7\u09b7 \u09b9\u09af\u09bc\u09c7 \u0997\u09c7\u099b\u09c7\u0964\n"
    "\u09a6\u09af\u09bc\u09be \u0995\u09b0\u09c7 \u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c \u09b0\u09bf\u09a8\u09bf\u0989 \u0995\u09b0\u09c1\u09a8\u0964"
)


async def send_customer_reminders(bot: Bot) -> None:
    """মেয়াদ শেষের আগে ও পরে গ্রাহককে জানানো।"""
    today = date_utils.today()
    sent = 0
    async with db.session() as session:
        repo = CustomerRepository(session)
        # সামনের রিমাইন্ডার
        for days, text in REMINDER_DAYS.items():
            target = today + timedelta(days=days)
            for customer in await repo.expiring_between(target, target):
                if not customer.telegram_id:
                    continue
                try:
                    await bot.send_message(customer.telegram_id, text)
                    sent += 1
                except Exception as exc:
                    log.warning("Reminder failed for %s: %s", customer.telegram_id, exc)
        # আজ মেয়াদোত্তীর্ণ হওয়া গ্রাহককে এক্সপায়ার্ড নোটিশ
        for customer in await repo.expiring_between(today, today):
            if not customer.telegram_id:
                continue
            try:
                await bot.send_message(customer.telegram_id, EXPIRED_TEXT)
                sent += 1
            except Exception as exc:
                log.warning("Expired notice failed for %s: %s", customer.telegram_id, exc)
    log.info("Customer reminders sent: %s", sent)


async def send_daily_report(bot: Bot) -> None:
    """সকালে owner কে ডেইলি সামারি।"""
    # চক্রীয় ইমপোর্ট এড়াতে এখানে import
    from app.handlers.owner.reports import render_daily_report

    await customer_service.refresh_all_statuses()
    try:
        await bot.send_message(settings.owner_id, await render_daily_report())
    except Exception as exc:
        log.warning("Daily report failed: %s", exc)


async def run_daily_backup(bot: Bot) -> None:
    """স্বয়ংক্রিয় ডেইলি ব্যাকআপ + owner কে জানানো।"""
    try:
        result = await backup_service.run_full_backup()
        log.info("Auto backup done: %s", result)
    except Exception as exc:
        log.error("Auto backup failed: %s", exc)


async def refresh_statuses_job(bot: Bot) -> None:
    """প্রতিদিন সব গ্রাহকের status/remaining_days হালনাগাদ করে।"""
    count = await customer_service.refresh_all_statuses()
    log.info("Statuses refreshed for %s customers", count)


async def send_due_reminders(bot: Bot) -> None:
    """বকেয়া থাকা গ্রাহকদের প্রতিদিন একবার মনে করিয়ে দেওয়া।"""
    sent = 0
    async with db.session() as session:
        repo = CustomerRepository(session)
        for customer in await repo.list_all():
            due = float(customer.due_amount or 0.0)
            if due <= 0 or not customer.telegram_id:
                continue
            try:
                await bot.send_message(
                    customer.telegram_id,
                    f"💳 আপনার {date_utils.fmt_money(due)} বকেয়া রয়েছে।\n"
                    "পরিশোধ করতে মেনু থেকে টাকা জমা করুন — "
                    "জমা হওয়ার সাথে সাথে বকেয়া স্বয়ংক্রিয়ভাবে কেটে নেওয়া হবে।",
                )
                sent += 1
            except Exception as exc:
                log.warning("Due reminder failed for %s: %s", customer.telegram_id, exc)
    log.info("Due reminders sent: %s", sent)


def setup_scheduler(bot: Bot) -> AsyncIOScheduler:
    """সব জব রেজিস্টার করে শিডিউলার ফেরত দেয় (চালু হয় main থেকে)।"""
    scheduler = AsyncIOScheduler(timezone=settings.timezone)

    # প্রতিদিন status refresh (মধ্যরাতের পর)
    scheduler.add_job(
        refresh_statuses_job, "cron", hour=0, minute=5, args=[bot], id="refresh_statuses"
    )
    # গ্রাহক রিমাইন্ডার
    scheduler.add_job(
        send_customer_reminders, "cron",
        hour=settings.reminder_hour, minute=settings.reminder_minute,
        args=[bot], id="customer_reminders",
    )
    # owner এর ডেইলি রিপোর্ট
    scheduler.add_job(
        send_daily_report, "cron",
        hour=settings.daily_report_hour, minute=settings.daily_report_minute,
        args=[bot], id="daily_report",
    )
    # ডেইলি ব্যাকআপ
    scheduler.add_job(
        run_daily_backup, "cron",
        hour=settings.backup_hour, minute=settings.backup_minute,
        args=[bot], id="daily_backup",
    )
    # বকেয়া রিমাইন্ডার (প্রতিদিন একবার)
    scheduler.add_job(
        send_due_reminders, "cron",
        hour=settings.due_reminder_hour, minute=settings.due_reminder_minute,
        args=[bot], id="due_reminders",
    )
    return scheduler
