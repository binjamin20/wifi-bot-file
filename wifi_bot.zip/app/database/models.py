"""ORM মডেল — Customer, Payment, RenewalHistory, Package, PaymentRequest।

- remaining_days ও status ডেরাইভড ভ্যালু — expiry_date থেকে রিফ্রেশ হয়।
- Customer.balance = গ্রাহকের নিজস্ব অ্যাকাউন্ট ব্যালান্স (ওয়ালেট)।
- Package = এডমিন-নিয়ন্ত্রিত প্যাকেজ (নাম/মেয়াদ/দাম এডিটযোগ্য)।
- PaymentRequest = গ্রাহকের ডিপোজিট বা প্যাকেজ কেনার অনুরোধ (Approve/Reject)।
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base

# স্ট্যাটাস কনস্ট্যান্ট (magic string এড়াতে)
STATUS_ACTIVE = "active"
STATUS_EXPIRED = "expired"

# পেমেন্ট-অনুরোধের ধরন ও অবস্থা
REQ_DEPOSIT = "deposit"
REQ_PACKAGE = "package"
REQUEST_PENDING = "pending"
REQUEST_APPROVED = "approved"
REQUEST_REJECTED = "rejected"


class Customer(Base):
    """একজন WiFi গ্রাহক।"""

    __tablename__ = "customers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    phone: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    # গ্রাহকের Telegram numeric ID — কাস্টমার প্যানেল লগইনে ব্যবহৃত।
    telegram_id: Mapped[int | None] = mapped_column(
        BigInteger, nullable=True, unique=True, index=True
    )
    # গ্রাহকের Telegram ইউজারনেম ও অ্যাকাউন্টের নাম (প্যানেল ব্যবহারের সময় হালনাগাদ হয়)।
    telegram_username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    telegram_name: Mapped[str | None] = mapped_column(String(120), nullable=True)

    package_name: Mapped[str] = mapped_column(String(120), nullable=False)
    package_price: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)

    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    expiry_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    # প্যাকেজ চালুর মুহূর্ত ধরে নির্ভুল মেয়াদ-শেষের সময় (naive লোকাল সময়)।
    # থাকলে অবশিষ্ট 'দিন ঘণ্টা' এখান থেকে নির্ভুলভাবে গণনা হয়; না থাকলে expiry_date fallback।
    expiry_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # cache করা ডেরাইভড ফিল্ড (scheduler ও আপডেট-এ রিফ্রেশ হয়)
    remaining_days: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default=STATUS_ACTIVE, index=True
    )

    paid_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    due_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    # গ্রাহকের নিজস্ব অ্যাকাউন্ট ব্যালান্স (ডিপোজিট জমা হয়, প্যাকেজ কিনলে কাটা যায়)।
    balance: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    # গ্রাহকের সর্বশেষ জানা MAC অ্যাড্রেস (প্যাকেজ কেনার সময় নেওয়া হয়)।
    mac_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    # এডমিন কর্তৃক ব্যান — True হলে গ্রাহক এডমিনের কাছে কোনো অনুরোধ পাঠাতে পারে না।
    is_banned: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    payments: Mapped[list["Payment"]] = relationship(
        back_populates="customer",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    renewals: Mapped[list["RenewalHistory"]] = relationship(
        back_populates="customer",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Customer id={self.id} name={self.name!r} status={self.status}>"


class Payment(Base):
    """একটি পেমেন্ট রেকর্ড।"""

    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True
    )
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    payment_method: Mapped[str] = mapped_column(String(32), nullable=False)
    # True হলে এই পেমেন্ট owner-এর প্রকৃত আয় (ড্যাশবোর্ড কালেকশনে গণনা হয়)।
    # ডিপোজিট/রিডিম = শুধু ব্যালান্স টপ-আপ → False; প্যাকেজ কিনলে তবেই আয়।
    counts_as_income: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True
    )
    transaction_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )

    customer: Mapped["Customer"] = relationship(back_populates="payments")


class RenewalHistory(Base):
    """একটি রিনিউয়াল ইতিহাস রেকর্ড।"""

    __tablename__ = "renewal_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True
    )
    old_expiry: Mapped[date | None] = mapped_column(Date, nullable=True)
    new_expiry: Mapped[date] = mapped_column(Date, nullable=False)
    duration: Mapped[int] = mapped_column(Integer, nullable=False)  # দিন সংখ্যা
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    customer: Mapped["Customer"] = relationship(back_populates="renewals")


class Package(Base):
    """এডমিন-নিয়ন্ত্রিত প্যাকেজ (নাম, মেয়াদ-দিন, দাম)।"""

    __tablename__ = "packages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    duration_days: Mapped[int] = mapped_column(Integer, nullable=False)
    price: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Package id={self.id} name={self.name!r} days={self.duration_days}>"


class PaymentRequest(Base):
    """গ্রাহকের ডিপোজিট বা প্যাকেজ কেনার অনুরোধ — Approve/Reject করা যায়।"""

    __tablename__ = "payment_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # গ্রাহক ডিলিট হলেও অনুরোধ ইতিহাস থাকুক (SET NULL)।
    customer_id: Mapped[int | None] = mapped_column(
        ForeignKey("customers.id", ondelete="SET NULL"), nullable=True, index=True
    )
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    telegram_username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    telegram_name: Mapped[str | None] = mapped_column(String(120), nullable=True)

    req_type: Mapped[str] = mapped_column(String(16), nullable=False)  # deposit / package
    amount: Mapped[float | None] = mapped_column(Float, nullable=True)
    method: Mapped[str | None] = mapped_column(String(32), nullable=True)
    transaction_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    # গ্রাহক যে নম্বর থেকে টাকা পাঠিয়েছে (ডিপোজিটে আবশ্যক)।
    sender_number: Mapped[str | None] = mapped_column(String(32), nullable=True)

    package_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    package_name: Mapped[str | None] = mapped_column(String(120), nullable=True)
    duration_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # বাকিতে (credit) কেনার অনুরোধ কিনা
    is_credit: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    # বাকিতে কেনার অনুরোধে এখন কত নগদ (ব্যালান্স থেকে) ও কত বকেয়া থাকবে (স্ন্যাপশট)
    paid_now: Mapped[float | None] = mapped_column(Float, nullable=True)
    credit_due: Mapped[float | None] = mapped_column(Float, nullable=True)
    # প্যাকেজ কেনার অনুরোধে গ্রাহকের দেওয়া MAC অ্যাড্রেস (ঐচ্ছিক)।
    mac_address: Mapped[str | None] = mapped_column(String(64), nullable=True)

    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default=REQUEST_PENDING, index=True
    )
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )
    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class AppSetting(Base):
    """key-value সেটিংস (পেমেন্ট নম্বর, সর্বনিম্ন ডিপোজিট ইত্যাদি — এডমিন এডিটযোগ্য)।"""

    __tablename__ = "app_settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<AppSetting key={self.key!r}>"


class RedeemCode(Base):
    """রিডিম/ভাউচার কোড — নির্দিষ্ট টাকা ও সর্বোচ্চ কতজন ব্যবহার করতে পারবে।"""

    __tablename__ = "redeem_codes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)
    amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    max_uses: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    used_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<RedeemCode code={self.code!r} amount={self.amount}>"


class RedeemUse(Base):
    """একটি রিডিম কোড কে কখন ব্যবহার করেছে (একজন একবারই পারবে — গার্ড)।"""

    __tablename__ = "redeem_uses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code_id: Mapped[int] = mapped_column(
        ForeignKey("redeem_codes.id", ondelete="CASCADE"), nullable=False, index=True
    )
    customer_id: Mapped[int | None] = mapped_column(
        ForeignKey("customers.id", ondelete="SET NULL"), nullable=True, index=True
    )
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class PackagePurchase(Base):
    """প্যাকেজ কেনার ইতিহাস — কখন (সময়সহ) কোন প্যাকেজ কেনা হয়েছিল।"""

    __tablename__ = "package_purchases"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True
    )
    package_name: Mapped[str] = mapped_column(String(120), nullable=False)
    duration_days: Mapped[int] = mapped_column(Integer, nullable=False)
    price: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    mac_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    expiry_date: Mapped[date] = mapped_column(Date, nullable=False)
    # প্যাকেজ কেনার পর গ্রাহকের অবশিষ্ট ব্যালান্স।
    balance_after: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    # কেনার সময় (তারিখ + সময়)।
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<PackagePurchase id={self.id} cust={self.customer_id} pkg={self.package_name!r}>"
