"""ডেটাবেজ ইঞ্জিন ও সেশন ফ্যাক্টরি (SQLAlchemy 2.0 async)।

- SQLite (default) এবং PostgreSQL দুটোই সাপোর্ট করে (DATABASE_URL দিয়ে নিয়ন্ত্রিত)।
- `Database` ক্লাস একটি সিঙ্গেলটন হিসেবে ব্যবহৃত হয় (নিচে `db`)।
- create_all() ছাড়াও পুরোনো DB-তে নতুন কলাম যোগ করার হালকা মাইগ্রেশন আছে।
"""

from __future__ import annotations

import os

from sqlalchemy import inspect as sa_inspect, text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from app.config import settings
from app.utils.logger import get_logger

log = get_logger(__name__)

# পুরোনো ডেটাবেসে যোগ করতে হবে এমন কলাম (table -> {column: SQL type})।
_MIGRATION_COLUMNS: dict[str, dict[str, str]] = {
    "customers": {
        "telegram_username": "VARCHAR(64)",
        "telegram_name": "VARCHAR(120)",
        "balance": "FLOAT DEFAULT 0",
        "mac_address": "VARCHAR(64)",
        "due_amount": "FLOAT DEFAULT 0",
        "expiry_at": "DATETIME",
        "is_banned": "BOOLEAN DEFAULT 0",
    },
    "payment_requests": {
        "mac_address": "VARCHAR(64)",
        "sender_number": "VARCHAR(32)",
        "is_credit": "BOOLEAN DEFAULT 0",
        "paid_now": "FLOAT",
        "credit_due": "FLOAT",
    },
    "package_purchases": {
        "balance_after": "FLOAT DEFAULT 0",
    },
    "payments": {
        "counts_as_income": "BOOLEAN DEFAULT 1",
    },
}


class Base(DeclarativeBase):
    """সব ORM মডেলের বেস ক্লাস।"""


class Database:
    """Async ইঞ্জিন + সেশন ফ্যাক্টরি র‍্যাপার।"""

    def __init__(self, url: str) -> None:
        self._ensure_sqlite_dir(url)
        # SQLite-এ pool_pre_ping দরকার নেই, কিন্তু Postgres-এ কানেকশন হেল্থ চেক ভালো।
        self.engine = create_async_engine(
            url,
            echo=False,
            pool_pre_ping=not url.startswith("sqlite"),
        )
        self.session_factory: async_sessionmaker[AsyncSession] = async_sessionmaker(
            bind=self.engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

    @staticmethod
    def _ensure_sqlite_dir(url: str) -> None:
        """SQLite ফাইলের ডিরেক্টরি না থাকলে তৈরি করে।"""
        if url.startswith("sqlite") and "///" in url:
            path = url.split("///", 1)[1]
            directory = os.path.dirname(path)
            if directory:
                os.makedirs(directory, exist_ok=True)

    async def create_all(self) -> None:
        """সব টেবিল তৈরি করে (যদি না থাকে) এবং প্রয়োজনে নতুন কলাম যোগ করে।"""
        # মডেল ইম্পোর্ট নিশ্চিত করতে এখানে লোকাল ইম্পোর্ট।
        from app.database import models  # noqa: F401

        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        await self._ensure_columns()
        log.info("Database tables ready.")

    async def _ensure_columns(self) -> None:
        """পুরোনো ডেটাবেসে নতুন কলাম না থাকলে ALTER TABLE দিয়ে যোগ করে।"""

        def _existing(sync_conn, table_name: str) -> set[str]:
            insp = sa_inspect(sync_conn)
            if not insp.has_table(table_name):
                return set()
            return {col["name"] for col in insp.get_columns(table_name)}

        async with self.engine.begin() as conn:
            for table_name, columns in _MIGRATION_COLUMNS.items():
                existing = await conn.run_sync(_existing, table_name)
                if not existing:
                    continue  # টেবিল নেই — create_all সঠিক স্কিমা তৈরি করেছে।
                for column, col_type in columns.items():
                    if column not in existing:
                        await conn.execute(
                            text(
                                f'ALTER TABLE "{table_name}" '
                                f'ADD COLUMN "{column}" {col_type}'
                            )
                        )
                        log.info("Migrated: added %s.%s", table_name, column)
                        # নতুন income-ফ্ল্যাগ যোগ হলে পুরোনো ডিপোজিট/রিডিম
                        # রেকর্ডকে আয় থেকে বাদ দিই (এগুলো ব্যালান্স টপ-আপ মাত্র)।
                        if (
                            table_name == "payments"
                            and column == "counts_as_income"
                        ):
                            await conn.execute(
                                text(
                                    "UPDATE payments SET counts_as_income = 0 "
                                    "WHERE payment_method = 'Redeem' "
                                    "OR note LIKE 'ব্যালান্স ডিপোজিট%'"
                                )
                            )
                            log.info(
                                "Backfilled non-income payments (deposit/redeem)"
                            )
                        # নতুন expiry_at যোগ হলে পুরোনো গ্রাহকদের জন্য মেয়াদ দিনের
                        # শেষ (পরের দিনের 00:00) ধরে ব্যাকফিল করি।
                        if (
                            table_name == "customers"
                            and column == "expiry_at"
                        ):
                            await conn.execute(
                                text(
                                    "UPDATE customers "
                                    "SET expiry_at = datetime(expiry_date, '+1 day') "
                                    "WHERE expiry_at IS NULL AND expiry_date IS NOT NULL"
                                )
                            )
                            log.info(
                                "Backfilled customers.expiry_at from expiry_date"
                            )

    def session(self) -> AsyncSession:
        """নতুন async সেশন ফেরত দেয় (async with এ ব্যবহার করো)।"""
        return self.session_factory()

    async def dispose(self) -> None:
        await self.engine.dispose()


# গ্লোবাল সিঙ্গেলটন — সব রিপোজিটরি/সার্ভিস এটি ব্যবহার করে।
db = Database(settings.database_url)
