"""এনটিটি → মানুষ-পঠনযোগ্য টেক্সট (বাংলা) ফর্ম্যাটার।"""

from __future__ import annotations

from app.database.models import (
    REQ_PACKAGE,
    STATUS_ACTIVE,
    Customer,
    Package,
    PackagePurchase,
    Payment,
    PaymentRequest,
)
from app.utils.date_utils import (
    fmt_date,
    fmt_datetime,
    fmt_money,
    remaining_days,
    remaining_label,
    to_bn_digits,
)

# পেমেন্ট মেথড বাংলা লেবেল
PAYMENT_METHODS = ["Cash", "Bkash", "Nagad", "Rocket", "Bank"]


def status_badge(customer: Customer) -> str:
    """স্ট্যাটাস ব্যাজ।"""
    if customer.status == STATUS_ACTIVE:
        return "\U0001f7e2 এক্টিভ"
    return "\U0001f534 মেয়াদোত্তীর্ণ"


def customer_profile(customer: Customer) -> str:
    """Owner-এর জন্য পূর্ণ গ্রাহক প্রোফাইল।"""
    days = remaining_days(customer.expiry_date)
    if days >= 0:
        days_txt = remaining_label(customer.expiry_date, customer.expiry_at)
    else:
        days_txt = f"{to_bn_digits(abs(days))} দিন আগে শেষ"
    tg_id = str(customer.telegram_id) if customer.telegram_id else "-"
    username = ("@" + customer.telegram_username) if customer.telegram_username else "-"
    tg_name = customer.telegram_name or "-"
    return (
        f"\U0001f464 <b>{customer.name}</b>  (#{to_bn_digits(customer.id)})\n"
        f"\U0001f4de ফোন: {customer.phone}\n"
        f"\U0001f194 Telegram ID: <code>{tg_id}</code>\n"
        f"\U0001f516 ইউজারনেম: {username}\n"
        f"\U0001f9d1 টেলিগ্রাম নাম: {tg_name}\n"
        f"\U0001f50c MAC: {customer.mac_address or '-'}\n"
        f"\U0001f4e6 প্যাকেজ: {customer.package_name}\n"
        f"\U0001f4b5 মূল্য: {fmt_money(customer.package_price)}\n"
        f"\U0001f4ca স্ট্যাটাস: {status_badge(customer)}\n"
        f"\U0001f4c5 শুরু: {fmt_date(customer.start_date)}\n"
        f"\u23f3 মেয়াদ: {fmt_date(customer.expiry_date)} ({days_txt})\n"
        f"\u2705 পরিশোধ: {fmt_money(customer.paid_amount)}\n"
        f"\u274c বকেয়া: {fmt_money(customer.due_amount)}\n"
        f"\U0001f4b0 ব্যালান্স: {fmt_money(customer.balance)}\n"
        f"\U0001f4dd নোট: {customer.notes or '-'}"
    )


def customer_self_package(customer: Customer) -> str:
    """Customer প্যানেল — My Package।"""
    return (
        f"\U0001f4e6 <b>আপনার প্যাকেজ</b>\n\n"
        f"\U0001f4e6 নাম: {customer.package_name or 'সংযোগ নেই'}\n"
        f"\U0001f4b5 মূল্য: {fmt_money(customer.package_price)}\n"
        f"\U0001f4c5 শুরু: {fmt_date(customer.start_date)}\n"
        f"\u23f3 মেয়াদ: {fmt_date(customer.expiry_date)}\n"
        f"\u23f3 অবশিষ্ট: {remaining_label(customer.expiry_date, customer.expiry_at)}\n"
        f"\U0001f50c MAC: {customer.mac_address or 'সংযোগ নেই'}\n"
        f"\u2705 পরিশোধ: {fmt_money(customer.paid_amount)}\n"
        f"\u274c বকেয়া: {fmt_money(customer.due_amount)}\n"
        f"\U0001f4b0 ব্যালান্স: {fmt_money(customer.balance)}\n"
        f"\U0001f4ca স্ট্যাটাস: {status_badge(customer)}"
    )


def customer_row(customer: Customer) -> str:
    """লিস্ট-এ এক লাইন সারাংশ।"""
    return (
        f"{status_badge(customer)[:2]} <b>{customer.name}</b> "
        f"— {customer.package_name} "
        f"({remaining_label(customer.expiry_date, customer.expiry_at)})"
    )


def payment_row(payment: Payment) -> str:
    """একটি পেমেন্ট লাইন — ধরনসহ (ডিপোজিট / প্যাকেজ / রিডিম)।"""
    when = fmt_datetime(payment.created_at) if payment.created_at else "-"
    method = payment.payment_method or "-"
    note = (payment.note or "").strip()
    if method == "Balance":
        icon, label = "📦", (note or "প্যাকেজ কেনা")
        sign = "➖"
    elif method == "Redeem":
        icon, label = "🎁", (note or "রিডিম কোড")
        sign = "➕"
    elif method == "Due":
        icon, label = "🧾", (note or "বকেয়া পরিশোধ")
        sign = "➖"
    elif not payment.counts_as_income:
        icon, label = "💰", (note or "ব্যালান্স ডিপোজিট")
        sign = "➕"
    else:
        icon, label = "💵", (note or "পরিশোধ")
        sign = ""
    txn = f" · 🧾 {payment.transaction_id}" if payment.transaction_id else ""
    return (
        f"{icon} <b>{label}</b>\n"
        f"   {sign}{fmt_money(payment.amount)} · {method} · {when}{txn}"
    )


def package_row(pkg: Package) -> str:
    """প্যাকেজ তালিকার এক লাইন।"""
    state = "\U0001f7e2" if pkg.is_active else "\u26aa"
    return (
        f"{state} <b>{pkg.name}</b> \u2014 {to_bn_digits(pkg.duration_days)} দিন "
        f"\u00b7 {fmt_money(pkg.price)}"
    )


def package_detail(pkg: Package) -> str:
    """একটি প্যাকেজের বিস্তারিত।"""
    state = "\U0001f7e2 চালু" if pkg.is_active else "\u26aa বন্ধ"
    return (
        f"\U0001f4e6 <b>{pkg.name}</b>\n"
        f"\U0001f194 আইডি: {to_bn_digits(pkg.id)}\n"
        f"\U0001f4c5 মেয়াদ: {to_bn_digits(pkg.duration_days)} দিন\n"
        f"\U0001f4b5 দাম: {fmt_money(pkg.price)}\n"
        f"\U0001f4ca অবস্থা: {state}"
    )


def request_card(req: PaymentRequest) -> str:
    """Owner-এর কাছে আসা অনুরোধের কার্ড।"""
    who = req.telegram_name or "গ্রাহক"
    uname = ("@" + req.telegram_username) if req.telegram_username else "-"
    tg_id = str(req.telegram_id) if req.telegram_id else "-"
    if req.req_type == REQ_PACKAGE:
        body = (
            f"ধরন: \U0001f4e6 প্যাকেজ কেনা\n"
            f"প্যাকেজ: {req.package_name} ({to_bn_digits(req.duration_days or 0)} দিন)\n"
            f"মূল্য: {fmt_money(req.amount or 0)}"
        )
        if getattr(req, "is_credit", False):
            body += (
                "\n🧾 বাকিতে কেনার অনুরোধ"
                f"\n💵 নগদ পরিশোধ (ব্যালান্স থেকে): {fmt_money(getattr(req, 'paid_now', 0) or 0)}"
                f"\n❌ বকেয়া থাকবে: {fmt_money(getattr(req, 'credit_due', 0) or 0)}"
            )
        if req.mac_address:
            body += f"\n\U0001f50c MAC: <code>{req.mac_address}</code>"
    else:
        body = (
            f"ধরন: \U0001f4b0 ব্যালান্স ডিপোজিট\n"
            f"পরিমাণ: {fmt_money(req.amount or 0)}\n"
            f"মাধ্যম: {req.method or '-'}"
        )
        if req.transaction_id:
            body += f"\nTxnID: <code>{req.transaction_id}</code>"
        if getattr(req, "sender_number", None):
            body += f"\n\U0001f4f1 প্রেরকের নম্বর: <code>{req.sender_number}</code>"
    return (
        f"\U0001f4e5 <b>নতুন অনুরোধ</b>  (#{to_bn_digits(req.id)})\n"
        f"\U0001f464 {who}  ({uname})\n"
        f"\U0001f194 Telegram ID: <code>{tg_id}</code>\n"
        f"{body}"
    )


def purchase_row(p: PackagePurchase) -> str:
    """একটি প্যাকেজ ক্রয়ের লাইন (কোন প্যাকেজ + কেনার পর ব্যালান্স)।"""
    when = fmt_datetime(p.created_at) if p.created_at else "-"
    mac = f" · MAC {p.mac_address}" if p.mac_address else ""
    return (
        f"• {p.package_name} — {fmt_money(p.price)} "
        f"({to_bn_digits(p.duration_days)} দিন) · {when}{mac}\n"
        f"   \U0001f4b0 কেনার পর ব্যালান্স: {fmt_money(getattr(p, 'balance_after', 0) or 0)}"
    )


def purchase_summary(purchases: list[PackagePurchase]) -> str:
    """প্যাকেজভিত্তিক ক্রয়ের সংখ্যা (গ্রুপ করা) — কাস্টমার প্যানেল।"""
    if not purchases:
        return ""
    counts: dict[str, int] = {}
    for p in purchases:
        counts[p.package_name] = counts.get(p.package_name, 0) + 1
    lines = ["\n\n\U0001f4e6 <b>আপনার কেনা প্যাকেজসমূহ:</b>"]
    for name, count in counts.items():
        lines.append(f"• {name} × {to_bn_digits(count)} টি")
    return "\n".join(lines)
