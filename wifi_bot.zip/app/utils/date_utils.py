"""তারিখ সংক্রান্ত হেল্পার।

- timezone-aware `today()`
- expiry থেকে remaining_days ও status হিসাব
- বাংলা সংখ্যা ফর্ম্যাট
"""

from __future__ import annotations

from datetime import date, datetime, timedelta

import pytz

from app.config import settings

_TZ = pytz.timezone(settings.timezone)

# ইংরেজি → বাংলা অঙ্ক
EN_TO_BN = str.maketrans("0123456789", "\u09e6\u09e7\u09e8\u09e9\u09ea\u09eb\u09ec\u09ed\u09ee\u09ef")


def now() -> datetime:
    """টাইমজোন-অ্যাওয়ার বর্তমান সময়।"""
    return datetime.now(_TZ)


def today() -> date:
    """টাইমজোন-অ্যাওয়ার আজকের তারিখ।"""
    return now().date()


def now_naive() -> datetime:
    """naive লোকাল বর্তমান সময় (DB-র naive expiry_at-এর সাথে তুলনার জন্য)।"""
    return now().replace(tzinfo=None)


def calc_expiry(start: date, duration_days: int) -> date:
    """শুরুর তারিখ + মেয়াদ = এক্সপায়ারি তারিখ।"""
    return start + timedelta(days=duration_days)


def calc_expiry_at(base_at: datetime, duration_days: int) -> datetime:
    """প্যাকেজ চালু/বর্ধনের ভিত্তি সময় + মেয়াদ = নির্ভুল মেয়াদ-শেষের সময়।"""
    return base_at + timedelta(days=duration_days)


def remaining_days(expiry: date, ref: date | None = None) -> int:
    """আজ থেকে expiry পর্যন্ত কতদিন বাকি (নেগেটিভ = মেয়াদ শেষ)।"""
    ref = ref or today()
    return (expiry - ref).days


def compute_status(expiry: date, ref: date | None = None) -> str:
    """expiry থেকে active/expired হিসাব।"""
    from app.database.models import STATUS_ACTIVE, STATUS_EXPIRED

    return STATUS_ACTIVE if remaining_days(expiry, ref) >= 0 else STATUS_EXPIRED


def to_bn_digits(value: object) -> str:
    """ইংরেজি অঙ্ককে বাংলা অঙ্কে রূপান্তর।"""
    return str(value).translate(EN_TO_BN)


def fmt_date(d: date | None) -> str:
    """তারিখ → '09 Jun 2026' (বাংলা অঙ্ক)।"""
    if d is None:
        return "-"
    return to_bn_digits(d.strftime("%d %b %Y"))


def fmt_datetime(dt: datetime | None) -> str:
    """তারিখ ও সময় → '১২ Jun ২০২৬, ০৫:০০ PM' (বাংলা অংক, লোকাল সময়)।"""
    if dt is None:
        return "-"
    if dt.tzinfo is None:
        dt = pytz.utc.localize(dt)
    local = dt.astimezone(_TZ)
    return to_bn_digits(local.strftime("%d %b %Y, %I:%M %p"))


def parse_date(raw: str | None) -> date | None:
    """স্ট্রিং থেকে তারিখ পার্স করে — বিভিন্ন ফর্ম্যাট সাপোর্ট করে।

    সমর্থিত: YYYY-MM-DD, DD-MM-YYYY, DD/MM/YYYY, YYYY/MM/DD।
    পার্স না হলে None ফেরত দেয়।
    """
    if not raw:
        return None
    text = raw.strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def fmt_money(amount: float | int | None) -> str:
    """টাকা → '৳ 1,200' (বাংলা অঙ্ক)।"""
    amount = amount or 0
    formatted = f"{amount:,.0f}"
    return "\u09f3 " + to_bn_digits(formatted)


def remaining_label(expiry: date | None, expiry_at: datetime | None = None) -> str:
    """বাকি 'দিন ঘন্টা' (বাংলা)। শেষ হলে 'মেয়াদ শেষ'।

    expiry_at থাকলে প্যাকেজ চালুর মুহূর্ত ধরে নির্ভুল সময় গণনা হয় (যেমন সদ্য চালু
    ৭ দিনের প্যাকেজ → '৭ দিন ০ ঘন্টা')। নাহলে expiry দিনের শেষ পর্যন্ত গণনা
    (পুরোনো ডেটার জন্য fallback)।
    """
    if expiry_at is not None:
        end = expiry_at if expiry_at.tzinfo else _TZ.localize(expiry_at)
    elif expiry is not None:
        end = _TZ.localize(datetime.combine(expiry + timedelta(days=1), datetime.min.time()))
    else:
        return "-"
    total_seconds = int((end - now()).total_seconds())
    if total_seconds <= 0:
        return "মেয়াদ শেষ"
    days = total_seconds // 86400
    hours = (total_seconds % 86400) // 3600
    return f"{to_bn_digits(days)} দিন {to_bn_digits(hours)} ঘন্টা"
