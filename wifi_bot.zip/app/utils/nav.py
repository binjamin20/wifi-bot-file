"""ইউজার প্যানেলের 'এক-স্ক্রিন' নেভিগেশন হেল্পার।

- একটি ফ্লোতে একটিই বট-মেসেজ ('স্ক্রিন') থাকে; ধাপে ধাপে সেটিই edit হয়,
  ফলে চ্যাটে নতুন মেসেজ জমে না।
- ইউজারের টাইপ-করা ইনপুট মুছে চ্যাট পরিষ্কার রাখা হয়।
"""

from __future__ import annotations

from contextlib import suppress
from typing import Optional

from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

_SCREEN_CHAT = "_screen_chat"
_SCREEN_MSG = "_screen_msg"


async def show_screen(
    event,
    state: FSMContext,
    text: str,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
) -> None:
    """ফ্লোর একমাত্র স্ক্রিন মেসেজটি দেখায়/আপডেট করে (edit-in-place)।

    স্ক্রিন থাকলে সেটিই edit হয়; না থাকলে নতুন একটি পাঠিয়ে মনে রাখা হয়।
    """
    bot = event.bot
    data = await state.get_data()
    chat_id = data.get(_SCREEN_CHAT)
    msg_id = data.get(_SCREEN_MSG)
    if chat_id is not None and msg_id is not None:
        try:
            await bot.edit_message_text(
                text,
                chat_id=chat_id,
                message_id=msg_id,
                reply_markup=reply_markup,
            )
            return
        except TelegramBadRequest as exc:
            # একই কনটেন্ট হলে চুপচাপ থামি; নাহলে নতুন স্ক্রিন পাঠাই
            if "not modified" in str(exc).lower():
                return
    if isinstance(event, CallbackQuery):
        if event.message is None:
            return
        sent = await event.message.answer(text, reply_markup=reply_markup)
    else:
        sent = await event.answer(text, reply_markup=reply_markup)
    await state.update_data(**{_SCREEN_CHAT: sent.chat.id, _SCREEN_MSG: sent.message_id})


async def clear_screen(state: FSMContext) -> None:
    """স্ক্রিন রেফারেন্স মুছে ফেলে (ফ্লো শেষ/বাতিল হলে)।"""
    await state.update_data(**{_SCREEN_CHAT: None, _SCREEN_MSG: None})


async def delete_user_message(message: Message) -> None:
    """ইউজারের টাইপ-করা মেসেজ মুছে চ্যাট পরিষ্কার রাখে (best-effort)।"""
    with suppress(Exception):
        await message.delete()
