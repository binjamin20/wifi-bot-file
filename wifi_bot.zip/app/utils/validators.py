"""ইনপুট ভ্যালিডেশন হেল্পার।

সব ইউজার ইনপুট FSM-এ এখানে ভ্যালিডেট হয় — ভুল থাকলে ValueError থ্রো করে।
"""

from __future__ import annotations

import re

_PHONE_RE = re.compile(r"^\+?\d[\d\s\-]{6,18}$")
_MAC_RE = re.compile(r"^([0-9A-Fa-f]{2})([:-]([0-9A-Fa-f]{2})){5}$")


class ValidationError(ValueError):
    """ভ্যালিডেশন ব্যর্থ হলে।"""


def validate_name(raw: str) -> str:
    name = (raw or "").strip()
    if len(name) < 2:
        raise ValidationError("\u09a8\u09be\u09ae \u0995\u09ae\u09aa\u0995\u09cd\u09b7\u09c7 \u09e8 \u0985\u0995\u09cd\u09b7\u09b0 \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964")
    if len(name) > 120:
        raise ValidationError("\u09a8\u09be\u09ae \u0996\u09c1\u09ac \u09ac\u09a1\u09bc (\u09b8\u09b0\u09cd\u09ac\u09cb\u099a\u09cd\u099a \u09e7\u09e8\u09e6)\u0964")
    return name


def validate_phone(raw: str) -> str:
    phone = (raw or "").strip()
    if not _PHONE_RE.match(phone):
        raise ValidationError("\u09b8\u09a0\u09bf\u0995 \u09ab\u09cb\u09a8 \u09a8\u09ae\u09cd\u09ac\u09b0 \u09a6\u09be\u0993 (\u09af\u09c7\u09ae\u09a8 01712345678)\u0964")
    return phone


def validate_telegram_id(raw: str) -> int | None:
    """খালি / 'skip' দিলে None। নাহলে পূর্ণসংখ্যা।"""
    value = (raw or "").strip().lower()
    if value in ("", "-", "skip", "\u09a8\u09be"):
        return None
    if not value.isdigit():
        raise ValidationError("Telegram ID \u09b6\u09c1\u09a7\u09c1 \u09b8\u0982\u0996\u09cd\u09af\u09be \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7, \u0985\u09a5\u09ac\u09be 'skip' \u09b2\u09c7\u0996\u09cb\u0964")
    return int(value)


def validate_price(raw: str) -> float:
    value = (raw or "").strip().replace(",", "")
    try:
        price = float(value)
    except ValueError as exc:
        raise ValidationError("\u09a6\u09be\u09ae \u098f\u0995\u099f\u09bf \u09b8\u0982\u0996\u09cd\u09af\u09be \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7 (\u09af\u09c7\u09ae\u09a8 500)\u0964") from exc
    if price < 0:
        raise ValidationError("\u09a6\u09be\u09ae \u09a8\u09c7\u0997\u09c7\u099f\u09bf\u09ad \u09b9\u09a4\u09c7 \u09aa\u09be\u09b0\u09ac\u09c7 \u09a8\u09be\u0964")
    return price


def validate_amount(raw: str) -> float:
    value = (raw or "").strip().replace(",", "")
    try:
        amount = float(value)
    except ValueError as exc:
        raise ValidationError("\u099f\u09be\u0995\u09be\u09b0 \u0985\u0999\u09cd\u0995 \u098f\u0995\u099f\u09bf \u09b8\u0982\u0996\u09cd\u09af\u09be \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964") from exc
    if amount <= 0:
        raise ValidationError("\u099f\u09be\u0995\u09be\u09b0 \u0985\u0999\u09cd\u0995 \u09e6 \u098f\u09b0 \u09ac\u09c7\u09b6\u09bf \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964")
    return amount


def validate_duration(raw: str) -> int:
    value = (raw or "").strip()
    if not value.isdigit():
        raise ValidationError("\u09ae\u09c7\u09af\u09bc\u09be\u09a6 \u09a6\u09bf\u09a8 \u09b8\u0982\u0996\u09cd\u09af\u09be\u09af\u09bc \u09a6\u09be\u0993 (\u09af\u09c7\u09ae\u09a8 30)\u0964")
    days = int(value)
    if not 1 <= days <= 3650:
        raise ValidationError("\u09ae\u09c7\u09af\u09bc\u09be\u09a6 \u09e7 \u09a5\u09c7\u0995\u09c7 \u09e9\u09ec\u09eb\u09e6 \u09a6\u09bf\u09a8\u09c7\u09b0 \u09ae\u09a7\u09cd\u09af\u09c7 \u09b9\u09a4\u09c7 \u09b9\u09ac\u09c7\u0964")
    return days


def validate_mac(raw: str) -> str:
    """MAC অ্যাড্রেস যাচাই — AA:BB:CC:DD:EE:FF ফরম্যাট (কোলন বা হাইফেন)।"""
    value = (raw or "").strip().upper()
    if not _MAC_RE.match(value):
        raise ValidationError("সঠিক MAC অ্যাড্রেস দিন (যেমন AA:BB:CC:DD:EE:FF)।")
    return value.replace("-", ":")


_BN_DIGITS = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")


def validate_sender_number(raw: str) -> str:
    """ডিপোজিটে প্রেরকের মোবাইল নম্বর — অবশ্যই ১১ ডিজিট এবং 01 দিয়ে শুরু।

    বাংলা সংখ্যা/স্পেস/হাইফেন থাকলেও চলবে; ভেতরের সংখ্যাগুলোই যাচাই হয়।
    ভুল করে টাকার অঙ্ক (যেমন 100) দিলে গ্রহণ করা হবে না।
    """
    value = (raw or "").strip().translate(_BN_DIGITS)
    digits = "".join(ch for ch in value if ch.isdigit())
    if not re.fullmatch(r"01\d{9}", digits):
        raise ValidationError(
            "সঠিক নম্বর দিন — নম্বরটি অবশ্যই ১১ ডিজিটের হতে হবে এবং 01 দিয়ে শুরু হতে হবে (যেমন 01712345678)।"
        )
    return digits
