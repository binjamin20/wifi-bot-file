"""প্রিমিয়াম UI হেল্পার।

- বাটন রঙ: Telegram Bot API 9.4 ফিচার (aiogram >= 3.25 লাগে)।
  পুরোনো aiogram-এ রঙ এমনিতেই বাদ পড়বে, কিন্তু বট স্বাভাবিকভাবেই চলবে
  (কিছুই ভাঙবে না) — কারণ primary()/success()/danger() তখন খালি dict ফেরত দেয়।
- ডেকোরেটিভ ফরম্যাটিং হেল্পার (হেডার, ডিভাইডার, প্রোগ্রেস বার) — মেসেজ
  প্রিমিয়াম দেখাতে ব্যবহার হয়।
"""

from __future__ import annotations

try:
    from aiogram.enums import ButtonStyle  # aiogram >= 3.25

    _HAS_STYLE = True
except Exception:  # পুরোনো aiogram — রঙ ছাড়াই চলবে
    ButtonStyle = None  # type: ignore[assignment]
    _HAS_STYLE = False


def _style(name: str) -> dict:
    """বাটনের style kwargs ফেরত দেয়; পুরোনো aiogram-এ খালি dict (নিরাপদ)।"""
    if _HAS_STYLE:
        value = getattr(ButtonStyle, name, None)
        if value is not None:
            return {"style": value}
    return {}


def primary() -> dict:
    """🔵 নীল — মূল অ্যাকশন / নেভিগেশন।"""
    return _style("PRIMARY")


def success() -> dict:
    """🟢 সবুজ — পজিটিভ / কনফার্ম / টাকা-ইন।"""
    return _style("SUCCESS")


def danger() -> dict:
    """🔴 লাল — বাতিল / মুছে ফেলা / সতর্কতা।"""
    return _style("DANGER")


# ---- ডেকোরেটিভ ফরম্যাটিং (HTML parse_mode ধরে) ----
RULE = "\u2501" * 18      # ━━━ মোটা লাইন
THIN = "\u2500" * 18      # ─── পাতলা লাইন
DASH = "\u2504" * 16      # ┄┄┄ ড্যাশ লাইন


def header(title: str) -> str:
    """《 শিরোনাম 》 + নিচে রুল লাইন।"""
    return f"<b>\u300a {title} \u300b</b>\n{RULE}"


def section(title: str) -> str:
    """একটি সেকশন হেডার + পাতলা ডিভাইডার।"""
    return f"<b>{title}</b>\n{THIN}"


def progress_bar(used: int, total: int, width: int = 12) -> str:
    """[███████░░░░] স্টাইল প্রোগ্রেস বার।"""
    if total <= 0:
        ratio = 0.0
    else:
        ratio = max(0.0, min(1.0, used / total))
    filled = int(round(ratio * width))
    return "[" + "\u2588" * filled + "\u2591" * (width - filled) + "]"
