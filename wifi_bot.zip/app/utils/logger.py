"""Centralized logging সেটআপ।

Console + ঘূর্ণায়মান ফাইল লগ (logs/bot.log)। সব এরর এখানে ধরা পড়ে।
"""

from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler

from app.config import settings

_LOG_DIR = "logs"
_LOG_FILE = os.path.join(_LOG_DIR, "bot.log")
_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s"


def setup_logging() -> None:
    """অ্যাপ শুরুতে একবার কল করো।"""
    os.makedirs(_LOG_DIR, exist_ok=True)

    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(level)

    # পুরনো হ্যান্ডলার পরিষ্কার (reload-safe)
    for handler in list(root.handlers):
        root.removeHandler(handler)

    formatter = logging.Formatter(_FORMAT)

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(console)

    file_handler = RotatingFileHandler(
        _LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    # খুব verbose লাইব্রেরির লগ কমাও
    logging.getLogger("aiogram.event").setLevel(logging.WARNING)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """মডিউল-ভিত্তিক logger ফেরত দেয়।"""
    return logging.getLogger(name)
