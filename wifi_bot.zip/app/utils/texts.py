"""বটে ব্যবহৃত এডিটযোগ্য টেক্সটের কেন্দ্রীয় ক্যাটালগ (অল টেক্সট এডিট)।

- এডমিন প্যানেল → সিস্টেম → 📝 অল টেক্সট এডিট থেকে এই টেক্সটগুলো এডিট করা যায়।
- প্রতিটি টেক্সটের একটি `default` আছে (বটের আসল লেখা)। override না থাকলে default-ই দেখানো হয়।
- `{name}` ধরনের অংশগুলো ডায়নামিক — রান করার সময় আসল মান বসে। এগুলো হুবহু রাখতে হবে।

নতুন টেক্সট এডিটযোগ্য করতে: এখানে একটি এন্ট্রি যোগ করুন এবং সংশ্লিষ্ট হ্যান্ডলারে
`tx("key", ...)` ব্যবহার করুন।
"""

from __future__ import annotations

# সেকশন তালিকা (ক্রম গুরুত্বপূর্ণ — মেনুতে এই ক্রমে দেখাবে)।
SECTIONS: list[tuple[str, str]] = [
    ("start", "🏠 স্বাগত বার্তা"),
    ("myid", "🆔 আমার আইডি ও নম্বর"),
    ("balance", "💰 ব্যালান্স ও বকেয়া"),
    ("redeem", "🎟 রিডিম কোড"),
    ("contact", "🎧 সাপোর্ট সেন্টার"),
]

# key -> {section, label, default, placeholders}
TEXTS: dict[str, dict] = {
    # ---------------- স্বাগত বার্তা ----------------
    "start.welcome_registered": {
        "section": "start",
        "label": "স্বাগতম (সংযোগ আছে এমন গ্রাহক)",
        "placeholders": ["name"],
        "default": """👋 <b>স্বাগতম, {name}!</b>
আপনার WiFi অ্যাকাউন্ট পরিচালনার জন্য নিচের মেনু ব্যবহার করুন।

📶 সংযোগের অবস্থা, প্যাকেজ, ব্যালান্স ও অন্যান্য তথ্য সহজেই দেখতে পারবেন।
💡 কোনো সমস্যা, অভিযোগ বা সহায়তার প্রয়োজন হলে নিচের "🎧 সাপোর্ট সেন্টার" বাটনে ক্লিক করুন।""",
    },
    "start.welcome_new": {
        "section": "start",
        "label": "স্বাগতম (নতুন/সংযোগ নেই)",
        "placeholders": [],
        "default": """👋 <b>স্বাগতম!</b>
আপনার WiFi অ্যাকাউন্ট পরিচালনার জন্য নিচের মেনু ব্যবহার করুন।

📶 আপনি এখনো কোনো WiFi সংযোগ নেননি — "📦 প্যাকেজ কিনুন" থেকে প্যাকেজ কিনে নিজেই সংযোগ চালু করতে পারেন, "🆔 আমার আইডি" থেকে নিজের তথ্য ও নম্বর দেখতে পারেন।
💡 কোনো সমস্যা, অভিযোগ বা সহায়তার প্রয়োজন হলে নিচের "🎧 সাপোর্ট সেন্টার" বাটনে ক্লিক করুন।""",
    },
    # ---------------- আমার আইডি ----------------
    "myid.card": {
        "section": "myid",
        "label": "আমার আইডি কার্ড",
        "placeholders": ["name", "username", "id", "phone"],
        "default": """🆔 <b>আপনার তথ্য</b>

👤 নাম: {name}
🔖 ইউজারনেম: {username}
🆔 Telegram ID: <code>{id}</code>
📞 নম্বর: {phone}""",
    },
    "myid.set_phone_prompt": {
        "section": "myid",
        "label": "নিজের নম্বর সেট — প্রম্পট",
        "placeholders": [],
        "default": """📱 <b>নিজের নম্বর সেট করুন</b>

আপনার মোবাইল নম্বরটি লিখুন (১১ ডিজিট, 01 দিয়ে শুরু — যেমন 01712345678):
<i>('বাতিল' লিখে বন্ধ করতে পারেন)</i>""",
    },
    "myid.set_phone_done": {
        "section": "myid",
        "label": "নিজের নম্বর সেট — সফল",
        "placeholders": ["phone"],
        "default": """✅ আপনার নম্বর সেট হয়েছে।
📞 নম্বর: <code>{phone}</code>""",
    },
    # ---------------- ব্যালান্স ----------------
    "balance.show": {
        "section": "balance",
        "label": "ব্যালান্স দেখানো",
        "placeholders": ["balance"],
        "default": "💰 <b>আপনার ব্যালান্স:</b> {balance}",
    },
    "balance.due_extra": {
        "section": "balance",
        "label": "ব্যালান্সের সাথে বকেয়া লাইন",
        "placeholders": ["due"],
        "default": "\n❌ বকেয়া: {due}",
    },
    "balance.duepay_info": {
        "section": "balance",
        "label": "বকেয়া পরিশোধ তথ্য",
        "placeholders": ["due"],
        "default": """💳 <b>বকেয়া পরিশোধ</b>

আপনার বর্তমান বকেয়া: {due}

পরিশোধ করতে মেনু থেকে টাকা জমা করুন।
টাকা জমা হওয়ার সাথে সাথে আপনার বকেয়া স্বয়ংক্রিয়ভাবে কেটে নেওয়া হবে।""",
    },
    # ---------------- রিডিম কোড ----------------
    "redeem.prompt": {
        "section": "redeem",
        "label": "রিডিম কোড — প্রম্পট",
        "placeholders": [],
        "default": """🎟 <b>রিডিম কোড</b>

আপনার কাছে থাকা কোডটি লিখে পাঠান:
<i>('বাতিল' লিখে বন্ধ করতে পারেন)</i>""",
    },
    "redeem.success": {
        "section": "redeem",
        "label": "রিডিম সফল",
        "placeholders": ["amount", "due_line", "balance"],
        "default": """✅ কোড সফলভাবে রিডিম হয়েছে!
💰 যোগ হয়েছে: {amount}{due_line}
💼 নতুন ব্যালান্স: {balance}""",
    },
    # ---------------- সাপোর্ট ----------------
    "contact.center": {
        "section": "contact",
        "label": "সাপোর্ট সেন্টার",
        "placeholders": ["contact", "support_link"],
        "default": """🎧 <b>সাপোর্ট সেন্টার</b>

📞 ফোন: <code>{contact}</code>

🕐 সাপোর্ট সময়:
সকাল ৯টা - রাত ১০টা

💬 Telegram:
{support_link}""",
    },
}


def section_label(section_key: str) -> str:
    for key, label in SECTIONS:
        if key == section_key:
            return label
    return section_key


def keys_in_section(section_key: str) -> list[str]:
    return [k for k, m in TEXTS.items() if m.get("section") == section_key]
