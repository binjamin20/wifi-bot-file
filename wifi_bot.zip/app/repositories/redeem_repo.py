"""RedeemCode / RedeemUse রিপোজিটরি।"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import RedeemCode, RedeemUse


class RedeemRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, code: RedeemCode) -> RedeemCode:
        self.session.add(code)
        await self.session.flush()
        return code

    async def get(self, code_id: int) -> RedeemCode | None:
        return await self.session.get(RedeemCode, code_id)

    async def get_by_code(self, code: str) -> RedeemCode | None:
        result = await self.session.execute(
            select(RedeemCode).where(RedeemCode.code == code)
        )
        return result.scalar_one_or_none()

    async def list_all(self) -> list[RedeemCode]:
        result = await self.session.execute(
            select(RedeemCode).order_by(RedeemCode.created_at.desc())
        )
        return list(result.scalars().all())

    async def used_by_telegram(self, code_id: int, telegram_id: int) -> RedeemUse | None:
        result = await self.session.execute(
            select(RedeemUse).where(
                RedeemUse.code_id == code_id,
                RedeemUse.telegram_id == telegram_id,
            )
        )
        return result.scalar_one_or_none()

    async def add_use(self, use: RedeemUse) -> RedeemUse:
        self.session.add(use)
        await self.session.flush()
        return use
