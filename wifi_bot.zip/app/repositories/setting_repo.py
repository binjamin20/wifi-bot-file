"""AppSetting রিপোজিটরি — key-value সেটিংস।"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import AppSetting


class SettingRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get(self, key: str) -> AppSetting | None:
        return await self.session.get(AppSetting, key)

    async def get_value(self, key: str) -> str | None:
        setting = await self.session.get(AppSetting, key)
        return setting.value if setting is not None else None

    async def all(self) -> list[AppSetting]:
        result = await self.session.execute(select(AppSetting))
        return list(result.scalars().all())

    async def set(self, key: str, value: str | None) -> AppSetting:
        setting = await self.session.get(AppSetting, key)
        if setting is None:
            setting = AppSetting(key=key, value=value)
            self.session.add(setting)
        else:
            setting.value = value
        await self.session.flush()
        return setting
