"""PaymentRequest রিপোজিটরি — ডিপোজিট/প্যাকেজ অনুরোধের query।"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import REQUEST_PENDING, PaymentRequest


class RequestRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, request: PaymentRequest) -> PaymentRequest:
        self.session.add(request)
        await self.session.flush()
        return request

    async def get(self, request_id: int) -> PaymentRequest | None:
        return await self.session.get(PaymentRequest, request_id)

    async def list_pending(self) -> list[PaymentRequest]:
        result = await self.session.execute(
            select(PaymentRequest)
            .where(PaymentRequest.status == REQUEST_PENDING)
            .order_by(PaymentRequest.created_at)
        )
        return list(result.scalars().all())
