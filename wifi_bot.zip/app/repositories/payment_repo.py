"""Payment রিপোজিটরি — পেমেন্ট টেবিলের query।"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import Payment


class PaymentRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, payment: Payment) -> Payment:
        self.session.add(payment)
        await self.session.flush()
        return payment

    async def list_for_customer(self, customer_id: int) -> list[Payment]:
        result = await self.session.execute(
            select(Payment)
            .where(Payment.customer_id == customer_id)
            .order_by(Payment.created_at.desc())
        )
        return list(result.scalars().all())

    async def list_all(self, limit: int = 100, offset: int = 0) -> list[Payment]:
        result = await self.session.execute(
            select(Payment).order_by(Payment.created_at.desc()).limit(limit).offset(offset)
        )
        return list(result.scalars().all())

    async def sum_between(self, start: datetime, end: datetime) -> float:
        """start <= created_at < end এর মধ্যে মোট কালেকশন।"""
        result = await self.session.execute(
            select(func.coalesce(func.sum(Payment.amount), 0.0)).where(
                Payment.created_at >= start,
                Payment.created_at < end,
                Payment.counts_as_income.is_(True),
            )
        )
        return float(result.scalar() or 0.0)

    async def count_between(self, start: datetime, end: datetime) -> int:
        result = await self.session.execute(
            select(func.count(Payment.id)).where(
                Payment.created_at >= start, Payment.created_at < end
            )
        )
        return int(result.scalar() or 0)
