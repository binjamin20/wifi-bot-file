"""ডেটা অ্যাক্সেস লেয়ার (Repository pattern)।

প্রতিটি রিপো একটি AsyncSession নেয় এবং শুধু DB query করে —
কোনো বিজনেস লজিক এখানে নেই (সেটা services-এ)।
"""
