"""Package রিপোজিটরি — প্যাকেজ টেবিলের query।"""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import Package


class PackageRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, package: Package) -> Package:
        self.session.add(package)
        await self.session.flush()
        return package

    async def get(self, package_id: int) -> Package | None:
        return await self.session.get(Package, package_id)

    async def list_active(self) -> list[Package]:
        result = await self.session.execute(
            select(Package)
            .where(Package.is_active.is_(True))
            .order_by(Package.duration_days)
        )
        return list(result.scalars().all())

    async def list_all(self) -> list[Package]:
        result = await self.session.execute(
            select(Package).order_by(Package.duration_days)
        )
        return list(result.scalars().all())

    async def delete(self, package: Package) -> None:
        await self.session.delete(package)

    async def count(self) -> int:
        result = await self.session.execute(select(func.count(Package.id)))
        return int(result.scalar() or 0)
