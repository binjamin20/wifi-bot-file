"""Customer রিপোজিটরি — গ্রাহক টেবিলের সকল query।"""

from __future__ import annotations

from datetime import date

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import STATUS_ACTIVE, STATUS_EXPIRED, Customer


class CustomerRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, customer: Customer) -> Customer:
        self.session.add(customer)
        await self.session.flush()
        return customer

    async def get(self, customer_id: int) -> Customer | None:
        return await self.session.get(Customer, customer_id)

    async def get_by_telegram_id(self, telegram_id: int) -> Customer | None:
        result = await self.session.execute(
            select(Customer).where(Customer.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def list_all(
        self, limit: int | None = None, offset: int = 0
    ) -> list[Customer]:
        stmt = select(Customer).order_by(Customer.name)
        if limit is not None:
            stmt = stmt.limit(limit).offset(offset)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def search(self, term: str) -> list[Customer]:
        """নাম / ফোন / Telegram ID / Customer ID দিয়ে খোঁজ।"""
        like = f"%{term}%"
        conditions = [
            Customer.name.ilike(like),
            Customer.phone.ilike(like),
        ]
        if term.isdigit():
            conditions.append(Customer.id == int(term))
            conditions.append(Customer.telegram_id == int(term))
        result = await self.session.execute(
            select(Customer).where(or_(*conditions)).order_by(Customer.name)
        )
        return list(result.scalars().all())

    async def delete(self, customer: Customer) -> None:
        await self.session.delete(customer)

    async def count(self) -> int:
        result = await self.session.execute(select(func.count(Customer.id)))
        return int(result.scalar() or 0)

    async def count_by_status(self, status: str) -> int:
        result = await self.session.execute(
            select(func.count(Customer.id)).where(Customer.status == status)
        )
        return int(result.scalar() or 0)

    async def total_due(self) -> float:
        result = await self.session.execute(select(func.coalesce(func.sum(Customer.due_amount), 0.0)))
        return float(result.scalar() or 0.0)

    async def expiring_between(self, start: date, end: date) -> list[Customer]:
        """start <= expiry_date <= end (inclusive)।"""
        result = await self.session.execute(
            select(Customer)
            .where(Customer.expiry_date >= start, Customer.expiry_date <= end)
            .order_by(Customer.expiry_date)
        )
        return list(result.scalars().all())

    async def expired(self, ref: date) -> list[Customer]:
        result = await self.session.execute(
            select(Customer).where(Customer.expiry_date < ref).order_by(Customer.expiry_date)
        )
        return list(result.scalars().all())

    async def with_due(self) -> list[Customer]:
        result = await self.session.execute(
            select(Customer).where(Customer.due_amount > 0).order_by(Customer.due_amount.desc())
        )
        return list(result.scalars().all())

    async def with_telegram(self) -> list[Customer]:
        """যাদের telegram_id আছে (broadcast / reminder এর জন্য)।"""
        result = await self.session.execute(
            select(Customer).where(Customer.telegram_id.is_not(None))
        )
        return list(result.scalars().all())
