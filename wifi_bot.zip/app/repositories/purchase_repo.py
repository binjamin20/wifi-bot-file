"""PackagePurchase রিপোজিটরি — ক্রয় ইতিহাস।"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import PackagePurchase


class PurchaseRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, purchase: PackagePurchase) -> PackagePurchase:
        self.session.add(purchase)
        await self.session.flush()
        return purchase

    async def list_for_customer(self, customer_id: int) -> list[PackagePurchase]:
        result = await self.session.execute(
            select(PackagePurchase)
            .where(PackagePurchase.customer_id == customer_id)
            .order_by(PackagePurchase.created_at.desc())
        )
        return list(result.scalars().all())
