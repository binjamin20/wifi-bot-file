"""RenewalHistory রিপোজিটরি।"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import RenewalHistory


class RenewalRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, renewal: RenewalHistory) -> RenewalHistory:
        self.session.add(renewal)
        await self.session.flush()
        return renewal

    async def list_for_customer(self, customer_id: int) -> list[RenewalHistory]:
        result = await self.session.execute(
            select(RenewalHistory)
            .where(RenewalHistory.customer_id == customer_id)
            .order_by(RenewalHistory.created_at.desc())
        )
        return list(result.scalars().all())

    async def count_between(self, start: datetime, end: datetime) -> int:
        result = await self.session.execute(
            select(func.count(RenewalHistory.id)).where(
                RenewalHistory.created_at >= start, RenewalHistory.created_at < end
            )
        )
        return int(result.scalar() or 0)
