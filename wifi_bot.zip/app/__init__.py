"""WiFi Subscription Management Telegram Bot.

Clean Architecture প্যাকেজ:
    config      -> কনফিগারেশন/সেটিংস
    database    -> ORM মডেল ও সেশন
    repositories-> ডেটা অ্যাক্সেস লেয়ার
    services    -> বিজনেস লজিক লেয়ার
    handlers    -> Telegram (presentation) লেয়ার
    keyboards   -> UI কীবোর্ড
    middlewares -> Auth ও Throttling
    scheduler   -> APScheduler জব
    utils       -> হেল্পার ইউটিলিটি
"""

__version__ = "1.0.0"
