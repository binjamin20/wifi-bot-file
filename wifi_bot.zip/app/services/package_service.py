"""Package সার্ভিস — এডমিনের প্যাকেজ ব্যবস্থাপনার লজিক।

ডিফল্ট প্যাকেজ (৭/১৫/৩০ দিন) প্রথমবার সিড হয়; এরপর এডমিন যোগ/এডিট/মুছতে পারে।
"""

from __future__ import annotations

from app.database.base import db
from app.database.models import Package
from app.repositories.package_repo import PackageRepository
from app.utils.logger import get_logger

log = get_logger(__name__)

# প্রথমবার সিড হওয়া ডিফল্ট প্যাকেজ (নাম, দিন, দাম) — দাম এডিটযোগ্য।
_DEFAULTS = [
    ("৭ দিনের প্যাকেজ", 7, 150.0),
    ("১৫ দিনের প্যাকেজ", 15, 300.0),
    ("৩০ দিনের প্যাকেজ", 30, 500.0),
]


class PackageService:
    async def ensure_defaults(self) -> None:
        """একটিও প্যাকেজ না থাকলে ডিফল্টগুলো যোগ করে।"""
        async with db.session() as session:
            repo = PackageRepository(session)
            if await repo.count() > 0:
                return
            for name, days, price in _DEFAULTS:
                session.add(Package(name=name, duration_days=days, price=price))
            await session.commit()
            log.info("Default packages seeded.")

    async def list_active(self) -> list[Package]:
        async with db.session() as session:
            return await PackageRepository(session).list_active()

    async def list_all(self) -> list[Package]:
        async with db.session() as session:
            return await PackageRepository(session).list_all()

    async def get(self, package_id: int) -> Package | None:
        async with db.session() as session:
            return await PackageRepository(session).get(package_id)

    async def create(self, name: str, duration_days: int, price: float) -> Package:
        async with db.session() as session:
            repo = PackageRepository(session)
            package = Package(name=name, duration_days=duration_days, price=price)
            await repo.add(package)
            await session.commit()
            await session.refresh(package)
            log.info("Package created id=%s name=%s", package.id, package.name)
            return package

    async def update_fields(self, package_id: int, **fields: object) -> Package | None:
        editable = {"name", "duration_days", "price", "is_active"}
        async with db.session() as session:
            repo = PackageRepository(session)
            package = await repo.get(package_id)
            if package is None:
                return None
            for key, value in fields.items():
                if key in editable:
                    setattr(package, key, value)
            await session.commit()
            await session.refresh(package)
            return package

    async def toggle_active(self, package_id: int) -> Package | None:
        async with db.session() as session:
            repo = PackageRepository(session)
            package = await repo.get(package_id)
            if package is None:
                return None
            package.is_active = not bool(package.is_active)
            await session.commit()
            await session.refresh(package)
            return package

    async def delete(self, package_id: int) -> bool:
        async with db.session() as session:
            repo = PackageRepository(session)
            package = await repo.get(package_id)
            if package is None:
                return False
            await repo.delete(package)
            await session.commit()
            log.info("Package deleted id=%s", package_id)
            return True


package_service = PackageService()
