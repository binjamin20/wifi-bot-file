"""Payment সার্ভিস — পেমেন্ট যোগ ও due/paid হিসাব।

পেমেন্ট যোগ করলে গ্রাহকের paid_amount বাড়ে ও due_amount কমে —
এই হিসাব সার্ভারে হয় (frontend ঠিক করে না)।
"""

from __future__ import annotations

from app.database.base import db
from app.database.models import Payment
from app.repositories.customer_repo import CustomerRepository
from app.repositories.payment_repo import PaymentRepository
from app.utils.logger import get_logger

log = get_logger(__name__)


class PaymentService:
    async def add_payment(
        self,
        customer_id: int,
        amount: float,
        method: str,
        transaction_id: str | None = None,
        note: str | None = None,
    ) -> Payment | None:
        async with db.session() as session:
            customer_repo = CustomerRepository(session)
            payment_repo = PaymentRepository(session)
            customer = await customer_repo.get(customer_id)
            if customer is None:
                return None
            payment = Payment(
                customer_id=customer_id,
                amount=amount,
                payment_method=method,
                transaction_id=transaction_id,
                note=note,
            )
            await payment_repo.add(payment)
            # টাকার হিসাব আপডেট (সার্ভার-সাইড)
            customer.paid_amount = (customer.paid_amount or 0) + amount
            customer.due_amount = max(0.0, (customer.due_amount or 0) - amount)
            await session.commit()
            await session.refresh(payment)
            log.info("Payment added customer=%s amount=%s", customer_id, amount)
            return payment

    async def history(self, customer_id: int) -> list[Payment]:
        async with db.session() as session:
            return await PaymentRepository(session).list_for_customer(customer_id)


payment_service = PaymentService()
