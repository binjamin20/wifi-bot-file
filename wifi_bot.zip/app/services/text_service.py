"""টেক্সট সার্ভিস — কেবল ইউজার/গ্রাহক প্যানেলের টেক্সট এডিটযোগ্য করে।

দুই উৎস একসাথে (উভয়ই গ্রাহক-মুখী):
1. `app/utils/texts.py` (TEXTS)        — হাতে-কিউরেট, হ্যান্ডলারে `tx()` দিয়ে বসানো।
2. `app/utils/text_catalog.py` (CATALOG) — panel.py থেকে অটো-সংগৃহীত লিটারাল টেক্সট।

দুই উৎসই একই স্ক্রিন-সেকশন (slug) এ মিলিয়ে দেখানো হয়, যেন owner বুঝতে পারে
কোন টেক্সট গ্রাহক প্যানেলের কোন জায়গার।

override গুলো AppSetting টেবিলে `text:<key>` কী হিসেবে জমা হয়।
- curated key (tx) → `tx()` সামলায়।
- auto key → `TextOverrideMiddleware` পাঠানোর মুহূর্তে বসায় (owner এডিট না করলে কিছুই বদলায় না)।
"""

from __future__ import annotations

import re

from app.database.base import db
from app.repositories.setting_repo import SettingRepository
from app.services.settings_service import settings_service
from app.utils import text_catalog as cat
from app.utils.logger import get_logger
from app.utils.texts import TEXTS

log = get_logger(__name__)

_PREFIX = "text:"
_PH_RE = re.compile(r"\{(\d+)\}")


def _compile_template(default: str) -> re.Pattern:
    """`{1}`-style প্লেসহোল্ডারওয়ালা ডিফল্টকে fullmatch regex বানায়।"""
    parts = _PH_RE.split(default)
    chunks = []
    for i, p in enumerate(parts):
        chunks.append(re.escape(p) if i % 2 == 0 else "(?P<g%s>.+?)" % p)
    return re.compile("^" + "".join(chunks) + "$", re.DOTALL)


def _render(template: str, groups: dict[str, str]) -> str:
    return _PH_RE.sub(lambda m: groups.get("g" + m.group(1), m.group(0)), template)


class TextService:
    def __init__(self) -> None:
        self._overrides: dict[str, str] = {}
        self._loaded = False
        # unified index: key -> {slug, kind, default, label, ph, where, is_auto}
        self._idx: dict[str, dict] = {}
        self._sections: list[tuple[str, str]] = []
        self._sec_keys: dict[str, list[str]] = {}
        # middleware runtime maps (auto only)
        self._static_over: dict[str, str] = {}
        self._templates: list[tuple[re.Pattern, str, int]] = []
        self._override_values: set[str] = set()
        self._build_index()

    # ---------- index ----------
    def _build_index(self) -> None:
        idx: dict[str, dict] = {}
        sec_keys: dict[str, list[str]] = {slug: [] for slug in cat.SECTION_ORDER}

        # curated (texts.py) — slug আসে CURATED_SLUGS থেকে
        for key, meta in TEXTS.items():
            slug = cat.CURATED_SLUGS.get(key, "other")
            idx[key] = {
                "slug": slug,
                "kind": "curated",
                "default": meta["default"],
                "label": meta.get("label") or _shorten(meta["default"]),
                "ph": list(meta.get("placeholders") or []),
                "where": [cat.SECTION_LABELS.get(slug, slug)],
                "is_auto": False,
            }
            sec_keys.setdefault(slug, []).append(key)

        # auto (text_catalog.py)
        for slug in cat.SECTION_ORDER:
            for key in cat.SECTION_KEYS.get(slug, []):
                e = cat.CATALOG[key]
                idx[key] = {
                    "slug": slug,
                    "kind": e["k"],  # static | template
                    "default": e["d"],
                    "label": e["l"],
                    "ph": [str(i) for i in range(1, e["p"] + 1)],
                    "where": list(e.get("w") or [cat.SECTION_LABELS.get(slug, slug)]),
                    "is_auto": True,
                }
                sec_keys.setdefault(slug, []).append(key)

        self._idx = idx
        self._sec_keys = {s: ks for s, ks in sec_keys.items() if ks}
        self._sections = [
            (slug, cat.SECTION_LABELS.get(slug, slug))
            for slug in cat.SECTION_ORDER
            if self._sec_keys.get(slug)
        ]

    # ---------- load ----------
    async def preload(self) -> None:
        try:
            async with db.session() as session:
                rows = await SettingRepository(session).all()
            overrides: dict[str, str] = {}
            for s in rows:
                if s.key and s.key.startswith(_PREFIX) and s.value:
                    overrides[s.key[len(_PREFIX):]] = s.value
            self._overrides = overrides
            self._loaded = True
            self._rebuild_runtime()
            log.info("Text overrides loaded: %d", len(overrides))
        except Exception as exc:
            log.warning("Text preload failed: %s", exc)

    def _rebuild_runtime(self) -> None:
        """override থেকে মিডলওয়্যারের ম্যাচ ম্যাপ (শুধু auto entry)।"""
        static_over: dict[str, str] = {}
        templates: list[tuple[re.Pattern, str, int]] = []
        values: set[str] = set()
        for key, override in self._overrides.items():
            entry = cat.CATALOG.get(key)
            if not entry:
                continue  # curated অথবা অপরিচিত key → মিডলওয়্যার নয়
            default = entry["d"]
            if not override or override == default:
                continue
            values.add(override)
            if entry["k"] == "template":
                try:
                    rx = _compile_template(default)
                except re.error:
                    continue
                templates.append((rx, override, len(_PH_RE.sub("", default))))
            else:
                static_over[default] = override
        templates.sort(key=lambda t: -t[2])
        self._static_over = static_over
        self._templates = templates
        self._override_values = values

    # ---------- middleware ----------
    def has_overrides(self) -> bool:
        return bool(self._static_over or self._templates)

    def apply(self, text: str) -> str:
        if not text or not self.has_overrides():
            return text
        ov = self._static_over.get(text)
        if ov is not None:
            return ov
        if text in self._override_values:
            return text
        for rx, override, _ in self._templates:
            m = rx.match(text)
            if m:
                return _render(override, m.groupdict())
        return text

    # ---------- curated tx() ----------
    def get(self, key: str, **kwargs) -> str:
        entry = self._idx.get(key)
        default = entry["default"] if entry else ""
        template = self._overrides.get(key, default)
        if kwargs:
            for name, value in kwargs.items():
                template = template.replace("{" + name + "}", str(value))
        return template

    def get_raw(self, key: str) -> str:
        entry = self._idx.get(key)
        default = entry["default"] if entry else ""
        value = self._overrides.get(key)
        return value if value is not None else default

    def is_overridden(self, key: str) -> bool:
        return bool(self._overrides.get(key))

    async def set(self, key: str, value: str) -> None:
        await settings_service.set(_PREFIX + key, value)
        self._overrides[key] = value
        self._rebuild_runtime()

    async def reset(self, key: str) -> None:
        await settings_service.set(_PREFIX + key, None)
        self._overrides.pop(key, None)
        self._rebuild_runtime()

    # ---------- UI helpers ----------
    def list_sections(self) -> list[tuple[str, str, int]]:
        return [(slug, label, len(self._sec_keys.get(slug, []))) for slug, label in self._sections]

    def section_label(self, slug: str) -> str:
        return cat.SECTION_LABELS.get(slug, slug)

    def list_keys(self, slug: str) -> list[str]:
        return list(self._sec_keys.get(slug, []))

    def has_key(self, key: str) -> bool:
        return key in self._idx

    def label_of(self, key: str) -> str:
        e = self._idx.get(key)
        return e["label"] if e else key

    def slug_of(self, key: str) -> str:
        e = self._idx.get(key)
        return e["slug"] if e else ""

    def where_of(self, key: str) -> list[str]:
        e = self._idx.get(key)
        return list(e["where"]) if e else []

    def placeholders_of(self, key: str) -> list[str]:
        e = self._idx.get(key)
        return list(e["ph"]) if e else []

    def is_template(self, key: str) -> bool:
        e = self._idx.get(key)
        return bool(e and e["ph"])


def _shorten(text: str, limit: int = 40) -> str:
    one = " ".join(text.split())
    return one if len(one) <= limit else one[: limit - 1] + "\u2026"


text_service = TextService()


def tx(key: str, **kwargs) -> str:
    """হ্যান্ডলারে সংক্ষিপ্ত ব্যবহার: tx(\"key\", name=...)।"""
    return text_service.get(key, **kwargs)
