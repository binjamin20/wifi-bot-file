"""Customer সার্ভিস — গ্রাহক সংক্রান্ত সব বিজনেস লজিক।

start_date / expiry_date / remaining_days / balance — এগুলো সবসময় সার্ভারে হিসাব
করা হয়, ভিজিটরের ইনপুটের উপর নেই (security)।
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from app.database.base import db
from app.database.models import PackagePurchase, Payment, RenewalHistory, Customer
from app.repositories.customer_repo import CustomerRepository
from app.repositories.purchase_repo import PurchaseRepository
from app.repositories.renewal_repo import RenewalRepository
from app.utils import date_utils
from app.utils.logger import get_logger

log = get_logger(__name__)


class DuplicateCustomerError(Exception):
    """একই Telegram ID দিয়ে দ্বিতীয়বার গ্রাহক যোগ করতে গেলে।"""

    def __init__(self, existing: Customer) -> None:
        super().__init__("Duplicate customer")
        self.existing = existing


class InsufficientBalanceError(Exception):
    """প্যাকেজ কিনতে পর্যাপ্ত ব্যালান্স নেই।"""


def settle_due_from_balance(session, customer) -> float:
    """ব্যালান্সে টাকা থাকলে আগের বকেয়া স্বয়ংক্রিয়ভাবে কেটে নেয়।

    টাকা যেভাবেই (ডিপোজিট/রিডিম/এডমিন টপ-আপ) ব্যালান্সে যোগ হোক না কেন, বকেয়া
    থাকলে সাথে সাথেই তা কেটে নেওয়া হয়। কাটা পরিমাণ ফেরত দেয়।
    """
    due = float(customer.due_amount or 0.0)
    balance = float(customer.balance or 0.0)
    if due <= 0 or balance <= 0:
        return 0.0
    settle = min(due, balance)
    customer.balance = balance - settle
    customer.due_amount = due - settle
    customer.paid_amount = float(customer.paid_amount or 0.0) + settle
    session.add(
        Payment(
            customer_id=customer.id,
            amount=settle,
            payment_method="Due",
            counts_as_income=True,  # বকেয়া পরিশোধ = প্রকৃত আয় (আদায়ে গণনা হবে)
            note="বকেয়া পরিশোধ (ব্যালান্স থেকে স্বয়ংক্রিয়)",
        )
    )
    return settle


@dataclass(slots=True)
class NewCustomerData:
    """Add Customer FSM থেকে সংগৃহীত ডাটা।"""

    name: str
    phone: str
    telegram_id: int | None
    package_name: str
    package_price: float
    duration: int
    notes: str | None
    paid_amount: float = 0.0  # গ্রাহক এখন কত টাকা পরিশোধ করলেন


class CustomerService:
    """সব মেথড নিজেই session ম্যানেজ করে (atomic)।"""

    async def create(self, data: NewCustomerData) -> Customer:
        start = date_utils.today()
        expiry = date_utils.calc_expiry(start, data.duration)
        expiry_at = date_utils.calc_expiry_at(date_utils.now_naive(), data.duration)
        paid = max(0.0, float(data.paid_amount or 0.0))
        due = max(0.0, float(data.package_price) - paid)
        async with db.session() as session:
            repo = CustomerRepository(session)
            # ডুপ্লিকেট গার্ড — একই Telegram ID থাকলে আটকানোর বদলে স্পষ্ট এরর।
            if data.telegram_id is not None:
                existing = await repo.get_by_telegram_id(data.telegram_id)
                if existing is not None:
                    raise DuplicateCustomerError(existing)
            customer = Customer(
                name=data.name,
                phone=data.phone,
                telegram_id=data.telegram_id,
                package_name=data.package_name,
                package_price=data.package_price,
                start_date=start,
                expiry_date=expiry,
                expiry_at=expiry_at,
                remaining_days=date_utils.remaining_days(expiry, start),
                status=date_utils.compute_status(expiry, start),
                paid_amount=paid,
                due_amount=due,
                notes=data.notes,
            )
            await repo.add(customer)
            # শুরুতেই টাকা দিলে একটি পেমেন্ট রেকর্ডও রাখি।
            if paid > 0:
                session.add(
                    Payment(
                        customer_id=customer.id,
                        amount=paid,
                        payment_method="Cash",
                        note="প্রাথমিক পরিশোধ",
                    )
                )
            await session.commit()
            await session.refresh(customer)
            log.info("Customer created id=%s name=%s", customer.id, customer.name)
            return customer

    async def update_fields(self, customer_id: int, **fields: object) -> Customer | None:
        """এক বা একাধিক এডিটেবল ফিল্ড আপডেট।"""
        editable = {"name", "phone", "package_name", "package_price", "notes", "mac_address", "telegram_id"}
        async with db.session() as session:
            repo = CustomerRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return None
            for key, value in fields.items():
                if key in editable:
                    setattr(customer, key, value)
            await session.commit()
            await session.refresh(customer)
            return customer

    async def touch_telegram_profile(
        self, telegram_id: int, username: str | None, name: str | None
    ) -> Customer | None:
        """গ্রাহক প্যানেল ব্যবহার করলে তার username/নাম হালনাগাদ করে।"""
        async with db.session() as session:
            repo = CustomerRepository(session)
            customer = await repo.get_by_telegram_id(telegram_id)
            if customer is None:
                return None
            changed = False
            if username and customer.telegram_username != username:
                customer.telegram_username = username
                changed = True
            if name and customer.telegram_name != name:
                customer.telegram_name = name
                changed = True
            if changed:
                await session.commit()
                await session.refresh(customer)
            return customer

    async def get_or_create_account(
        self, telegram_id: int, name: str | None, username: str | None
    ) -> Customer:
        """গ্রাহকের অ্যাকাউন্ট আছে কিনা দেখে, না থাকলে একটি খালি (সাবস্ক্রিপশনহীন)
        অ্যাকাউন্ট খোলে — যেন গ্রাহক নিজে ডিপোজিট/প্যাকেজ কিনতে পারে।"""
        async with db.session() as session:
            repo = CustomerRepository(session)
            existing = await repo.get_by_telegram_id(telegram_id)
            if existing is not None:
                changed = False
                if username and existing.telegram_username != username:
                    existing.telegram_username = username
                    changed = True
                if name and existing.telegram_name != name:
                    existing.telegram_name = name
                    changed = True
                if changed:
                    await session.commit()
                    await session.refresh(existing)
                return existing
            today = date_utils.today()
            # সাবস্ক্রিপশন নেই বোঝাতে expiry গতকাল (মেয়াদোত্তীর্ণ)।
            expired_day = today - timedelta(days=1)
            customer = Customer(
                name=name or "গ্রাহক",
                phone="",
                telegram_id=telegram_id,
                telegram_username=username,
                telegram_name=name,
                package_name="—",
                package_price=0.0,
                start_date=today,
                expiry_date=expired_day,
                remaining_days=date_utils.remaining_days(expired_day, today),
                status=date_utils.compute_status(expired_day, today),
                paid_amount=0.0,
                due_amount=0.0,
                balance=0.0,
            )
            await repo.add(customer)
            await session.commit()
            await session.refresh(customer)
            log.info("Auto account created tg=%s id=%s", telegram_id, customer.id)
            return customer

    async def credit_balance(
        self,
        customer_id: int,
        amount: float,
        method: str = "Cash",
        transaction_id: str | None = None,
        note: str | None = None,
    ) -> Customer | None:
        """গ্রাহকের ব্যালান্সে টাকা জমা করে ও একটি পেমেন্ট রেকর্ড রাখে।"""
        async with db.session() as session:
            repo = CustomerRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return None
            customer.balance = float(customer.balance or 0.0) + float(amount)
            session.add(
                Payment(
                    customer_id=customer.id,
                    amount=float(amount),
                    payment_method=method,
                    counts_as_income=False,  # ম্যানুয়াল ব্যালান্স টপ-আপ — আয় নয়
                    transaction_id=transaction_id,
                    note=note or "ব্যালান্স ডিপোজিট",
                )
            )
            settled = settle_due_from_balance(session, customer)
            await session.commit()
            await session.refresh(customer)
            customer.last_settled = settled
            log.info("Balance credited id=%s +%s", customer_id, amount)
            return customer

    async def activate_package(
        self, customer_id: int, package_name: str, price: float, duration: int
    ) -> Customer | None:
        """ব্যালান্স থেকে দাম কেটে নিয়ে প্যাকেজ এক্টিভ/রিনিউ করে।

        পর্যাপ্ত ব্যালান্স না থাকলে InsufficientBalanceError।
        """
        async with db.session() as session:
            repo = CustomerRepository(session)
            renewal_repo = RenewalRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return None
            if float(customer.balance or 0.0) < float(price):
                raise InsufficientBalanceError()
            today = date_utils.today()
            now_local = date_utils.now_naive()
            base: date = customer.expiry_date if customer.expiry_date >= today else today
            base_at = (
                customer.expiry_at
                if customer.expiry_at and customer.expiry_at > now_local
                else now_local
            )
            old_expiry = customer.expiry_date
            new_expiry = date_utils.calc_expiry(base, duration)
            new_expiry_at = date_utils.calc_expiry_at(base_at, duration)
            customer.balance = float(customer.balance or 0.0) - float(price)
            customer.expiry_date = new_expiry
            customer.expiry_at = new_expiry_at
            customer.remaining_days = date_utils.remaining_days(new_expiry)
            customer.status = date_utils.compute_status(new_expiry)
            customer.package_name = package_name
            customer.package_price = float(price)
            customer.paid_amount = float(customer.paid_amount or 0.0) + float(price)
            customer.due_amount = 0.0
            await renewal_repo.add(
                RenewalHistory(
                    customer_id=customer.id,
                    old_expiry=old_expiry,
                    new_expiry=new_expiry,
                    duration=duration,
                )
            )
            await session.commit()
            await session.refresh(customer)
            log.info("Package activated id=%s +%s days (-%s)", customer_id, duration, price)
            return customer

    async def delete(self, customer_id: int) -> bool:
        async with db.session() as session:
            repo = CustomerRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return False
            await repo.delete(customer)
            await session.commit()
            log.info("Customer deleted id=%s", customer_id)
            return True

    async def renew(self, customer_id: int, duration: int) -> Customer | None:
        """মেয়াদ বাড়ায় এবং renewal history সংরক্ষণ করে।

        এক্সপায়ার্ড হলে আজ থেকে, নাহলে বর্তমান expiry থেকে যোগ হয়।
        """
        async with db.session() as session:
            repo = CustomerRepository(session)
            renewal_repo = RenewalRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return None
            today = date_utils.today()
            now_local = date_utils.now_naive()
            base: date = customer.expiry_date if customer.expiry_date >= today else today
            base_at = (
                customer.expiry_at
                if customer.expiry_at and customer.expiry_at > now_local
                else now_local
            )
            old_expiry = customer.expiry_date
            new_expiry = date_utils.calc_expiry(base, duration)
            customer.expiry_date = new_expiry
            customer.expiry_at = date_utils.calc_expiry_at(base_at, duration)
            customer.remaining_days = date_utils.remaining_days(new_expiry)
            customer.status = date_utils.compute_status(new_expiry)
            await renewal_repo.add(
                RenewalHistory(
                    customer_id=customer.id,
                    old_expiry=old_expiry,
                    new_expiry=new_expiry,
                    duration=duration,
                )
            )
            await session.commit()
            await session.refresh(customer)
            log.info("Customer renewed id=%s +%s days", customer_id, duration)
            return customer

    async def set_balance(self, customer_id: int, value: float) -> Customer | None:
        """এডমিন কর্তৃক ব্যালান্স নির্দিষ্ট মানে সেট করে।"""
        async with db.session() as session:
            repo = CustomerRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return None
            customer.balance = max(0.0, float(value))
            settled = settle_due_from_balance(session, customer)
            await session.commit()
            await session.refresh(customer)
            customer.last_settled = settled
            log.info("Balance set id=%s =%s", customer_id, customer.balance)
            return customer

    async def adjust_balance(self, customer_id: int, delta: float) -> Customer | None:
        """এডমিন কর্তৃক ব্যালান্স বাড়ায়/কমায় (সর্বনিম্ন 0)।"""
        async with db.session() as session:
            repo = CustomerRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return None
            customer.balance = max(0.0, float(customer.balance or 0.0) + float(delta))
            settled = settle_due_from_balance(session, customer)
            await session.commit()
            await session.refresh(customer)
            customer.last_settled = settled
            log.info("Balance adjusted id=%s %s", customer_id, delta)
            return customer

    async def update_dates(
        self,
        customer_id: int,
        start_date: date | None = None,
        expiry_date: date | None = None,
    ) -> Customer | None:
        """এডমিন কর্তৃক শুরু/মেয়াদের তারিখ এডিট।

        - শুরুর তারিখ বদলালে: নতুন শুরু থেকে প্যাকেজের মেয়াদ গণনা হয়
          (expiry = নতুন শুরু + মেয়াদ); ইতিমধ্যে পেরিয়ে যাওয়া দিন অবশিষ্ট থেকে বাদ পড়ে।
        - মেয়াদের তারিখ সরাসরি বদলালে: ঐ দিনের শেষ পর্যন্ত ধরা হয়।
        """
        async with db.session() as session:
            repo = CustomerRepository(session)
            customer = await repo.get(customer_id)
            if customer is None:
                return None
            now_time = date_utils.now_naive().time()
            if start_date is not None:
                # পুরোনো প্যাকেজের দৈর্ঘ্য (দিন) ধরে রেখে নতুন শুরু থেকে হিসাব।
                duration = max(0, (customer.expiry_date - customer.start_date).days)
                customer.start_date = start_date
                customer.expiry_date = start_date + timedelta(days=duration)
                start_at = datetime.combine(start_date, now_time)
                customer.expiry_at = start_at + timedelta(days=duration)
            if expiry_date is not None:
                customer.expiry_date = expiry_date
                # ঐ দিনের শেষ মুহূর্ত (পরের দিনের 00:00) পর্যন্ত।
                customer.expiry_at = datetime.combine(
                    expiry_date + timedelta(days=1), time.min
                )
            customer.remaining_days = date_utils.remaining_days(customer.expiry_date)
            customer.status = date_utils.compute_status(customer.expiry_date)
            await session.commit()
            await session.refresh(customer)
            log.info("Dates updated id=%s", customer_id)
            return customer

    async def get_purchases(self, customer_id: int) -> list[PackagePurchase]:
        """গ্রাহকের প্যাকেজ ক্রয় ইতিহাস (সাম্প্রতিক আগে)।"""
        async with db.session() as session:
            return await PurchaseRepository(session).list_for_customer(customer_id)

    async def refresh_all_statuses(self) -> int:
        """সব গ্রাহকের remaining_days ও status রিফ্রেশ (scheduler থেকে)।"""
        async with db.session() as session:
            repo = CustomerRepository(session)
            customers = await repo.list_all()
            for customer in customers:
                customer.remaining_days = date_utils.remaining_days(customer.expiry_date)
                customer.status = date_utils.compute_status(customer.expiry_date)
            await session.commit()
            return len(customers)

    # ---- রিড হেল্পার ----
    async def get(self, customer_id: int) -> Customer | None:
        async with db.session() as session:
            return await CustomerRepository(session).get(customer_id)

    async def get_by_telegram_id(self, telegram_id: int) -> Customer | None:
        async with db.session() as session:
            return await CustomerRepository(session).get_by_telegram_id(telegram_id)

    async def search(self, term: str) -> list[Customer]:
        async with db.session() as session:
            return await CustomerRepository(session).search(term)

    async def resolve_one(self, term: str) -> tuple[Customer | None, list[Customer]]:
        """ID / Telegram ID / ফোন / নাম — যেকোনো একটি দিয়ে একজন গ্রাহক বের করে।

        ফেরত: (single_match_or_None, all_matches)।
        একাধিক মিললে এবং টার্মটি হুবহু একটি Customer ID হলে সেটিকেই বেছে নেয়।
        """
        term = (term or "").strip()
        matches = await self.search(term)
        if not matches:
            return None, []
        if len(matches) == 1:
            return matches[0], matches
        if term.isdigit():
            exact = [c for c in matches if str(c.id) == term]
            if len(exact) == 1:
                return exact[0], matches
        return None, matches

    async def list_all(self, limit: int | None = None, offset: int = 0) -> list[Customer]:
        async with db.session() as session:
            return await CustomerRepository(session).list_all(limit, offset)


customer_service = CustomerService()
