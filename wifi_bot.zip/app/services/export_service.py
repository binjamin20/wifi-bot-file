"""Export সার্ভিস — Excel (.xlsx) ও CSV ফাইল জেনারেট।

Customers + Payments শিট সহ Excel, এবং একটি customers CSV।
ফাইল exports/ ডিরেক্টরিতে সেভ হয়।
"""

from __future__ import annotations

import csv
import os

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

from app.database.base import db
from app.repositories.customer_repo import CustomerRepository
from app.repositories.payment_repo import PaymentRepository
from app.utils import date_utils
from app.utils.logger import get_logger

log = get_logger(__name__)
_EXPORT_DIR = "exports"

_HEADER_FILL = PatternFill("solid", fgColor="2E86C1")
_HEADER_FONT = Font(bold=True, color="FFFFFF")

_CUSTOMER_COLUMNS = [
    "ID", "Name", "Phone", "Telegram ID",
    "Package", "Price", "Start Date", "Expiry Date",
    "Remaining Days", "Status", "Paid", "Due", "Notes",
]
_PAYMENT_COLUMNS = [
    "ID", "Customer ID", "Amount", "Method", "Transaction ID", "Note", "Date",
]


def _style_header(ws) -> None:
    for cell in ws[1]:
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT


class ExportService:
    async def export_excel(self) -> str:
        """Excel ফাইল তৈরি করে পাথ ফেরত দেয়।"""
        os.makedirs(_EXPORT_DIR, exist_ok=True)
        async with db.session() as session:
            customers = await CustomerRepository(session).list_all()
            payments = await PaymentRepository(session).list_all(limit=100000)

        wb = Workbook()
        ws_c = wb.active
        ws_c.title = "Customers"
        ws_c.append(_CUSTOMER_COLUMNS)
        for c in customers:
            ws_c.append([
                c.id, c.name, c.phone, c.telegram_id or "",
                c.package_name, c.package_price,
                c.start_date.isoformat() if c.start_date else "",
                c.expiry_date.isoformat() if c.expiry_date else "",
                date_utils.remaining_days(c.expiry_date), c.status,
                c.paid_amount, c.due_amount, c.notes or "",
            ])
        _style_header(ws_c)

        ws_p = wb.create_sheet("Payments")
        ws_p.append(_PAYMENT_COLUMNS)
        for p in payments:
            ws_p.append([
                p.id, p.customer_id, p.amount, p.payment_method,
                p.transaction_id or "", p.note or "",
                p.created_at.isoformat() if p.created_at else "",
            ])
        _style_header(ws_p)

        stamp = date_utils.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(_EXPORT_DIR, f"wifi_export_{stamp}.xlsx")
        wb.save(path)
        log.info("Excel export created: %s", path)
        return path

    async def export_csv(self) -> str:
        """Customers CSV ফাইল তৈরি করে পাথ ফেরত দেয়।"""
        os.makedirs(_EXPORT_DIR, exist_ok=True)
        async with db.session() as session:
            customers = await CustomerRepository(session).list_all()

        stamp = date_utils.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(_EXPORT_DIR, f"wifi_customers_{stamp}.csv")
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            writer = csv.writer(fh)
            writer.writerow(_CUSTOMER_COLUMNS)
            for c in customers:
                writer.writerow([
                    c.id, c.name, c.phone, c.telegram_id or "",
                    c.package_name, c.package_price,
                    c.start_date.isoformat() if c.start_date else "",
                    c.expiry_date.isoformat() if c.expiry_date else "",
                    date_utils.remaining_days(c.expiry_date), c.status,
                    c.paid_amount, c.due_amount, c.notes or "",
                ])
        log.info("CSV export created: %s", path)
        return path


export_service = ExportService()
