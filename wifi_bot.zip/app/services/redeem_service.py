"""RedeemCode সার্ভিস — রিডিম কোড তৈরি ও ব্যবহার।

একটি কোড নির্দিষ্ট টাকার এবং সর্বোচ্চ max_uses বার ব্যবহার হতে পারে;
একজন গ্রাহক একটি কোড শুধু একবারই ব্যবহার করতে পারবে।
"""

from __future__ import annotations

import secrets
import string

from app.database.base import db
from app.database.models import Customer, Payment, RedeemCode, RedeemUse
from app.repositories.customer_repo import CustomerRepository
from app.repositories.redeem_repo import RedeemRepository
from app.services.customer_service import settle_due_from_balance
from app.utils.logger import get_logger

log = get_logger(__name__)

_ALPHABET = string.ascii_uppercase + string.digits


class RedeemService:
    """সব মেথড নিজেই session ম্যানেজ করে।"""

    @staticmethod
    def _generate() -> str:
        return "".join(secrets.choice(_ALPHABET) for _ in range(8))

    async def create(
        self, amount: float, max_uses: int, code: str | None = None
    ) -> RedeemCode:
        async with db.session() as session:
            repo = RedeemRepository(session)
            if code:
                code = code.strip().upper()
            else:
                code = self._generate()
                while await repo.get_by_code(code) is not None:
                    code = self._generate()
            rc = RedeemCode(
                code=code,
                amount=float(amount),
                max_uses=max(1, int(max_uses)),
            )
            await repo.add(rc)
            await session.commit()
            await session.refresh(rc)
            log.info("Redeem code created %s amount=%s uses=%s", rc.code, amount, max_uses)
            return rc

    async def list_all(self) -> list[RedeemCode]:
        async with db.session() as session:
            return await RedeemRepository(session).list_all()

    async def redeem(
        self, code_str: str, customer_id: int, telegram_id: int
    ) -> tuple[str, RedeemCode | None, Customer | None]:
        """কোড রিডিম করে।

        ফেরত: (code, redeem_code, customer)। code ∈ {not_found, inactive,
        exhausted, already, no_customer, ok}।
        """
        async with db.session() as session:
            repo = RedeemRepository(session)
            cust_repo = CustomerRepository(session)
            rc = await repo.get_by_code((code_str or "").strip().upper())
            if rc is None:
                return "not_found", None, None
            if not rc.is_active:
                return "inactive", rc, None
            if rc.used_count >= rc.max_uses:
                return "exhausted", rc, None
            already = await repo.used_by_telegram(rc.id, telegram_id)
            if already is not None:
                return "already", rc, None
            customer = await cust_repo.get(customer_id)
            if customer is None:
                return "no_customer", rc, None
            customer.balance = float(customer.balance or 0.0) + float(rc.amount)
            settled = settle_due_from_balance(session, customer)
            rc.used_count += 1
            if rc.used_count >= rc.max_uses:
                rc.is_active = False
            await repo.add_use(
                RedeemUse(
                    code_id=rc.id,
                    customer_id=customer.id,
                    telegram_id=telegram_id,
                )
            )
            session.add(
                Payment(
                    customer_id=customer.id,
                    amount=float(rc.amount),
                    payment_method="Redeem",
                    counts_as_income=False,  # রিডিম = ব্যালান্স টপ-আপ, আয় নয়
                    transaction_id=rc.code,
                    note=f"\u09b0\u09bf\u09a1\u09bf\u09ae \u0995\u09cb\u09a1: {rc.code}",
                )
            )
            await session.commit()
            await session.refresh(rc)
            await session.refresh(customer)
            customer.last_settled = settled
            log.info("Redeem used %s by cust=%s", rc.code, customer.id)
            return "ok", rc, customer


    async def set_active(self, code_id: int, active: bool) -> RedeemCode | None:
        """একটি রিডিম কোড চালু/বন্ধ করে (ব্যালান্সে হাত দেয় না)।"""
        async with db.session() as session:
            repo = RedeemRepository(session)
            rc = await repo.get(code_id)
            if rc is None:
                return None
            rc.is_active = bool(active)
            await session.commit()
            await session.refresh(rc)
            log.info("Redeem code %s set active=%s", rc.code, active)
            return rc


redeem_service = RedeemService()
