"""PaymentRequest সার্ভিস — গ্রাহকের ডিপোজিট/প্যাকেজ অনুরোধ ও Approve/Reject।

টাকার হিসাব (ব্যালান্স যোগ/কাটা, প্যাকেজ এক্টিভেশন) সব এই লেয়ারে
atomic transaction-এ হয় — কখনো গ্রাহকের ইনপুটের উপর ভরসা করা হয় না।
"""

from __future__ import annotations

from app.database.base import db
from app.database.models import (
    REQ_DEPOSIT,
    REQ_PACKAGE,
    REQUEST_APPROVED,
    REQUEST_PENDING,
    REQUEST_REJECTED,
    Customer,
    Package,
    PackagePurchase,
    Payment,
    PaymentRequest,
    RenewalHistory,
)
from app.config import settings
from app.repositories.customer_repo import CustomerRepository
from app.repositories.request_repo import RequestRepository
from app.utils import date_utils
from app.utils.logger import get_logger

log = get_logger(__name__)


class RequestService:
    """সব মেথড নিজেই session ম্যানেজ করে।"""

    # ---------- তৈরি ----------
    async def create_deposit(
        self,
        *,
        customer_id: int | None,
        telegram_id: int,
        username: str | None,
        name: str | None,
        amount: float,
        method: str,
        transaction_id: str | None = None,
        sender_number: str | None = None,
    ) -> PaymentRequest:
        async with db.session() as session:
            repo = RequestRepository(session)
            req = PaymentRequest(
                customer_id=customer_id,
                telegram_id=telegram_id,
                telegram_username=username,
                telegram_name=name,
                req_type=REQ_DEPOSIT,
                amount=float(amount),
                method=method,
                transaction_id=transaction_id,
                sender_number=sender_number,
                status=REQUEST_PENDING,
            )
            await repo.add(req)
            await session.commit()
            await session.refresh(req)
            return req

    async def create_package(
        self,
        *,
        customer_id: int | None,
        telegram_id: int,
        username: str | None,
        name: str | None,
        package: Package,
        mac_address: str | None = None,
        is_credit: bool = False,
        paid_now: float | None = None,
        credit_due: float | None = None,
    ) -> PaymentRequest:
        async with db.session() as session:
            repo = RequestRepository(session)
            req = PaymentRequest(
                customer_id=customer_id,
                telegram_id=telegram_id,
                telegram_username=username,
                telegram_name=name,
                req_type=REQ_PACKAGE,
                amount=float(package.price),
                package_id=package.id,
                package_name=package.name,
                duration_days=package.duration_days,
                mac_address=(mac_address or None),
                is_credit=bool(is_credit),
                paid_now=paid_now,
                credit_due=credit_due,
                status=REQUEST_PENDING,
            )
            await repo.add(req)
            await session.commit()
            await session.refresh(req)
            return req

    # ---------- রিড ----------
    async def get(self, request_id: int) -> PaymentRequest | None:
        async with db.session() as session:
            return await RequestRepository(session).get(request_id)

    async def list_pending(self) -> list[PaymentRequest]:
        async with db.session() as session:
            return await RequestRepository(session).list_pending()

    # ---------- Approve / Reject ----------
    async def approve(
        self, request_id: int
    ) -> tuple[str, PaymentRequest | None, Customer | None, dict]:
        """অনুরোধ অনুমোদন করে।

        ফেরত: (code, request, customer)। code ∈ {not_found, already, no_customer,
        insufficient, deposit_ok, package_ok}।
        """
        async with db.session() as session:
            req_repo = RequestRepository(session)
            cust_repo = CustomerRepository(session)
            req = await req_repo.get(request_id)
            if req is None:
                return "not_found", None, None, {}
            if req.status != REQUEST_PENDING:
                return "already", req, None, {}

            # গ্রাহক বের করি
            customer: Customer | None = None
            if req.customer_id is not None:
                customer = await cust_repo.get(req.customer_id)
            if customer is None and req.telegram_id is not None:
                customer = await cust_repo.get_by_telegram_id(req.telegram_id)
            if customer is None:
                return "no_customer", req, None, {}

            if req.req_type == REQ_DEPOSIT:
                amount = float(req.amount or 0.0)
                # আগে বকেয়া থাকলে ডিপোজিট থেকে আগে বকেয়া কাটা হয়, বাকিটা ব্যালান্সে যোগ হয়
                due_before = float(customer.due_amount or 0.0)
                applied_to_due = min(due_before, amount)
                customer.due_amount = due_before - applied_to_due
                customer.paid_amount = float(customer.paid_amount or 0.0) + applied_to_due
                customer.balance = float(customer.balance or 0.0) + (amount - applied_to_due)
                session.add(
                    Payment(
                        customer_id=customer.id,
                        amount=amount,
                        payment_method=req.method or "Cash",
                        counts_as_income=False,  # ডিপোজিট আয় নয়, শুধু ব্যালান্স টপ-আপ
                        transaction_id=req.transaction_id,
                        note="\u09ac\u09cd\u09af\u09be\u09b2\u09be\u09a8\u09cd\u09b8 \u09a1\u09bf\u09aa\u09cb\u099c\u09bf\u099f",
                    )
                )
                if applied_to_due > 0:
                    session.add(
                        Payment(
                            customer_id=customer.id,
                            amount=applied_to_due,
                            payment_method="Due",
                            counts_as_income=True,  # বকেয়া পরিশোধ = প্রকৃত আয়
                            note="বকেয়া পরিশোধ (ডিপোজিট থেকে)",
                        )
                    )
                req.status = REQUEST_APPROVED
                req.resolved_at = date_utils.now()
                await session.commit()
                await session.refresh(req)
                await session.refresh(customer)
                log.info("Deposit approved req=%s cust=%s amount=%s", req.id, customer.id, amount)
                return "deposit_ok", req, customer, {"applied_to_due": applied_to_due}

            if req.req_type == REQ_PACKAGE:
                price = float(req.amount or 0.0)
                balance = float(customer.balance or 0.0)
                is_credit = bool(getattr(req, "is_credit", False))
                min_pay = price * float(settings.credit_min_pay_ratio)
                if balance >= price:
                    pay_now = price
                    new_due = 0.0
                elif is_credit and float(customer.due_amount or 0.0) <= 0 and balance >= min_pay:
                    # বাকিতে কেনা: এখন পুরো ব্যালান্স কাটা হবে, বাকিটা বকেয়া
                    pay_now = balance
                    new_due = price - balance
                else:
                    return "insufficient", req, customer, {}
                duration = int(req.duration_days or 0)
                today = date_utils.today()
                now_local = date_utils.now_naive()
                base = (
                    customer.expiry_date
                    if customer.expiry_date and customer.expiry_date >= today
                    else today
                )
                base_at = (
                    customer.expiry_at
                    if customer.expiry_at and customer.expiry_at > now_local
                    else now_local
                )
                old_expiry = customer.expiry_date
                new_expiry = date_utils.calc_expiry(base, duration)
                new_expiry_at = date_utils.calc_expiry_at(base_at, duration)
                # ব্যালান্স কাটা (বাকিতে হলে যতটুকু আছে, বাকিটা বকেয়ায় যোগ)
                customer.balance = float(customer.balance or 0.0) - pay_now
                customer.due_amount = float(customer.due_amount or 0.0) + new_due
                customer.package_name = req.package_name or customer.package_name
                customer.package_price = price
                customer.expiry_date = new_expiry
                customer.expiry_at = new_expiry_at
                customer.remaining_days = date_utils.remaining_days(new_expiry)
                customer.status = date_utils.compute_status(new_expiry)
                customer.paid_amount = float(customer.paid_amount or 0.0) + pay_now
                # গ্রাহকের MAC অ্যাড্রেস হালনাগাদ (অনুরোধে থাকলে)
                if req.mac_address:
                    customer.mac_address = req.mac_address
                # প্যাকেজ ক্রয়ের রেকর্ড (কখন, কোন প্যাকেজ, MAC সহ)
                session.add(
                    PackagePurchase(
                        customer_id=customer.id,
                        package_name=req.package_name or "প্যাকেজ",
                        duration_days=duration,
                        price=price,
                        mac_address=req.mac_address,
                        start_date=base,
                        expiry_date=new_expiry,
                        balance_after=customer.balance,
                    )
                )
                # রিনিউয়াল ইতিহাস + পেমেন্ট রেকর্ড (ব্যালান্স থেকে)
                session.add(
                    RenewalHistory(
                        customer_id=customer.id,
                        old_expiry=old_expiry,
                        new_expiry=new_expiry,
                        duration=duration,
                    )
                )
                session.add(
                    Payment(
                        customer_id=customer.id,
                        amount=pay_now,
                        payment_method="Balance",
                        note=f"\u09aa\u09cd\u09af\u09be\u0995\u09c7\u099c: {req.package_name or '-'}",
                    )
                )
                req.status = REQUEST_APPROVED
                req.resolved_at = date_utils.now()
                await session.commit()
                await session.refresh(req)
                await session.refresh(customer)
                log.info("Package approved req=%s cust=%s pkg=%s", req.id, customer.id, req.package_name)
                return "package_ok", req, customer, {"pay_now": pay_now, "new_due": new_due}

            # অজানা ধরন — নিরাপদে এডভান্স
            req.status = REQUEST_APPROVED
            req.resolved_at = date_utils.now()
            await session.commit()
            await session.refresh(req)
            return "deposit_ok", req, customer, {}

    async def reject(self, request_id: int) -> PaymentRequest | None:
        async with db.session() as session:
            repo = RequestRepository(session)
            req = await repo.get(request_id)
            if req is None:
                return None
            if req.status == REQUEST_PENDING:
                req.status = REQUEST_REJECTED
                req.resolved_at = date_utils.now()
                await session.commit()
                await session.refresh(req)
            return req


request_service = RequestService()
