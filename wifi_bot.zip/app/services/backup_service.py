"""Backup সার্ভিস — ডেটাবেজ ফাইল + JSON ব্যাকআপ।

- SQLite হলে ডিকে .db ফাইল কপি হয়।
- সবক্ষেত্রে একটি JSON ডাম্প (customers + payments + renewals) তৈরি হয়।
- restore_json() দিয়ে JSON ব্যাকআপ থেকে রিস্টোর করা যায়।
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import date, datetime

from sqlalchemy import Date as SA_Date, DateTime as SA_DateTime, delete, select

from app.config import settings
from app.database.base import db
from app.database.models import (
    AppSetting,
    Customer,
    Package,
    PackagePurchase,
    Payment,
    PaymentRequest,
    RedeemCode,
    RedeemUse,
    RenewalHistory,
)
from app.utils import date_utils
from app.utils.logger import get_logger

log = get_logger(__name__)
_BACKUP_DIR = "backups"


def _json_default(value: object) -> str:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value)


class BackupService:
    async def backup_json(self) -> str:
        """সব ডাটা JSON-এ ডাম্প করে।"""
        os.makedirs(_BACKUP_DIR, exist_ok=True)
        async with db.session() as session:
            customers = (await session.execute(select(Customer))).scalars().all()
            payments = (await session.execute(select(Payment))).scalars().all()
            renewals = (await session.execute(select(RenewalHistory))).scalars().all()

            data = {
                "exported_at": date_utils.now().isoformat(),
                "customers": [self._customer_dict(c) for c in customers],
                "payments": [self._payment_dict(p) for p in payments],
                "renewals": [self._renewal_dict(r) for r in renewals],
            }

        stamp = date_utils.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(_BACKUP_DIR, f"backup_{stamp}.json")
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2, default=_json_default)
        log.info("JSON backup created: %s", path)
        return path

    async def backup_database_file(self) -> str | None:
        """SQLite হলে .db ফাইল কপি করে। Postgres হলে None।"""
        url = settings.database_url
        if not url.startswith("sqlite") or "///" not in url:
            return None
        os.makedirs(_BACKUP_DIR, exist_ok=True)
        src = url.split("///", 1)[1]
        if not os.path.exists(src):
            return None
        stamp = date_utils.now().strftime("%Y%m%d_%H%M%S")
        dst = os.path.join(_BACKUP_DIR, f"wifi_bot_{stamp}.db")
        shutil.copy2(src, dst)
        log.info("DB file backup created: %s", dst)
        return dst

    async def run_full_backup(self) -> dict:
        """JSON + DB দুটোই। scheduler এটি ডাকে।"""
        json_path = await self.backup_json()
        db_path = await self.backup_database_file()
        return {"json": json_path, "database": db_path}

    async def restore_json(self, path: str | None = None) -> int:
        """JSON ব্যাকআপ থেকে রিস্টোর (বর্তমান ডাটা মুছে নতুন করে বসায়)।"""
        if path is None:
            return -1
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        async with db.session() as session:
            # পুরনো ডাটা মুছে ফেলা (cascade)
            for customer in (await session.execute(select(Customer))).scalars().all():
                await session.delete(customer)
            await session.flush()
            for c in data.get("customers", []):
                session.add(self._customer_from_dict(c))
            await session.flush()
            for p in data.get("payments", []):
                session.add(Payment(
                    id=p["id"], customer_id=p["customer_id"], amount=p["amount"],
                    payment_method=p["payment_method"], transaction_id=p.get("transaction_id"),
                    note=p.get("note"),
                ))
            for r in data.get("renewals", []):
                session.add(RenewalHistory(
                    id=r["id"], customer_id=r["customer_id"],
                    old_expiry=date.fromisoformat(r["old_expiry"]) if r.get("old_expiry") else None,
                    new_expiry=date.fromisoformat(r["new_expiry"]),
                    duration=r["duration"],
                ))
            await session.commit()
        count = len(data.get("customers", []))
        log.info("Restored %s customers from %s", count, path)
        return count

    # ---- helpers ----
    @staticmethod
    def _customer_dict(c: Customer) -> dict:
        return {
            "id": c.id, "name": c.name, "phone": c.phone, "telegram_id": c.telegram_id,
            "package_name": c.package_name,
            "package_price": c.package_price, "start_date": c.start_date,
            "expiry_date": c.expiry_date, "remaining_days": c.remaining_days,
            "status": c.status, "paid_amount": c.paid_amount,
            "due_amount": c.due_amount, "notes": c.notes,
        }

    @staticmethod
    def _payment_dict(p: Payment) -> dict:
        return {
            "id": p.id, "customer_id": p.customer_id, "amount": p.amount,
            "payment_method": p.payment_method, "transaction_id": p.transaction_id,
            "note": p.note, "created_at": p.created_at,
        }

    @staticmethod
    def _renewal_dict(r: RenewalHistory) -> dict:
        return {
            "id": r.id, "customer_id": r.customer_id, "old_expiry": r.old_expiry,
            "new_expiry": r.new_expiry, "duration": r.duration,
        }

    @staticmethod
    def _customer_from_dict(c: dict) -> Customer:
        return Customer(
            id=c["id"], name=c["name"], phone=c["phone"], telegram_id=c.get("telegram_id"),
            package_name=c["package_name"],
            package_price=c["package_price"],
            start_date=date.fromisoformat(c["start_date"]),
            expiry_date=date.fromisoformat(c["expiry_date"]),
            remaining_days=c.get("remaining_days", 0), status=c.get("status", "active"),
            paid_amount=c.get("paid_amount", 0.0), due_amount=c.get("due_amount", 0.0),
            notes=c.get("notes"),
        )


    # ---- পূর্ণ এক্সপোর্ট / ইমপোর্ট (এক ফাইলে সব টেবিল) ----
    EXPORT_VERSION = 1

    _INSERT_ORDER = [
        Customer,
        Package,
        RedeemCode,
        Payment,
        RenewalHistory,
        PackagePurchase,
        PaymentRequest,
        RedeemUse,
        AppSetting,
    ]
    _DELETE_ORDER = [
        RedeemUse,
        PackagePurchase,
        RenewalHistory,
        Payment,
        PaymentRequest,
        RedeemCode,
        Package,
        AppSetting,
        Customer,
    ]

    @staticmethod
    def _row_to_dict(row: object) -> dict:
        result: dict = {}
        for col in row.__table__.columns:
            value = getattr(row, col.name)
            if isinstance(value, (date, datetime)):
                value = value.isoformat()
            result[col.name] = value
        return result

    @staticmethod
    def _dict_to_row(model: type, record: dict) -> object:
        kwargs: dict = {}
        for col in model.__table__.columns:
            if col.name not in record:
                continue
            value = record[col.name]
            if value is not None:
                if isinstance(col.type, SA_DateTime):
                    value = datetime.fromisoformat(value)
                elif isinstance(col.type, SA_Date):
                    value = date.fromisoformat(value)
            kwargs[col.name] = value
        return model(**kwargs)

    async def export_full(self) -> str:
        """সব টেবিল একটি JSON ফাইলে ডাম্প করে (সম্পূর্ণ স্ন্যাপশট)।"""
        os.makedirs(_BACKUP_DIR, exist_ok=True)
        payload: dict = {
            "__wifibot_export__": True,
            "version": self.EXPORT_VERSION,
            "exported_at": date_utils.now().isoformat(),
            "tables": {},
        }
        async with db.session() as session:
            for model in self._INSERT_ORDER:
                rows = (await session.execute(select(model))).scalars().all()
                payload["tables"][model.__tablename__] = [
                    self._row_to_dict(r) for r in rows
                ]
        stamp = date_utils.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(_BACKUP_DIR, f"wifibot_full_{stamp}.json")
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2, default=_json_default)
        log.info("Full export created: %s", path)
        return path

    @staticmethod
    def load_export(path: str) -> dict:
        """ফাইল পড়ে বৈধতা যাচাই করে ডেটা ফেরত দেয়; ভুল হলে ValueError।"""
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
            raise ValueError("ফাইলটি পড়া যায়নি বা বৈধ JSON নয়।") from exc
        if not isinstance(data, dict) or not data.get("__wifibot_export__"):
            raise ValueError("এটি বৈধ WiFi-বট এক্সপোর্ট ফাইল নয়।")
        if not isinstance(data.get("tables"), dict):
            raise ValueError("এক্সপোর্ট ফাইলটির গঠন ঠিক নেই।")
        return data

    @classmethod
    def summarize(cls, data: dict) -> dict:
        """টেবিল-ভিত্তিক row সংখ্যা (কনফার্মের আগে দেখানোর জন্য)।"""
        tables = data.get("tables", {})
        return {
            model.__tablename__: len(tables.get(model.__tablename__, []))
            for model in cls._INSERT_ORDER
        }

    async def import_full(self, data: dict) -> dict:
        """বর্তমান সব ডেটা মুছে ফাইল থেকে হুবহু রিস্টোর করে; row-count ফেরত দেয়।"""
        tables = data.get("tables", {})
        counts: dict = {}
        async with db.session() as session:
            for model in self._DELETE_ORDER:
                await session.execute(delete(model))
            await session.flush()
            for model in self._INSERT_ORDER:
                records = tables.get(model.__tablename__, [])
                for record in records:
                    session.add(self._dict_to_row(model, record))
                counts[model.__tablename__] = len(records)
                await session.flush()
            await session.commit()
        log.info("Full import done: %s", counts)
        return counts


backup_service = BackupService()
