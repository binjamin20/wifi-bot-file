"""Report সার্ভিস — ড্যাশবোর্ড, ডেইলি ও মাসিক রিপোর্ট ডাটা।"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, time, timedelta

import pytz

from app.config import settings
from app.database.base import db
from app.database.models import STATUS_ACTIVE, STATUS_EXPIRED
from app.repositories.customer_repo import CustomerRepository
from app.repositories.payment_repo import PaymentRepository
from app.repositories.renewal_repo import RenewalRepository
from app.utils import date_utils


@dataclass(slots=True)
class DashboardData:
    total: int
    active: int
    expired: int
    expiring_soon: int
    today_collection: float
    month_collection: float
    total_due: float


@dataclass(slots=True)
class DailyReportData:
    total: int
    active: int
    expired: int
    expiring_today: int
    expiring_3_days: int
    total_due: float
    yesterday_collection: float
    today_collection: float
    new_customers: int
    renewals: int


@dataclass(slots=True)
class MonthlyReportData:
    month_collection: float
    month_renewals: int
    total_due: float
    total_customers: int
    new_customers: int


_TZ = pytz.timezone(settings.timezone)


def _to_utc_naive(local_naive: datetime) -> datetime:
    """লোকাল (naive) সময়কে UTC naive-এ রূপান্তর — DB-তে created_at UTC-তে রাখা হয়।"""
    return _TZ.localize(local_naive).astimezone(pytz.utc).replace(tzinfo=None)


def _day_bounds(d) -> tuple[datetime, datetime]:
    """একটি লোকাল তারিখের শুরু ও পরের দিনের শুরু — UTC naive-এ (created_at তুলনার জন্য)।"""
    start_local = datetime.combine(d, time.min)
    return _to_utc_naive(start_local), _to_utc_naive(start_local + timedelta(days=1))


class ReportService:
    async def dashboard(self) -> DashboardData:
        today = date_utils.today()
        soon_end = today + timedelta(days=settings.expiring_soon_days)
        month_start = _to_utc_naive(datetime.combine(today.replace(day=1), time.min))
        day_start, day_end = _day_bounds(today)
        async with db.session() as session:
            crepo = CustomerRepository(session)
            prepo = PaymentRepository(session)
            expiring = await crepo.expiring_between(today, soon_end)
            return DashboardData(
                total=await crepo.count(),
                active=await crepo.count_by_status(STATUS_ACTIVE),
                expired=await crepo.count_by_status(STATUS_EXPIRED),
                expiring_soon=len(expiring),
                today_collection=await prepo.sum_between(day_start, day_end),
                month_collection=await prepo.sum_between(
                    month_start,
                    _to_utc_naive(datetime.combine(today + timedelta(days=1), time.min)),
                ),
                total_due=await crepo.total_due(),
            )

    async def daily_report(self) -> DailyReportData:
        today = date_utils.today()
        yesterday = today - timedelta(days=1)
        y_start, y_end = _day_bounds(yesterday)
        t_start, t_end = _day_bounds(today)
        async with db.session() as session:
            crepo = CustomerRepository(session)
            prepo = PaymentRepository(session)
            rrepo = RenewalRepository(session)
            expiring_today = await crepo.expiring_between(today, today)
            expiring_3 = await crepo.expiring_between(today, today + timedelta(days=3))
            return DailyReportData(
                total=await crepo.count(),
                active=await crepo.count_by_status(STATUS_ACTIVE),
                expired=await crepo.count_by_status(STATUS_EXPIRED),
                expiring_today=len(expiring_today),
                expiring_3_days=len(expiring_3),
                total_due=await crepo.total_due(),
                yesterday_collection=await prepo.sum_between(y_start, y_end),
                today_collection=await prepo.sum_between(t_start, t_end),
                new_customers=0,  # নিচে চেক
                renewals=await rrepo.count_between(t_start, t_end),
            )

    async def monthly_report(self) -> MonthlyReportData:
        today = date_utils.today()
        month_start = _to_utc_naive(datetime.combine(today.replace(day=1), time.min))
        next_day = _to_utc_naive(datetime.combine(today + timedelta(days=1), time.min))
        async with db.session() as session:
            crepo = CustomerRepository(session)
            prepo = PaymentRepository(session)
            rrepo = RenewalRepository(session)
            return MonthlyReportData(
                month_collection=await prepo.sum_between(month_start, next_day),
                month_renewals=await rrepo.count_between(month_start, next_day),
                total_due=await crepo.total_due(),
                total_customers=await crepo.count(),
                new_customers=0,
            )


report_service = ReportService()
