"""AppSetting সার্ভিস — owner এডিটযোগ্য সেটিংস।

পেমেন্ট মাধ্যম (নাম + নম্বর) ও সর্বনিম্ন ডিপোজিট DB-তে রাখা হয়।
owner চাইলে নতুন মাধ্যম যোগ করতে বা পুরোনো মাধ্যম বাদ দিতে পারে।
"""

from __future__ import annotations

import json

from app.database.base import db
from app.repositories.setting_repo import SettingRepository
from app.utils.logger import get_logger

log = get_logger(__name__)

# সেটিংস কী
KEY_PAYMENT_METHODS = "payment_methods"  # JSON: [{"name":.., "number":..}, ...]
KEY_MIN_DEPOSIT = "min_deposit"
KEY_FORCE_JOIN_ENABLED = "force_join_enabled"
KEY_FORCE_JOIN_CHANNELS = "force_join_channels"  # JSON: ["@channel", ...]
KEY_FORCE_JOIN_CHAT_META = "force_join_chat_meta"  # JSON: {key: {id,title,username}}
KEY_CASH_ENABLED = "cash_enabled"  # "1" চালু (ডিফল্ট) / "0" বন্ধ
KEY_MAC_VIDEO_URL = "mac_video_url"
KEY_MAC_VIDEO_LABEL = "mac_video_label"
KEY_MAC_SKIP_LABEL = "mac_skip_label"
KEY_MAC_ASK_TEXT = "mac_ask_text"

DEFAULT_MIN_DEPOSIT = 50.0

DEFAULT_MAC_VIDEO_LABEL = "📹 MAC বের করার ভিডিও দেখুন"
DEFAULT_MAC_SKIP_LABEL = "⏭ স্কিপ"
DEFAULT_MAC_ASK_TEXT = (
    "🔌 আপনার ডিভাইসের MAC অ্যাড্রেস লিখুন (যেমন AA:BB:CC:DD:EE:FF)।\n"
    "MAC না জানলে নিচের 'স্কিপ' বাটনে চাপুন।"
)

# প্রথমবার (DB খালি থাকলে) যেসব মাধ্যম দেখাবে
DEFAULT_METHODS = [
    {"name": "Bkash", "number": ""},
    {"name": "Nagad", "number": ""},
    {"name": "Rocket", "number": ""},
]


class SettingsService:
    """সব মেথড নিজেই session ম্যানেজ করে।"""

    async def get(self, key: str, default: str | None = None) -> str | None:
        async with db.session() as session:
            value = await SettingRepository(session).get_value(key)
            if value is None or value == "":
                return default
            return value

    async def set(self, key: str, value: str | None) -> None:
        async with db.session() as session:
            await SettingRepository(session).set(key, value)
            await session.commit()
            log.info("Setting updated %s", key)

    # ---- পেমেন্ট মাধ্যম (ডায়নামিক) ----
    async def list_payment_methods(self) -> list[dict]:
        """[{"name":.., "number":..}] তালিকা।"""
        raw = await self.get(KEY_PAYMENT_METHODS)
        if not raw:
            return [dict(m) for m in DEFAULT_METHODS]
        try:
            data = json.loads(raw)
        except (TypeError, ValueError):
            return [dict(m) for m in DEFAULT_METHODS]
        methods: list[dict] = []
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and item.get("name"):
                    methods.append(
                        {
                            "name": str(item["name"]).strip(),
                            "number": str(item.get("number") or "").strip(),
                        }
                    )
        return methods

    async def _save_methods(self, methods: list[dict]) -> None:
        await self.set(KEY_PAYMENT_METHODS, json.dumps(methods, ensure_ascii=False))

    async def method_names(self) -> list[str]:
        return [m["name"] for m in await self.list_payment_methods()]

    async def add_payment_method(self, name: str, number: str = "") -> bool:
        """নতুন মাধ্যম যোগ। আগে থাকলে শুধু নম্বর আপডেট হয়ে False ফেরে।"""
        name = (name or "").strip()
        if not name:
            return False
        methods = await self.list_payment_methods()
        for m in methods:
            if m["name"].lower() == name.lower():
                m["number"] = (number or "").strip()
                await self._save_methods(methods)
                return False
        methods.append({"name": name, "number": (number or "").strip()})
        await self._save_methods(methods)
        return True

    async def remove_payment_method(self, name: str) -> bool:
        target = (name or "").strip().lower()
        methods = await self.list_payment_methods()
        remaining = [m for m in methods if m["name"].lower() != target]
        if len(remaining) == len(methods):
            return False
        await self._save_methods(remaining)
        return True

    async def get_payment_number(self, method: str) -> str | None:
        target = (method or "").strip().lower()
        for m in await self.list_payment_methods():
            if m["name"].lower() == target:
                return m["number"] or None
        return None

    async def set_payment_number(self, method: str, number: str) -> None:
        method = (method or "").strip()
        methods = await self.list_payment_methods()
        for m in methods:
            if m["name"].lower() == method.lower():
                m["number"] = (number or "").strip()
                await self._save_methods(methods)
                return
        methods.append({"name": method, "number": (number or "").strip()})
        await self._save_methods(methods)

    async def all_numbers(self) -> dict[str, str | None]:
        """{name: number} — ডিসপ্লের জন্য।"""
        return {
            m["name"]: (m["number"] or None)
            for m in await self.list_payment_methods()
        }

    # ---- সর্বনিম্ন ডিপোজিট ----
    async def get_min_deposit(self) -> float:
        value = await self.get(KEY_MIN_DEPOSIT)
        if value is None:
            return DEFAULT_MIN_DEPOSIT
        try:
            return float(value)
        except (TypeError, ValueError):
            return DEFAULT_MIN_DEPOSIT

    async def set_min_deposit(self, amount: float) -> None:
        await self.set(KEY_MIN_DEPOSIT, str(float(amount)))

    # ---- ক্যাশ পেমেন্ট চালু/বন্ধ ----
    async def is_cash_enabled(self) -> bool:
        """ক্যাশ পেমেন্ট চালু কিনা (ডিফল্ট চালু)।"""
        return (await self.get(KEY_CASH_ENABLED, "1")) != "0"

    async def set_cash_enabled(self, enabled: bool) -> None:
        await self.set(KEY_CASH_ENABLED, "1" if enabled else "0")

    # ---- MAC ভিডিও সেটিং ----
    async def get_mac_video_url(self) -> str | None:
        return await self.get(KEY_MAC_VIDEO_URL) or None

    async def set_mac_video_url(self, url: str | None) -> None:
        await self.set(KEY_MAC_VIDEO_URL, (url or "").strip())

    async def get_mac_video_label(self) -> str:
        return await self.get(KEY_MAC_VIDEO_LABEL, DEFAULT_MAC_VIDEO_LABEL) or DEFAULT_MAC_VIDEO_LABEL

    async def set_mac_video_label(self, label: str) -> None:
        await self.set(KEY_MAC_VIDEO_LABEL, (label or "").strip() or DEFAULT_MAC_VIDEO_LABEL)

    async def get_mac_skip_label(self) -> str:
        return await self.get(KEY_MAC_SKIP_LABEL, DEFAULT_MAC_SKIP_LABEL) or DEFAULT_MAC_SKIP_LABEL

    async def set_mac_skip_label(self, label: str) -> None:
        await self.set(KEY_MAC_SKIP_LABEL, (label or "").strip() or DEFAULT_MAC_SKIP_LABEL)

    async def get_mac_ask_text(self) -> str:
        return await self.get(KEY_MAC_ASK_TEXT, DEFAULT_MAC_ASK_TEXT) or DEFAULT_MAC_ASK_TEXT

    async def set_mac_ask_text(self, text: str) -> None:
        await self.set(KEY_MAC_ASK_TEXT, (text or "").strip() or DEFAULT_MAC_ASK_TEXT)

    # ---- Force Join সিস্টেম ----
    @staticmethod
    def _norm_channel(raw: str) -> str | None:
        """@username বা t.me লিংক থেকে @username বের করে।"""
        if not raw:
            return None
        value = raw.strip()
        if not value:
            return None
        low = value.lower()
        for prefix in ("https://", "http://"):
            if low.startswith(prefix):
                value = value[len(prefix):]
                low = value.lower()
        if low.startswith("t.me/"):
            value = value[len("t.me/"):]
        elif low.startswith("telegram.me/"):
            value = value[len("telegram.me/"):]
        value = value.strip("/").split("/")[0].split("?")[0].strip()
        plain = value.lstrip("@").strip()
        if not plain:
            return None
        # সংখ্যাসূচক chat id (প্রাইভেট গ্রুপ/চ্যানেল) হলে যেমন আছে রাখি
        if plain.lstrip("-").isdigit():
            return plain
        return "@" + plain

    async def is_force_join_enabled(self) -> bool:
        return (await self.get(KEY_FORCE_JOIN_ENABLED)) == "1"

    async def set_force_join_enabled(self, enabled: bool) -> None:
        await self.set(KEY_FORCE_JOIN_ENABLED, "1" if enabled else "0")

    async def list_force_join_channels(self) -> list[str]:
        raw = await self.get(KEY_FORCE_JOIN_CHANNELS)
        if not raw:
            return []
        try:
            data = json.loads(raw)
        except (TypeError, ValueError):
            return []
        if not isinstance(data, list):
            return []
        result: list[str] = []
        for item in data:
            ch = self._norm_channel(str(item))
            if ch and ch not in result:
                result.append(ch)
        return result

    async def add_force_join_channel(self, raw: str) -> str | None:
        ch = self._norm_channel(raw)
        if not ch:
            return None
        channels = await self.list_force_join_channels()
        if ch not in channels:
            channels.append(ch)
            await self.set(KEY_FORCE_JOIN_CHANNELS, json.dumps(channels, ensure_ascii=False))
        return ch

    async def remove_force_join_channel(self, raw: str) -> bool:
        ch = self._norm_channel(raw)
        if not ch:
            return False
        channels = await self.list_force_join_channels()
        if ch not in channels:
            return False
        channels = [c for c in channels if c != ch]
        await self.set(KEY_FORCE_JOIN_CHANNELS, json.dumps(channels, ensure_ascii=False))
        return True

    # ---- চ্যাট মেটা (অটো chat_id সংরক্ষণ — প্রাইভেট গ্রুপ/চ্যানেল চেকের জন্য) ----
    async def get_chat_meta_map(self) -> dict:
        raw = await self.get(KEY_FORCE_JOIN_CHAT_META)
        if not raw:
            return {}
        try:
            data = json.loads(raw)
        except (TypeError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    async def remember_chat(
        self, chat_id: int, username: str | None, title: str | None
    ) -> None:
        """বট কোনো চ্যাটে অ্যাডমিন/মেম্বার হলে chat_id সংরক্ষণ করে —
        যেন @username বা সংখ্যাসূচক id দিয়ে মেম্বারশিপ চেক করা যায়।"""
        data = await self.get_chat_meta_map()
        entry = {
            "id": int(chat_id),
            "title": title or "",
            "username": (username.lstrip("@") if username else None),
        }
        if username:
            data["@" + username.lstrip("@")] = entry
        data[str(chat_id)] = entry
        await self.set(KEY_FORCE_JOIN_CHAT_META, json.dumps(data, ensure_ascii=False))

    async def resolve_chat_target(self, channel: str):
        """force-join এন্ট্রি → get_chat_member-এ ব্যবহারযোগ্য টার্গেট।

        জানা থাকলে সংখ্যাসূচক chat_id (প্রাইভেটেও কাজ করে), নাহলে @username।
        """
        data = await self.get_chat_meta_map()
        meta = data.get(channel)
        if meta and meta.get("id"):
            return int(meta["id"])
        raw = channel.lstrip("@")
        if raw.lstrip("-").isdigit():
            return int(raw)
        return channel


settings_service = SettingsService()
