# 🛠 ইনস্টলেশন ও প্রডাকশন গাইড

## ১. প্রস্তুতি

### Telegram Bot তৈরি
1. Telegram-এ [@BotFather](https://t.me/BotFather) এ যান।
2. `/newbot` দিয়ে নাম ও username দিন।
3. প্রাপ্ত **BOT_TOKEN** কপি করুন।

### নিজের OWNER_ID বের করা
1. [@userinfobot](https://t.me/userinfobot) এ `/start` দিন।
2. আপনার সংখ্যাসূচক **id** টি নোট করুন — এটিই OWNER_ID।

## ২. লোকাল সেটআপ (ডেভেলপমেন্ট)

```bash
# Python 3.12+ নিশ্চিত করুন
python3 --version

# ভার্চুয়াল এনভায়রনমেন্ট
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# ডিপেন্ডেন্সি
pip install -r requirements.txt

# পরিবেশ ফাইল
cp .env.example .env
nano .env                       # BOT_TOKEN, OWNER_ID, OWNER_CONTACT বসান

# চালু
python -m app.main
```

## ৩. প্রডাকশন — Docker (প্রস্তাবিত)

```bash
cp .env.example .env
nano .env

docker compose up -d --build    # ব্যাকগ্রাউন্ডে চলবে
docker compose logs -f bot      # লগ দেখা
docker compose down             # বন্ধ
```

`./data`, `./backups`, `./exports`, `./logs` হোস্টে mount করা — কন্টেইনার মুছলেও ডাটা থাকবে।

## ৪. PostgreSQL ব্যবহার (ঐচ্ছিক, স্কেলের জন্য)

1. `docker-compose.yml` এ `db` সার্ভিস আনকমেন্ট করুন।
2. `.env` এ:
   ```
   DATABASE_URL=postgresql+asyncpg://wifi:wifi@db:5432/wifi_bot
   ```
3. `docker compose up -d --build`

## ৫. systemd (Docker ছাড়া VPS-এ)

`/etc/systemd/system/wifibot.service`:
```ini
[Unit]
Description=WiFi Subscription Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/wifi_bot
ExecStart=/opt/wifi_bot/venv/bin/python -m app.main
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now wifibot
sudo systemctl status wifibot
```

## ৬. প্রডাকশন টিপস

- **ব্যাকআপ:** প্রতিদিন অটো ব্যাকআপ হয় (`BACKUP_HOUR`)। `backups/` ফোল্ডার বাইরেও কপি রাখুন।
- **টাইমজোন:** `TIMEZONE=Asia/Dhaka` — রিমাইন্ডার/রিপোর্ট সঠিক সময়ে।
- **সিকিউরিটি:** `.env` কখনো git-এ কমিট করবেন না।
- **লগ:** `logs/bot.log` এ rotating লগ রাখা হয়।
- **একাধিক ইনস্ট্যান্স চালাবেন না** — Telegram polling এ conflict হবে।

## ৭. সমস্যা সমাধান

| সমস্যা | সমাধান |
|--------|---------|
| `TelegramConflictError` | একাধিক ইনস্ট্যান্স চলছে — একটি বন্ধ করুন |
| মালিক কমান্ড কাজ করে না | `.env` এ `OWNER_ID` সঠিক কিনা দেখুন |
| গ্রাহক নোটিফিকেশন পান না | গ্রাহকের `telegram_id` সঠিক কিনা + গ্রাহক বটকে `/start` দিয়েছে কিনা |
