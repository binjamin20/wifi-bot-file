"""রুট-লেভেল এন্ট্রি পয়েন্ট।

কিছু হোস্টিং প্ল্যাটফর্ম রুট-এ `python main.py` (অথবা `main.py`) খোঁজে চালায় এবং
`python -m app.main` স্টার্টআপ কমান্ড এডিট করতে দেয় না। এই ফাইলটি শুধু
মূল অ্যাপকে (`app/main.py`) রান করে — সব লজিক আগের মতো `app/` এই রয়েছে।

চালানোর দুই পদ্ধতিই কাজ করবে:
    python main.py
    python -m app.main
"""

from __future__ import annotations

import asyncio

from app.main import log, main

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        log.info("\u09ac\u09cd\u09af\u09ac\u09b9\u09be\u09b0\u0995\u09be\u09b0\u09c0 \u09ac\u09a8\u09cd\u09a7 \u0995\u09b0\u09b2\u09c7\u09a8\u0964")
